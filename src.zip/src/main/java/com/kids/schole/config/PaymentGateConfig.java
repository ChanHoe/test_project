package com.kids.schole.config;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;

import com.kids.schole.common.constant.IConst;

@Configuration
public class PaymentGateConfig implements EnvironmentAware {

  private Environment environment;

  @Override
  public void setEnvironment(final Environment environment) {
    this.environment = environment;
  }

  @Bean
  public PropertySourcesPlaceholderConfigurer properties() {

    boolean releaseFlag = false;
    
    IConst.CONF_SYSTEM_TYPE = "DEV";
    for (String profile : environment.getActiveProfiles()) {
      if (profile.equals("release")) {
        releaseFlag = true;
        IConst.CONF_SYSTEM_TYPE = "RELEASE";
        break;
      }
    }

    PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer =
        new PropertySourcesPlaceholderConfigurer();
    YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
    yaml.setResources(new ClassPathResource(
        releaseFlag == true ? "config/payment-release.yml" : "config/payment.yml"));
    propertySourcesPlaceholderConfigurer.setProperties(yaml.getObject());
    return propertySourcesPlaceholderConfigurer;
  }

}
