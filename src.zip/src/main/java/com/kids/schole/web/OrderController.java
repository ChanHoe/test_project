package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.consumer.purchase.ConsumerOrderPurchaseConfig;
import com.kids.schole.batch.execute.consumer.purchase.SingleCopyOrderPurchaseConfig;
import com.kids.schole.batch.execute.order.purchase.OrderPurchaseConfig;

@Controller
@RequestMapping(value = "/order")
public class OrderController {
  @Autowired
  private OrderPurchaseConfig orderPurchase;
  
  @Autowired
  private ConsumerOrderPurchaseConfig consumerOrderPurchase;
  
  @Autowired
  private SingleCopyOrderPurchaseConfig singleCopyOrderPurchase;

  @RequestMapping(value = "/runOrderPurchase")
  @ResponseBody
  public String runOrderPurcahse(Model model) throws Exception {

    return orderPurchase.runOrderPurcahse();

  }
  
  @RequestMapping(value = "/runConsumerOrderPurchase")
  @ResponseBody
  public String runConsumerOrderPurchase(Model model) throws Exception {

    return consumerOrderPurchase.runConsumerOrderPurchase();

  }
  
  @RequestMapping(value = "/runSingleCopyOrderPurchase")
  @ResponseBody
  public String runSingleCopyOrderPurchase(Model model) throws Exception {

    return singleCopyOrderPurchase.runSingleCopyOrderPurchase();

  }
}
