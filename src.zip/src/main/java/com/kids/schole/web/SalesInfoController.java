package com.kids.schole.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.sales.SalesEmpInfoConfig;
import com.kids.schole.batch.execute.sales.SalesInfoConfig;

@Controller
@RequestMapping(value = "/salesInfo")
public class SalesInfoController {
	
  @Autowired
  private SalesInfoConfig salesInfoConfig;

  @Autowired
  private SalesEmpInfoConfig salesEmpInfoConfig;
  
  @RequestMapping(value = "/dailySales")
  @ResponseBody
  public String dailySales(HttpServletRequest request, Model model) throws Exception {
	  
	  String firstDate = ServletRequestUtils.getStringParameter(request, "firstDate");
	  
	  return salesInfoConfig.runSalesInfo(firstDate);
  }

  @RequestMapping(value = "/mothlyEmpSales")
  @ResponseBody
  public String mothlyEmpSales(HttpServletRequest request, Model model) throws Exception {
	  
	  String firstDate = ServletRequestUtils.getStringParameter(request, "firstDate");
	  
	  return salesEmpInfoConfig.runSalesInfo(firstDate);
  }
}
