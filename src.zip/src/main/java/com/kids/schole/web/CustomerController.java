package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.customer.ConsultationAllotConfig;

@Controller
@RequestMapping(value = "/coustomer")
public class CustomerController {

  @Autowired
  private ConsultationAllotConfig consultationAllot;
  
  @RequestMapping(value = "/consultationAllot")
  @ResponseBody
  public String runConsultationAllot(Model model) throws Exception {
    
    return consultationAllot.runConsultationAllot();
  }
  
}
