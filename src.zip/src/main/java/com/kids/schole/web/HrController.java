package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.hr.emp.EmpConfig;
import com.kids.schole.batch.execute.hr.organization.OrganizationEmpConfig;

@Controller
@RequestMapping("/hr")
public class HrController {

  @Autowired
  private EmpConfig empConfig;

  @Autowired
  private OrganizationEmpConfig organizationEmpConfig;

  @RequestMapping("/modifyPositionCode")
  @ResponseBody
  public String modifyPositionCode() throws Exception {

    return empConfig.runEmp();
  }

  @RequestMapping("/modifyOrganizationId")
  @ResponseBody
  public String modifyOrganizationId() throws Exception {

    return organizationEmpConfig.runOrganizationEmp();
  }
}
