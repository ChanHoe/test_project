package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.cashreceipt.issue.CashReceiptIssueConfig;
import com.kids.schole.batch.execute.cashreceipt.result.CashReceiptResultConfig;

@Controller
@RequestMapping(value = "/cashreceipt")
public class CashReceiptController {

  @Autowired
  private CashReceiptIssueConfig cashReceiptIssueConfig;

  @Autowired
  private CashReceiptResultConfig cashReceiptResultConfig;


  @RequestMapping(value = "/issue")
  @ResponseBody
  public String issue(Model model) throws Exception {

    return cashReceiptIssueConfig.runIssueCashReceipt();

  }

  @RequestMapping(value = "/result")
  @ResponseBody
  public String result(Model model) throws Exception {

    return cashReceiptResultConfig.runResultCashReceipt();

  }

}
