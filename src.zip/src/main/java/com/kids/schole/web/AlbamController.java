package com.kids.schole.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.albam.AlbamConfig;

@Controller
@RequestMapping(value = "/albam")
public class AlbamController {
  
  @Autowired
  private AlbamConfig albam;
  
  @RequestMapping(value = "/authenticate")
  @ResponseBody
  public String authenticate(Model model) throws Exception {
    
    return albam.runAlbamAuthenticate();
  }
  
  @RequestMapping(value = "/getStoresList")
  @ResponseBody
  public String getStoresList(Model model) throws Exception {
    
    return albam.runStoresList();
  }
  
  @RequestMapping(value = "/updateEmpInfo")
  @ResponseBody
  public String updateEmpInfo(HttpServletRequest request,Model model) throws Exception {
    
    String inputYear = ServletRequestUtils.getStringParameter(request, "inputYear");
    String inputMonth = ServletRequestUtils.getStringParameter(request, "inputMonth");
    String startDate = ServletRequestUtils.getStringParameter(request, "startDate");
    String endDate = ServletRequestUtils.getStringParameter(request, "endDate");
    String empKey = ServletRequestUtils.getStringParameter(request, "empKey");
    
    return albam.runAlbamRolls(inputYear, inputMonth, startDate,endDate, empKey);
  }

}
