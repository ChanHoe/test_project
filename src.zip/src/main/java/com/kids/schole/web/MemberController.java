package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.cms.member.MemberApplyConfig;
import com.kids.schole.batch.execute.cms.member.MemberDoneConfig;
import com.kids.schole.batch.execute.cms.member.MemberProofApplyConfig;
import com.kids.schole.batch.execute.cms.member.MemberProofCancelConfig;
import com.kids.schole.batch.execute.cms.member.MemberProofSearchConfig;
import com.kids.schole.batch.execute.cms.member.MemberSearchConfig;

@Controller
@RequestMapping(value = "/member")
public class MemberController {
  
  @Autowired
  private MemberProofApplyConfig memberProofApply;
  
  @Autowired
  private MemberProofSearchConfig memberProofSearch;
  
  @Autowired
  private MemberProofCancelConfig memberProofCancel;

  @Autowired
  private MemberApplyConfig memberApply;

  @Autowired
  private MemberDoneConfig memberDone;
  
  @Autowired
  private MemberSearchConfig memberSearch;
  
  @RequestMapping(value = "/memberProofApply")
  @ResponseBody
  public String runmemberProofApply(Model model) throws Exception {
    
    return memberProofApply.runMemberProofApply();
    
  }
  
  @RequestMapping(value = "/memberProofSearch")
  @ResponseBody
  public String runmemberProofSearch(Model model) throws Exception {
    
    return memberProofSearch.runMemberProofSearch();
    
  }
  
  @RequestMapping(value = "/memberProofCancel")
  @ResponseBody
  public String runmemberProofCancel(Model model) throws Exception {
    
    return memberProofCancel.runMemberProofCancel();
    
  }

  @RequestMapping(value = "/memberApply")
  @ResponseBody
  public String runMemberApply(Model model) throws Exception {

    return memberApply.runMemberApply();

  }

  @RequestMapping(value = "/memberDone")
  @ResponseBody
  public String runMemberDone(Model model) throws Exception {

    return memberDone.runMemberDone();

  }
  
  @RequestMapping(value = "/memberSearch")
  @ResponseBody
  public String runMemberSearch(Model model) throws Exception {
    
    return memberSearch.runMemberSearch();
    
  }
  
}
