package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.cms.installment.InstallmentApplyConfig;
import com.kids.schole.batch.execute.cms.installment.InstallmentDoneConfig;
import com.kids.schole.batch.execute.cms.installment.InstallmentSearchConfig;

@Controller
@RequestMapping(value = "/installment")
public class InstallmentController {

  @Autowired
  private InstallmentApplyConfig installmentApply;

  @Autowired
  private InstallmentDoneConfig installmentDone;

  @Autowired
  private InstallmentSearchConfig installmentSearch;
  
  @RequestMapping(value = "/installmentApply")
  @ResponseBody
  public String runInstallmentApply(Model model) throws Exception {

    return installmentApply.runInstallmentApply();

  }

  @RequestMapping(value = "/installmentDone")
  @ResponseBody
  public String runMemberDone(Model model) throws Exception {

    return installmentDone.runInstallmentDone();

  }

  @RequestMapping(value = "/installmentSearch")
  @ResponseBody
  public String runInstallmentSearch(Model model) throws Exception { 

    return installmentSearch.runInstallmentSearch();

  }

}
