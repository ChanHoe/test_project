package com.kids.schole.web;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.WarehouseResponseStatus;
import com.kids.schole.batch.support.delivery.service.DeliveryService;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.WarehouseConst;
import com.kids.schole.common.properties.WarehouseProperties;
import com.kids.schole.common.util.DomainUtil;
import com.kids.schole.common.util.WarehouseUtil;

@Controller
@RequestMapping(value = "/sample")
public class SampleController {

  /** 로거를 위한 변수 입니다. */
  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private WarehouseProperties warehouseProperties;

  @Autowired
  private DeliveryService deliveryService;

  @Autowired
  private SqlSession sqlSession;

  @RequestMapping(value = "/delivery/cancel")
  @ResponseBody
  public String cancelDelivery(HttpServletRequest request, Model model) throws Exception {
    //
    System.out.println("납품취소");

    // 현재 배송 대기중인 주문 리스트를 가져온다.
    List<Order> orderList = sqlSession.selectList("delivery.selectDeliveryRequestListForCancelScmTemp");
    for (Order order : orderList) {
      WarehouseResponseStatus warehouseResponseStatus = this.cancelScm(order.getWarehouseCompleteKey());
      if (warehouseResponseStatus.getResultCode().equals("0000")) {
        sqlSession.update("delivery.updateDeliveryRequestStatusTemp", order.getDeliveryRequestId());
      }
    }

    return "ok";
  }

  private WarehouseResponseStatus cancelScm(String warehouseCompleteKey) {
    //
    Map<String, String> warehouseMap = new TreeMap<String, String>();
    warehouseMap.put("customer_record_id", warehouseCompleteKey);
    warehouseMap.put("admin_id", "20160001");

    warehouseMap.put("memo", "배송 취소.");
    warehouseMap = WarehouseUtil.setTimeStampNFingerPrint(warehouseMap);

    String url = warehouseProperties.getUrl() + WarehouseConst.RECEPTION_RETURN_CONTENTS_URL;

    logger.debug("{}", url);
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

    HttpEntity<Map<String, String>> warehouseMapEntity =
        new HttpEntity<Map<String, String>>(warehouseMap, headers);

    RestTemplate restTemplate = new RestTemplate();
    ResponseEntity<String> responseEntity =
        restTemplate.postForEntity(url, warehouseMapEntity, String.class);
    logger.debug("{}", responseEntity);

    Gson gson = new GsonBuilder()
        .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

    WarehouseResponseStatus warehouseResponseStatus =
        gson.fromJson(responseEntity.getBody(), WarehouseResponseStatus.class);

    return warehouseResponseStatus;
  }

  @RequestMapping(value = "/sendDelivery")
  @ResponseBody
  public String dailySales(HttpServletRequest request, Model model) throws Exception {

    // 현재 배송 대기중인 주문 리스트를 가져온다.
    List<Order> orderList = sqlSession.selectList("delivery.selectDeliveryStatusWaitListTemp");

    System.out.println("ddd");

    for (Order order : orderList) {

      String[] tempMobileNumber = order.getReceiverMobileNumber().split("-");

      String prefixPhoneNumber = null;
      String infixPhoneNumber = null;
      String suffixPhoneNumber = null;

      if (StringUtils.isNotBlank(order.getReceiverPhoneNumber())) {
        String[] tempPhoneNumber = order.getReceiverPhoneNumber().split("-");
        if (tempPhoneNumber.length == 3) {
          prefixPhoneNumber = tempPhoneNumber[0];
          infixPhoneNumber = tempPhoneNumber[1];
          suffixPhoneNumber = tempPhoneNumber[2];
        }
      }

      // 현재 시간 설정
      LocalDateTime now = LocalDateTime.now();
      DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

      Map<String, String> warehouseMap = new TreeMap<String, String>();
      // 필수 값
      warehouseMap.put("contents_id", order.getWarehouseContentsKey());
      warehouseMap.put("biz_code", warehouseProperties.getBizCode());
      warehouseMap.put("biz_order_number", order.getOrderId() + "");
      warehouseMap.put("biz_delivery_record_id", order.getDeliveryRequestId() + "");
      warehouseMap.put("sender_name", warehouseProperties.getSenderName());
      warehouseMap.put("sender_tel", warehouseProperties.getSenderTel());
      warehouseMap.put("sender_addr", warehouseProperties.getSenderAddr());
      warehouseMap.put("customer_user_id", order.getCustomerId() + "");
      warehouseMap.put("customer_name", order.getReceiverName());
      warehouseMap.put("customer_phone1", tempMobileNumber[0]);
      warehouseMap.put("customer_phone2", tempMobileNumber[1]);
      warehouseMap.put("customer_phone3", tempMobileNumber[2]);
      warehouseMap.put("customer_postcode", order.getDeliveryPostcode());
      warehouseMap.put("customer_addr1", order.getDeliveryAddress());

      // 선택 값
      warehouseMap.put("customer_tel1", StringUtils.defaultString(prefixPhoneNumber));
      warehouseMap.put("customer_tel2", StringUtils.defaultString(infixPhoneNumber));
      warehouseMap.put("customer_tel3", StringUtils.defaultString(suffixPhoneNumber));
      warehouseMap.put("customer_addr2", order.getDeliveryAddressDetail());
      warehouseMap.put("biz_contents_id", "");
      warehouseMap.put("customer_memo", order.getDeliveryMessage());
      warehouseMap.put("payment_time", now.format(dateTimeFormatter));
      warehouseMap.put("delivery_contents_divide_yn", "N");
      warehouseMap.put("record_sub_type", "");
      warehouseMap.put("cs_reason", "");
      warehouseMap.put("cs_admin_id", "");
      warehouseMap.put("cs_admin_name", "");

      warehouseMap = WarehouseUtil.setTimeStampNFingerPrint(warehouseMap);

      String url = warehouseProperties.getUrl() + WarehouseConst.DELIVERY_INSERT_URL;
System.out.println(url);
      // Http Header 세팅
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

      HttpEntity<Map<String, String>> warehouseMapEntity =
          new HttpEntity<Map<String, String>>(warehouseMap, headers);

      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<String> responseEntity =
          restTemplate.postForEntity(url, warehouseMapEntity, String.class);

      Gson gson = new GsonBuilder()
          .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

      WarehouseResponseStatus warehouseResponseStatus =
          gson.fromJson(responseEntity.getBody(), WarehouseResponseStatus.class);

      DomainUtil.retriveDomain(warehouseResponseStatus);

      DeliveryRequest deliveryRequest = new DeliveryRequest();

      if (warehouseResponseStatus.getResultCode().equals("0000")) {
        deliveryRequest.setDeliveryRequestId(order.getDeliveryRequestId());
        deliveryRequest.setOrderId(order.getOrderId());
        deliveryRequest
            .setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_ACCEPTED);
        deliveryRequest.setWarehouseCompleteKey(
            warehouseResponseStatus.getWarehouseResult().getCustomerRecordId());
        deliveryRequest.setLastUpdatedEmpNumber(99999);

        deliveryService.modifyDeliveryRequestStatusScmAccept(deliveryRequest);

      } else {
        deliveryRequest.setDeliveryRequestId(order.getDeliveryRequestId());
        deliveryRequest.setOrderId(order.getOrderId());
        deliveryRequest.setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_WAIT);
        deliveryRequest.setWarehouseCompleteKey("");
        deliveryRequest.setLastUpdatedEmpNumber(99999);
      }

    }

    return "dd";
  }

}
