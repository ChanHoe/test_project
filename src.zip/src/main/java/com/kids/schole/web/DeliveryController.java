package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.channel.delivery.accept.ChannelSalesScmAcceptConfig;
import com.kids.schole.batch.execute.consumer.delivery.accept.ConsumerScmAcceptConfig;
import com.kids.schole.batch.execute.consumer.delivery.accept.SingleCopyScmAcceptConfig;
import com.kids.schole.batch.execute.consumer.delivery.tracking.ConsumerTrackingNumberTraceConfig;
import com.kids.schole.batch.execute.consumer.delivery.tracking.SingleCopyTrackingNumberTraceConfig;
import com.kids.schole.batch.execute.delivery.accept.ScmAcceptConfig;
import com.kids.schole.batch.execute.delivery.tracking.TrackingNumberTraceConfig;


@Controller
@RequestMapping(value = "/delivery")
public class DeliveryController {

  @Autowired
  private ScmAcceptConfig scmAcceptConfig;

  @Autowired
  private TrackingNumberTraceConfig trackingNumberTraceConfig;

  @Autowired
  private ConsumerScmAcceptConfig consumerScmAcceptConfig;

  @Autowired
  private SingleCopyScmAcceptConfig singleCopyScmAcceptConfig;

  @Autowired
  private ConsumerTrackingNumberTraceConfig consumerTrackingNumberTraceConfig;

  @Autowired
  private SingleCopyTrackingNumberTraceConfig singleCopyTrackingNumberTraceConfig;

  @Autowired
  private ChannelSalesScmAcceptConfig channelSalesScmAcceptConfig;

  @RequestMapping(value = "/runScmAccept")
  @ResponseBody
  public String runScmAccept(Model model) throws Exception {

    return scmAcceptConfig.runScmAccept();

  }

  @RequestMapping(value = "/runTrackingNumberTrace")
  @ResponseBody
  public String runTrackingNumberTrace(Model model) throws Exception {

    return trackingNumberTraceConfig.runTrackingNumberTrace();

  }

  @RequestMapping(value = "/runConsumerScmAccept")
  @ResponseBody
  public String runConsumerScmAccept(Model model) throws Exception {

    return consumerScmAcceptConfig.runConsumerScmAccept();

  }

  @RequestMapping(value = "/runConsumerTrackingNumberTrace")
  @ResponseBody
  public String runConsumerTrackingNumberTrace(Model model) throws Exception {

    return consumerTrackingNumberTraceConfig.runConsumerTrackingNumberTrace();

  }

  @RequestMapping(value = "/runSingleCopyScmAccept")
  @ResponseBody
  public String runSingleCopyScmAccept(Model model) throws Exception {

    return singleCopyScmAcceptConfig.runSingleCopyScmAccept();

  }

  @RequestMapping(value = "/runSingleCopyTrackingNumberTrace")
  @ResponseBody
  public String runSingleCopyTrackingNumberTrace(Model model) throws Exception {

    return singleCopyTrackingNumberTraceConfig.runSingleCopyTrackingNumberTrace();

  }

  /**
   * 채널주문의 배송
   */
  @RequestMapping(value = "/runChannelSalesScmAccept")
  @ResponseBody
  public String runChannelOrderScmAccept(Model model) throws Exception {

    return channelSalesScmAcceptConfig.runChannelSalesScmAccept();

  }
}
