package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.product.ProductStatusConfig;

@Controller
@RequestMapping(value = "/product")
public class ProductController {

  @Autowired
  private ProductStatusConfig productStatus;
  
  @RequestMapping(value = "/productStatus")
  @ResponseBody
  public String runProductStatus(Model model) throws Exception {
    
    return productStatus.runProductStatus();
  }
  
}
