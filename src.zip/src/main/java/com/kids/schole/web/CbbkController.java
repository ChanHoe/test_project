package com.kids.schole.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kids.schole.batch.execute.cbbk.autoAllot.AutoAllotConfig;
import com.kids.schole.batch.execute.cbbk.autoAllotCombine.AutoAllotCombineConfig;
import com.kids.schole.batch.execute.cbbk.settlebank.SettleBankDepositConfig;
import com.kids.schole.batch.execute.consumer.autoAllot.ConsumerAutoAllotConfig;

@Controller
@RequestMapping(value = "/cbbk")
public class CbbkController {
  
  @Autowired
  private SettleBankDepositConfig settleBankDepositConfig;

  @Autowired
  private AutoAllotConfig autoAllotConfig;
  
  @Autowired
  private AutoAllotCombineConfig autoAllotCombineConfig;
  
  @Autowired
  private ConsumerAutoAllotConfig consumerAutoAllotConfig;
  
  @RequestMapping(value = "/runSettleBankDeposit")
  @ResponseBody
  public String runSettleBankDeposit(Model model) throws Exception {
    
    return settleBankDepositConfig.runSettleBankDeposit();
    
  }
  
  @RequestMapping(value = "/runAutoAllot")
  @ResponseBody
  public String runAutoAllot(Model model) throws Exception {
    
    return autoAllotConfig.runAutoAllot();
    
  }
  
  @RequestMapping(value = "/runAutoAllotCombine")
  @ResponseBody
  public String runAutoAllotCombine(Model model) throws Exception {
    
    return autoAllotCombineConfig.runAutoAllotCombine();
    
  }
  
  @RequestMapping(value = "/runConsumerAutoAllot")
  @ResponseBody
  public String runConsumerAutoAllot(Model model) throws Exception {
    
    return consumerAutoAllotConfig.runConsumerAutoAllot();
    
  }

}
