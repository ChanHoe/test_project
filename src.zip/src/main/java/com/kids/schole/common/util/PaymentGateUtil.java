package com.kids.schole.common.util;

import java.io.File;
import java.io.IOException;

import org.springframework.core.io.ClassPathResource;

import com.galaxia.api.ConfigInfo;
import com.galaxia.api.ServiceCode;
import com.galaxia.api.crypto.GalaxiaCipher;
import com.galaxia.api.crypto.Seed;

/**
 * PaymentGateUtil은 PG사 관련 유틸리티 클래스입니다.
 * 
 * @version 1.0 2016.11.19
 * @author Jeongho Baek
 */
public class PaymentGateUtil {

  /**
   * PG(갤럭시아)의 전문 통신을 위해 데이터 암호화를 해서 반환합니다.
   *
   * @return String 파일경로
   * @exception Exception
   */
  public static GalaxiaCipher getGalaxiaCipher(String serviceId) {

    GalaxiaCipher cipher = null;

    try {
      String key = null;
      String iv = null;
      ConfigInfo config = new ConfigInfo(getGalaxiaConfigEnvFilePath(), ServiceCode.CREDIT_CARD);
      key = config.getKey();
      iv = config.getIv();
      cipher = new Seed();
      cipher.setKey(key.getBytes());
      cipher.setIV(iv.getBytes());
    } catch (Exception e) {
      e.printStackTrace();
    }

    return cipher;
  }

  /**
   * PG(갤럭시아)의 환경설정 파일을 위치를 반환합니다.
   *
   * @return String 파일경로
   * @exception Exception
   */
  public static String getGalaxiaConfigEnvFilePath() {

    File envConfigFile = null;
    try {
      String configFileName = ProfileUtil.isRelease() ? "config/galaxia_env-release.properties"
          : "config/galaxia_env.properties";
      ClassPathResource classPathResource = new ClassPathResource(configFileName);
      envConfigFile = classPathResource.getFile();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return envConfigFile.getAbsolutePath();
  }

  /**
   * PG(FMS)의 환경설정 파일을 위치를 반환합니다.
   *
   * @return String 파일경로
   * @exception Exception
   */
  public static String getFMSConfigEnvFilePath() {
    
    File envConfigFile = null;
    
    try {
      
      String configFileName = "";
      
      if(ProfileUtil.getActiveProfile().equals("local")) {
        configFileName = "config/xc_conf-local.txt";
      } else if(ProfileUtil.getActiveProfile().equals("dev")) {
        configFileName = "config/xc_conf-dev.txt";
      } else if(ProfileUtil.getActiveProfile().equals("qa")) {
        configFileName = "config/xc_conf-qa.txt";
      } else if(ProfileUtil.getActiveProfile().equals("release")) {
        configFileName = "config/xc_conf-release.txt";
      }
      
      ClassPathResource classPathResource = new ClassPathResource(configFileName);
      envConfigFile = classPathResource.getFile();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return envConfigFile.getAbsolutePath();
  }

}
