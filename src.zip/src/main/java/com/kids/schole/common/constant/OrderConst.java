package com.kids.schole.common.constant;

public class OrderConst {

  // 결재방식유형(할부)
  public static final String PAY_ACTION_TYPE_INSTALLMENT = "payIns";
  // 결재방식유형(일시불)
  public static final String PAY_ACTION_TYPE_LUMP_SUM = "payNow";

  // 주문상태
  // 가상계좌 : 입급대기, 입금 되어야 접수
  public static final String ORDER_STATUS_CBBK_READY = "cbbk-ready";
  // 접수 (카드 승인, 가상계좌 입금, 즉시출금 입금)
  public static final String ORDER_STATUS_ACCEPTED = "accepted";
  // 주문상태(보류)
  public static final String ORDER_STATUS_HOLDING = "holding";
  // 납품요청 (물류의뢰- 송장 타이틀? )
  public static final String ORDER_STATUS_SCM_ACCEPTED = "scm-accepted";
  // 배송완료(매출인식시점)
  public static final String ORDER_STATUS_DONE = "done";
  // 주문취소
  public static final String ORDER_STATUS_CANCEL = "cancel";
  // 부분취소
  public static final String ORDER_STATUS_PARTCANCEL = "partcancel";
  // 보류 인수거절
  public static final String ORDER_STATUS_ORDER_HOLDING_REJECT = "holding-reject";

  // 결제상태
  // 접수 (계좌요청, 승인)
  public static final String PAY_STATUS_READY = "ready";
  // 거절 (입금실패, 매입실패)
  public static final String PAY_STATUS_REJECT = "reject";
  // 결제완료 (계좌완료, 매입)
  public static final String PAY_STATUS_DONE = "done";
  // 결제취소 (결제취소)
  public static final String PAY_STATUS_CANCEL = "cancel";

  // 결제 방식
  // 카드
  public static final String ORDER_PAYMENT_PAY_TYPE_CARD = "card";
  // CMS 은행결제
  public static final String ORDER_PAYMENT_PAY_TYPE_CMS = "cms";
  // 가상계좌
  public static final String ORDER_PAYMENT_PAY_TYPE_CBBK = "cbbk";

  // 주문보류내역 - 요청 경로 request_type
  // 취소
  public static final String REQUEST_TYPE_CANCEL = "cancel";
  // 완료
  public static final String REQUEST_TYPE_DONE = "done";

  // 할부요청
  // 대기
  public static final String INSTALLMENT_PAYMENT_REQUEST_STATUS_WAIT = "wait";
  // 성공
  public static final String INSTALLMENT_PAYMENT_REQUEST_STATUS_SUCCESS = "success";
  // 연체
  public static final String INSTALLMENT_PAYMENT_REQUEST_STATUS_OVERDUE = "overdue";
  // 취소
  public static final String INSTALLMENT_PAYMENT_REQUEST_STATUS_CANCEL = "cancel";

  // 할부
  // 대기
  public static final String INSTALLMENT_PAYMENT_STATUS_WAIT = "wait";
  // 대체
  public static final String INSTALLMENT_PAYMENT_STATUS_SUBSTITUTE = "substitute";
  // 성공
  public static final String INSTALLMENT_PAYMENT_STATUS_SUCCESS = "success";
  // 실패
  public static final String INSTALLMENT_PAYMENT_STATUS_FAIL = "fail";

  // 할부인증
  // 대기
  public static final String INSTALLMENT_AUTHENTICATION_STATUS_WAIT = "wait";
   // 성공
  public static final String INSTALLMENT_AUTHENTICATION_STATUS_SUCCESS = "success";
  // 실패
  public static final String INSTALLMENT_AUTHENTICATION_STATUS_FAIL = "fail";

  // 회원증빙유형
  // 신규
  public static final String PROOF_TYPE_NEW = "new"; 
  // 수정
  public static final String PROOF_TYPE_MODIFY = "modify"; 
  // 삭제
  public static final String PROOF_TYPE_DELETE = "delete"; 
  
  // 회원증빙상태
  // 대기
  public static final String PROOF_STATUS_WAIT = "wait"; 
  // 진행중
  public static final String PROOF_STATUS_PROCESSING = "processing"; 
  // 실패
  public static final String PROOF_STATUS_FAIL = "fail"; 
  // 완료
  public static final String PROOF_STATUS_DONE = "done"; 
  
}
