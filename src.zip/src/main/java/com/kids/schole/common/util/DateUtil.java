package com.kids.schole.common.util;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

/**
 * DateUtil 는 날짜관련 클래스이다.
 *
 * @author GIL. K
 * @version 2015.05.20 / 1.0
 */
public class DateUtil {

    /**
     *
     * yyyymmdd ~ yyyymmdd 사이의 년수와 개월수 구하는 함수
     *
     * @param startYmd 시작 날짜 배열
     * @param endYmd 끝 날짜 배열
     * @param startIndex 시작배열 Index
     * @return String
     */
    public static String getYearMonth(String[] startYmd, String[] endYmd, int startIndex){

        String careerCnt = null;

        try{

            int size = startYmd.length;
            long diffday = 0;
            int f_year, f_month, f_date, e_year, e_month, e_date;

            for(int i = startIndex; i < size; i++){

                f_year = Integer.parseInt(startYmd[i].substring(0,4));
                f_month = Integer.parseInt(startYmd[i].substring(4,6));
                f_date = Integer.parseInt(startYmd[i].substring(6,8));

                e_year = Integer.parseInt(endYmd[i].substring(0,4));
                e_month = Integer.parseInt(endYmd[i].substring(4,6));
                e_date = Integer.parseInt(endYmd[i].substring(6,8));

                Calendar st = Calendar.getInstance();
                Calendar ed = Calendar.getInstance();
                st.set(f_year, f_month-1, f_date);
                ed.set(e_year, e_month-1, e_date);

                long diff = ed.getTime().getTime() - st.getTime().getTime();
                // 일자
                diffday += diff/(1000*60*60*24);
            }

            // 달수
            int month = (int)diffday/30;
            // 년수
            int year = month/12;
            // 나머지 개월수
            int extraMonth = (month % 12);
            StringBuffer sb = new StringBuffer();

            String strYear = "";
            String strMonth = "";

            if(year < 10) {
                sb.append("0");
                sb.append(String.valueOf(year));
                strYear = sb.toString();
            }else{
                strYear = String.valueOf(year);
            }

            sb = new StringBuffer();
            if(extraMonth < 10) {
                sb.append("0");
                sb.append(String.valueOf(extraMonth));
                strMonth = sb.toString();
            }else{
                strMonth = String.valueOf(extraMonth);
            }

            sb = new StringBuffer();
            sb.append(strYear);
            sb.append("-");
            sb.append(strMonth);

            careerCnt = sb.toString();

        } catch(Exception ex) {

        }

        return careerCnt;
    }

    /**
     *
     * 시작 나이와 끝 나이를 입력하면 시작년도와 끝년도를 구하는 함수
     *
     * @param ageStart 시작나이
     * @param ageEnd 끝나이
     * @return String[]
     */
    public static String[] getAgeYear(String ageStart, String ageEnd) {

        String[] year = new String[2];
        Calendar c = Calendar.getInstance();
        int curYear = c.get(Calendar.YEAR);

        int start = curYear - Integer.valueOf(ageEnd);
        int end = curYear - Integer.valueOf(ageStart);

        year[0] = String.valueOf(start);
        year[1] = String.valueOf(end);

        return year;
    }

    /**
     *
     * 해당년의 월의 마지막 날짜
     *
     * @param year 년도
     * @param month 월
     * @return int
     */
    public static int getDaysOfMonth(int year, int month) {
        int[] DOMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int[] lDOMonth = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if ((year % 4) == 0) {
            if ((year % 100) == 0 && (year % 400) != 0) {
                if(month>11){
                    return DOMonth[0];
                }else{
                    return DOMonth[month-1];
                }
            }
            if(month>11){
                return lDOMonth[0];
            }else{
                return lDOMonth[month-1];
            }
        } else {
            if(month>11){
                return DOMonth[0];
            }else{
                return DOMonth[month-1];
            }
        }
    }

    /**
     *
     * 시스템 날짜
     *
     * @return Date
     */
    public static Date getSysDate() {
        Calendar cal = Calendar.getInstance();
        return cal.getTime();
    }

    /**
     *
     * 시스템 날짜 Format
     *
     * @return String
     */
    public static String getSysDateFormat(String format) { return FormatUtil.matchFormat(new Date(), format); }
    public static String getSysDateFormat(Date date, String format) { return FormatUtil.matchFormat(date, format); }

    /**
     *
     * 시스템 날짜 (yyyyMMddHHmmss)
     *
     * @return String
     */
    public static String getSysYearSecond() { return FormatUtil.matchFormat(new Date(), "yyyyMMddHHmmss"); }
    
    /**
     * 시스템 해당월 첫번째 날짜 
     * 
     * @return
     */
    public static String getSysDateFirst() { return FormatUtil.matchFormat(new Date(), "yyyy-MM-")+"01"; }

    /**
     *
     * 시스템 날짜 (yyyyMMddHHmmss)
     *
     * @param ts Timestamp
     * @return String
     */
    public static String getSysYearSecond(Timestamp ts) {
        Date dt = new Date(ts.getTime());
        return FormatUtil.matchFormat(dt, "yyyyMMddHHmmss");
    }

    /**
     *
     * 시스템 날짜 (Calendar.YEAR)
     *
     * @return String
     */
    public static int getIntSysYear() { return Calendar.getInstance().get(Calendar.YEAR); }

    /**
     *
     * 시스템 날짜 (Calendar.MONTH)
     *
     * @return String
     */
    public static int getIntSysMonth() { return Calendar.getInstance().get(Calendar.MONTH) + 1; }
    
    /**
     *
     * 시스템 날짜 (Calendar.DAY_OF_MONTH)
     *
     * @return String
     */
    public static int getIntSysDay() { return Calendar.getInstance().get(Calendar.DAY_OF_MONTH); }

    /**
     *
     * 시스템 날짜 - 2자리 표현 월 (MM)
     *
     * @return String
     */
    public static String getSysTwoDigitMonth() { return FormatUtil.matchFormat(new Date(), "MM"); }

    /**
     *
     * 두 시간의 간격
     *
     * @param d1 시작날짜
     * @param d2 끝날짜
     * @return int (분)
     * @throws Exception
     */
    public static int getTimeInterval(Date d1, Date d2) throws Exception {
        int interval = 0;

        interval = (int)((d1.getTime() - d2.getTime()) / (60 * 1000));

        return interval;
    }

    /**
     *
     * 두 시간의 간격
     *
     * @param d1 시작날짜
     * @param d2 끝날짜
     * @return int (분)
     * @throws Exception
     */
    public static int getTimeInterval(long d1, long d2) throws Exception {
        int interval = 0;

        interval = (int)((d1 - d2) / (60 * 1000));

        return interval;
    }

    /**
     *
     * 현재와 시간 비교
     *
     * @return timedate 초
     * @throws Exception
     */

    public static int getTimeIntervalSecond(String timedate) throws Exception {
        int interval = 0;

        long d1 = System.currentTimeMillis();
        long d2 = Long.parseLong(timedate);
        interval = (int)((d1 - d2) / 1000);

        return interval;
    }

    /**
    *
    * targetDate까지의 남은 시간을 일-시-분-초 순서로 배열로 반환한다.
    *
    * @param targetDate 초
    * @return int[] 일-시-분-초
    */
   public static int[] getIntervalSecond(Date targetDate) {
       Date sysdate = getSysDate();

       int totalSec = (int)((targetDate.getTime() - sysdate.getTime()) / 1000 );

       int[] days = new int[4];
       if(totalSec < 0)
           totalSec = 0;

       int day = totalSec / (60 * 60 * 24);
       int hour = (totalSec - day * 60 * 60 * 24) / (60 * 60);
       int minute = (totalSec - day * 60 * 60 * 24 - hour * 60 * 60) / 60;
       int second = totalSec % 60;

       days[0] = day;
       days[1] = hour;
       days[2] = minute;
       days[3] = second;
       return days;
   }

    /**
     *
     * 날짜
     *
     * @param date 날짜
     * @param ymd 날짜  ( Calendar.YEAR | MONTH | DAY_OF_MONTH | HOUR | SECOND)
     * @param amt 추가 일자 또는 시간
     * @return Date
     */
    public static Date getDateAdd(Date date, int calendar_type, int amt) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(calendar_type, amt);
        return cal.getTime();
    }

    /**
     *
     * 날짜
     *
     * @param ts Timestamp 객체
     * @return int
     */
    public static int getAge(Timestamp ts) {

        Calendar c = Calendar.getInstance();
        int curYear = c.get(Calendar.YEAR);

        c.setTimeInMillis(ts.getTime());
        int birthYear = c.get(Calendar.YEAR);

        return curYear - birthYear;
    }

    /**
     *
     * 초를 일-시-분-초로 표현한다.
     *
     * @param totalSec 초
     * @return 일-시-분-초
     */
    public static String getSecondToDate(int totalSec) {
        int day = totalSec / (60 * 60 * 24);
        int hour = (totalSec - day * 60 * 60 * 24) / (60 * 60);
        int minute = (totalSec - day * 60 * 60 * 24 - hour * 3600) / 60;
        int second = totalSec % 60;
        return day+"-"+hour+"-"+minute+"-"+second;
    }

    /**
     *
     * 입력받은 date 에 addDate 만큼 날짜를 더해준다.
     *
     * @param date
     * @param addDate
     */
    public static Date addDate(Date date, int addDate){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, addDate);
        return cal.getTime();
    }

    /**
    *
    * 날짜
    *
    * @param year 년도
    * @param month 월
    * @param day 일
    * @param hour 시
    * @param minute 분
    * @param second 초
    * @return Date
    */
   public static Date getDate(int year, int month, int day, int hour, int minute, int second) {
       Calendar cal = Calendar.getInstance();
       cal.set(year, month-1, day, hour, minute, second);
       cal.set(Calendar.MILLISECOND, 0);
       return cal.getTime();
   }

   /**
    *
    * 날짜
    *
    * @param datetime 날짜
    * @return Date
    * @throws Exception
    */
   public static Date getDate(String datetime) throws Exception {
	   return getDateTime(datetime + " 00:00:00");
   }
   public static Date getDateTime(String datetime) throws Exception {
       String year, month, day, hour, minute, second;
       datetime = datetime.replace("-", "").replace(":", "").replace(" ", "");
       		
       if (datetime==null ||
           "".equals(datetime) ||
           datetime.length() != 14) return null;

       year = datetime.substring(0, 4);
       month = datetime.substring(4, 6);
       day = datetime.substring(6, 8);
       hour = datetime.substring(8, 10);
       minute = datetime.substring(10, 12);
       second = datetime.substring(12, 14);

       return getDate(StringUtil.toInt(year), StringUtil.toInt(month), StringUtil.toInt(day), StringUtil.toInt(hour), StringUtil.toInt(minute), StringUtil.toInt(second));
   }
   
}