package com.kids.schole.common.util;

import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

/**
 * SMSUtil은 문자 전송 유틸리티를 제공하는 클래스입니다.
 * 
 * @version 1.0 2016.12.08
 * @author Gil K.
 */
public class SMSUtil {
	private static final Logger LOG = LoggerFactory.getLogger(SMSUtil.class);

	// TODO 설정 파일로 빼성 유도적으로 받을 수 있게 (회사번호도 변경)
	private static String lapi_url = "https://lapi.dangi.co.kr";
	private static String company_num = "1522-6649";
	

	/**
	 * 문자 발송 (보낸이는 회사로 고정)
	 * 
	 * @param message
	 * @param receive_num
	 * @param subject
	 */
	public static void sendSms (
			String	message,
			String	receive_num,
			String	subject
			) {
		
		sendSms(message, receive_num, subject, company_num);
	}
	
	/**
	 * 문자발송 
	 * 
	 * @param message
	 * @param receive_num
	 * @param subject
	 * @param send_num
	 */
	public static void sendSms (
			String	message,
			String	receive_num,
			String	subject,
			String	send_num
			) {
	  
		String url = lapi_url + "/message/main/send";
		
		long timestamp = System.currentTimeMillis() / 1000;
		Random random = new Random();
		int seed = random.nextInt(9);
		
		Map<String, String> params = new TreeMap<String, String>();
		params.put("message"		, message);
		params.put("receive_num"	, receive_num);
		params.put("send_num"		, send_num);
		params.put("subject"		, subject);
		params.put("timestamp"		, String.valueOf(timestamp));
		
		String fingerPrint = ApiKeyUtil.getFingerPrint( params, seed );
		params.put("seed"			, String.valueOf(seed));
		params.put("fingerprint"	, fingerPrint);
		
		try {
			// 전송
			String result = new RestTemplate().postForObject(url, params, String.class);
			JSONObject resultJson = new JSONObject( result );	
			// 실패의 경우
			if( resultJson.getString("resultCode") != "0000" ) {
				LOG.error(result);
			}
		} catch ( Exception e) {
			LOG.error(params.toString());
			LOG.error(e.getMessage());
		}
	}
}
