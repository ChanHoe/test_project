package com.kids.schole.common.constant;

public class DeliveryConst {

  // 배송요청상태
  // 예약(주문접수전 상태로 납품대기 (보류, 가상계좌 입금대기))
  public static final String DELIVERY_REQUEST_STATUS_RESERVED = "reserved";
  // 예약취소(예약 단계에서 환불 등의 사유로 배송 취소된 상태)
  public static final String DELIVERY_REQUEST_STATUS_CANCELLED_RESERV = "cancelled-reservation";
  // 대기(물류 시스템으로 접수 요청하기 위한 단계. 시스템간 연동을 위한 상태)
  public static final String DELIVERY_REQUEST_STATUS_WAIT = "wait";
  // 보류(주문보류로 인한 남품 보류 (대기로 원복가능))
  public static final String DELIVERY_REQUEST_STATUS_HOLDING = "holding";
  // 물류접수(물류 시스템으로부터 접수 요청 완료키를 전달 받은 상태)
  public static final String DELIVERY_REQUEST_STATUS_SCM_ACCEPTED = "scm-accepted";
  // 물류접수취소(물류 접수 단계에서 배송 취소된 상태)
  public static final String DELIVERY_REQUEST_STATUS_SCM_CANCELLED = "scm-cancelled";
  // 출고(물류 시스템으로부터 택배 운송장번호를 전달 받은 상태)
  public static final String DELIVERY_REQUEST_STATUS_SCM_DELIVERY = "scm-delivery";
  // 배송완료(물류 시스템으로부터 택배 배송완료 받은 상태)
  public static final String DELIVERY_REQUEST_STATUS_SCM_SHIPPED = "scm-shipped";
  // 반품(출고 상태 이후 유입된 환불 건에 대하여 반품 요청.)
  public static final String DELIVERY_REQUEST_STATUS_REJECT = "reject";
  // 실패(서버에서 처리 실패로 판단한 상태. 특히, 물류창고 시스템으로부터 접수 요청에 대한 응답을 받지 못한 상태.)
  public static final String DELIVERY_REQUEST_STATUS_FAIL = "fail";
  // 폐기(이후의 처리가 불필요한 상태로 배송 요청 건을 폐기 함. 예) 중복 구매 건 등.)
  public static final String DELIVERY_REQUEST_STATUS_DISCARDED = "discarded";
  
  public static final String CJ_DELIVERY_SHIPPED = "배달완료";
  public static final String CJ_DELIVERY_REJECT = "미배달";

}
