package com.kids.schole.common.util;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

/**
 * SMSUtil은 문자 전송 유틸리티를 제공하는 클래스입니다.
 * 
 * @version 1.0 2016.12.28
 * @author Gil K.
 */
public class EmailUtil {

	// 메일 관련 정보
	private static final String host = "webmail.st-company.net";
	private static final int port = 465;
	private static final String system_mail = "noreply@stunitas.com";

	/**
     * HTML 메일 전송
     */
	public static void sendHtmlEmail(String to, String subject, String content) throws Exception {
		googleSmtpSendHtmlEmail(system_mail, system_mail, to, to, subject, content);
	}
	
	// google stmp 사용
	public static void googleSmtpSendHtmlEmail(String from, String fromName, String to, String toName, String subject, String content) throws Exception {

        Properties config = new Properties();
        config.put("mail.smtp.user", from);
        config.put("mail.smtp.host", "smtp.gmail.com");
        config.put("mail.smtp.port", port);
        config.put("mail.smtp.starttls.enable","true");
        config.put("mail.smtp.auth", "true");
        config.put("mail.smtp.debug", "true");
        config.put("mail.smtp.socketFactory.port", port);
        config.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        config.put("mail.smtp.socketFactory.fallback", "false");

        try {

            Session session = Session.getInstance(config, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("lounge.kids.schole@gmail.com", "lounge123"); // Google id, pwd, 주의) @gmail.com 은 제외
                }
            });

            Multipart mp = new MimeMultipart();
            MimeBodyPart mbpHtml = new MimeBodyPart();
            mbpHtml.setDataHandler(new DataHandler(new ByteArrayDataSource(content, "text/html")));
            mp.addBodyPart(mbpHtml);

            MimeMessage message = new MimeMessage(session);

            //메일 제목 넣기
            message.setSubject(subject);
            //메일 본문을 넣기
            message.setContent(mp);
            //보내는 날짜
            message.setSentDate(new Date());
            //보내는 메일 주소
            message.setFrom(new InternetAddress(from, fromName));
            // 한명에게만 보내는
//            message.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(to, toName));

            // 여려명에게
            List<String> list = StringUtil.split2Iterate(to, ",");
			InternetAddress[] recipientTo = new InternetAddress[list.size()];

			InternetAddress add;
			int i = 0;
			for(String mailTo : list){
				add = new InternetAddress();
				add.setAddress(mailTo);
				recipientTo[i++] = add;
            }
			message.addRecipients(Message.RecipientType.TO, recipientTo);

            Transport.send(message);

        } catch (Exception e){
            throw e;
        }
    }
	
	public static void sendHtmlEmail(String from, String fromName, String to, String subject, String content) throws Exception {
		try {
			Properties props = System.getProperties();
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.port", port);
            
			Session session = Session.getDefaultInstance(props);
			session.setDebug(false); //for debug
            
			InternetAddress add;
			int i = 0;
			List<String> list = StringUtil.split2Iterate(to, ",");
			InternetAddress[] recipientTo = new InternetAddress[list.size()];
			
			for(String mailTo : list){
				
				add = new InternetAddress();
				String[] mailInfo = StringUtil.split(mailTo.replace(">", ""), "<");
				if(mailInfo.length == 1){
					add.setAddress(mailTo);
				}else{
					add.setPersonal(mailInfo[0], "UTF-8");
					add.setAddress(mailInfo[1]);
				}
				recipientTo[i++] = add;
			}
			
			Message mimeMessage = new MimeMessage(session);
			mimeMessage.setFrom(new InternetAddress(from, fromName));
			mimeMessage.addRecipients(Message.RecipientType.TO, recipientTo);
			mimeMessage.setSubject(subject);
			mimeMessage.setContent(content, "text/html; charset=utf-8");
            
        	//James(Java Apache Mail Enterprise Server)
        	//로컬환경에서 테스트시 설치 필요
        	//http://james.apache.org/ 
			Transport.send(mimeMessage);
		}catch(Exception e){
			throw e;
		}
	}
	
	public static String makeEmailHtml(String content, String subject, String align) {  
		StringBuffer msg = new StringBuffer();
		msg.append(makeHtmlHeader());
		
		msg.append("<BODY>");
		msg.append("<table border='1' width='1000' cellpadding='2' align='center' borderColor='#ff0000' style='border-collapse:collapse'>");
		msg.append(" <tr height='25' align='center'>");
		msg.append("   <td width=100 class='bT'>"+subject+"</td>");
		msg.append(" </tr>");
		msg.append(" <tr bgcolor='#FFFFFF'>" );
		msg.append("	<td class='"+align+"' >"+content+"</td>");
		msg.append(" </tr>" );
		msg.append("</table> <br><br>" );
		msg.append("</BODY></HTML>" );

		return msg.toString(); 
	}
	
	public static String makeHtmlHeader() {
    	String Header = "<HTML>"
					  + "<HEAD>"
					  + "<meta http-equiv='Content-Language' content='euc-kr' />"
					  + "<meta http-equiv='Content-Type' content='text/html; charset=euc-kr' />"
					  + "<style type='text/css'>"
					  + "<!--"
					  + ".AC  {text-align:center; padding:10px;}"
					  + ".AL  {text-align:left; padding:10px;}"
					  + ".bT  {background:#F7C8BD; text-align:center; font-weight:bolder; padding:3 0 0 0px; }"
					  + ".bB  {background:#FFFFFF; padding:3 0 0 0px; }"
					  + ".bC  {background:#FF7FED; padding:3 0 0 0px; }"
					  + "BODY"
					  + "{"
					  + "    FONT-SIZE: 9pt;"
					  + "    COLOR: #000000;"
					  + "    LINE-HEIGHT: 11pt;"
					  + "    FONT-FAMILY: '굴림';"
					  + "    TEXT-DECORATION: none"
					  + "}"			
					  + "img { border:0; }"			
					  + "TD"
					  + "{"
					  + "    FONT-SIZE: 9pt;"
					  + "    COLOR: #000000;"
					  + "    LINE-HEIGHT: 11pt;"
					  + "    FONT-FAMILY: '굴림';"
					  + "    TEXT-DECORATION: none"
					  + "} -->"
					  + "</style>"
					  + "</HEAD>";
		
		return Header;
	}
}
