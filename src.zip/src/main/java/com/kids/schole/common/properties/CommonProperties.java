package com.kids.schole.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "common")
public class CommonProperties {

  private String uploadPath;
  private String uploadTempPath;
  private String systemEmailAddress;

  public String getUploadPath() {
    return uploadPath;
  }

  public void setUploadPath(String uploadPath) {
    this.uploadPath = uploadPath;
  }

  public String getUploadTempPath() {
    return uploadTempPath;
  }

  public void setUploadTempPath(String uploadTempPath) {
    this.uploadTempPath = uploadTempPath;
  }

  public String getSystemEmailAddress() {
    return systemEmailAddress;
  }

  public void setSystemEmailAddress(String systemEmailAddress) {
    this.systemEmailAddress = systemEmailAddress;
  }

}
