package com.kids.schole.common.constant;

public class AlbamConst {
  
  // 알밤 API는 전부 POST 방식
  
  // 등록된 상점 기본정보 조회 URL POST 방식
  public static final String ALBAM_STORES_URL = "/v1/stores";
  
  // 교사가 미등록이면 insert, 있는 경우에는 update 되는 API URL POST 방식
  public static final String ALBAM_CUSTOM_URL = "/v1/user/custom";
  
  // 교사 출근시간 기준, 출근여부 조회 URL POST 방식
  public static final String ALBAM_ROLLS_URL = "/v1/rolls";
  
  // 해당 지점에 근무하는 직원 목록 조회 URL POST 방식
  public static final String ALBAM_USERS_URL = "/v1/users";
  
  // accessToken 받는 인증
  public static final String ALBAM_AUTHENTICATE_URL = "/v1/authenticate";
  
}
