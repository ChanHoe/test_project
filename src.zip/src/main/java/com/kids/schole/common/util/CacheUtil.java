package com.kids.schole.common.util;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.etc.domain.SpecialHoliday;
import com.kids.schole.batch.support.etc.service.EtcService;

/**
 * CacheUtil은 캐쉬 관련 유틸리티 클래스입니다.
 * 
 * @version 1.0 2016.11.19
 * @author Jeongho Baek
 */
@Component
public class CacheUtil {

  private static EtcService etcService;

  @Autowired
  @SuppressWarnings("static-access")
  public void setEtcService(EtcService etcService) {
    this.etcService = etcService;
  }

  /**
   * 해당날짜가 대체휴일인지 체크한다.
   *
   * @param String 날짜(yyyyMMdd)
   * @return boolean 대체휴일 여부
   * 
   */
  public static boolean isSpecialHoliday(String date) {

    boolean isFlag = false;

    List<SpecialHoliday> specialHolidayList = etcService.getCacheSpecialHolidayList();

    for (SpecialHoliday specialHoliday : specialHolidayList) {
      if (specialHoliday.getHoliday().equals(date)) {
        isFlag = true;
        break;
      }
    }

    return isFlag;
  }

}
