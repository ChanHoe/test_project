package com.kids.schole.common.constant;

public class PaymentGateConst {

  // CARD----------------------------------
  // 결재 금액과 승인된 금액이 맞지 않을 때 쓰이는 코드(자체적으로 만듬)
  public static final String CREDIT_CARD_MISSMATCH_MONEY = "9999";
  // 카드 승인 취소 응답 명령어
  public static final String PG_APPROVAL_CANCEL_RESPONSE_COMMAND = "9001";
  // 카드 매입 취소 응답 명령어
  public static final String PG_PURCHASE_CANCEL_RESPONSE_COMMAND = "9301";
  
  // 카드 부분 매입 취소 (취소 구분)
  public static final String PG_PART_PURCHASE_CANCEL_REQUEST_REQUIRE_TYPE = "0000";
  // 카드 부분 매입 취소 (취소 구분) - 나머지 전체 취소
  public static final String PG_REMAINDER_PART_PURCHASE_CANCEL_REQUEST_REQUIRE_TYPE = "1000";
  
  // 카드 부분 매입 취소 응답 명령어
   public static final String PG_PART_PURCHASE_CANCEL_RESPONSE_COMMAND = "9011";

  
  // CMS-----------------------------------
  public static final String PG_REAL_CMS_BANK_ACCOUNT_SEARCH_TELEGRAM_CODE = "1000";
  public static final String PG_REAL_CMS_BANK_ACCOUNT_SEARCH_PROCESS_CODE = "300";
  
  public static final String PG_REAL_MEMBER_PROOF_APPLY_TELEGRAM_CODE = "1000";
  public static final String PG_REAL_MEMBER_PROOF_APPLY_PROCESS_CODE = "100";
  
  public static final String PG_REAL_MEMBER_PROOF_SEARCH_TELEGRAM_CODE = "1000";
  public static final String PG_REAL_MEMBER_PROOF_SEARCH_PROCESS_CODE = "200";
  
  public static final String PG_REAL_MEMBER_PROOF_CANCEL_TELEGRAM_CODE = "1000";
  public static final String PG_REAL_MEMBER_PROOF_CANCEL_PROCESS_CODE = "300";
  
}
