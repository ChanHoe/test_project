package com.kids.schole.common.util;

import java.lang.reflect.Field;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DomainUtil은 VO, Map에 있는 데이터를 보여주는 역할을 하는 클래스입니다.
 * 
 * @version 1.0 2016.11.19
 * @author Jeongho Baek
 */
public class DomainUtil {

  /** 로거를 위한 변수 입니다. */
  private final static Logger logger = LoggerFactory.getLogger(DomainUtil.class);

  @SuppressWarnings("unchecked")
  public static void retriveDomain(Object domainObject) {

    logger.debug("=================================================");
    if (domainObject instanceof Map) {
      Map<String, Object> mapobject = (Map<String, Object>) domainObject;
      for (String mapkey : mapobject.keySet()) {
        logger.debug("key: {}, value: {} ", mapkey, mapobject.get(mapkey));
      }
    } else {
      try {
        Object obj = domainObject;
        for (Field field : obj.getClass().getDeclaredFields()) {
          field.setAccessible(true);
          Object value = field.get(obj);
          logger.debug("{} : {}", field.getName(), value);
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    logger.debug("=================================================");

  }

}
