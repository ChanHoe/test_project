package com.kids.schole.common.util;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
*
* FormatUtil 는 Format관리하는 클래스이다.
*
* @author GIL. K
* @version 2015.05.20 / 1.0
*/
public class FormatUtil {

    /**
     *
     * matchFormat
     *
     * @param str String Value
     * @param format Format
     * @return String
     */
    public static String matchFormat(String str, String format) {
        if(str == null || str.length() == 0 ) return str;
        int len = format.length();
        char[] result = new char[len];
        for(int i=0,j=0; i<len; i++,j++) {
            if(format.charAt(i)=='#') {
                try {
                    result[i]= str.charAt(j);
                }catch(StringIndexOutOfBoundsException e) {
                    result[i]= '\u0000';
                }
            } else {
                result[i]= format.charAt(i);
                j--;
            }
        }
        return new String(result);
    }

    /**
     *
     * releaseFormat
     *
     * @param str String Value
     * @param format Format
     * @return String
     */
    public static String releaseFormat(String str, String format) {
        if(str == null || str.length() == 0 ) return str;
        int len = format.length();
        char[] result = new char[len];
        for(int i=0,j=0; i<len; i++,j++) {
            if(format.charAt(i)=='#') {
                try {
                    result[j] = str.charAt(i);
                }catch(StringIndexOutOfBoundsException e) {
                    result[j]= '\u0000';
                }
            } else {
                j--;
            }
        }
        return (new String(result)).trim();
    }

    /**
     *
     * matchFormat
     *
     * @param dt 날짜
     * @param format Format
     * @return String
     */
    public static String matchFormat(Date dt, String format) {
        if (dt == null) return "";
        try {
            return new SimpleDateFormat(format).format(dt);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return "invalid format";
    }

    /**
     *
     * PointFormat
     *
     * @param arg
     * @param pointDigit
     * @return String
     */
    public static String toPointFormat(double arg, int pointDigit) {
        if (pointDigit<=0) {
            return new DecimalFormat("##0").format(arg);
        } else {
            String formatStr = "##0.";
            formatStr +=pointDigit;
            return new DecimalFormat(formatStr).format(arg);
        }
    }

    /**
     *
     * DateFormat
     *
     * @param str String Value
     * @return Date
     */
    public static Date toDate(String str) {
        if(str == null || str.length() == 0 ) return null;
        String format = (str.length()==8)? "yyyyMMdd":(str.indexOf("-")>=0)? "yyyy-MM-dd":"yyyy/MM/dd";
        try {
            return new SimpleDateFormat(format).parse(str);
        } catch (ParseException ex) { return null; }
    }
}