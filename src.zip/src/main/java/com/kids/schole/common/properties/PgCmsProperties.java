package com.kids.schole.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "cms")
public class PgCmsProperties {

  private String domain;
  private String companyId;
  private String companyPassword;
  private String swId;
  private String swPassword;
  private String realMemberProofIp;
  private int realMemberProofPort;
  private int batchMemberApplyPort;
  private int batchPaymentApplyPort;
  private int realCmsAccountSearchPort;

  public String getDomain() {
    return domain;
  }

  public void setDomain(String domain) {
    this.domain = domain;
  }

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public String getCompanyPassword() {
    return companyPassword;
  }

  public void setCompanyPassword(String companyPassword) {
    this.companyPassword = companyPassword;
  }

  public String getSwId() {
    return swId;
  }

  public void setSwId(String swId) {
    this.swId = swId;
  }

  public String getSwPassword() {
    return swPassword;
  }

  public void setSwPassword(String swPassword) {
    this.swPassword = swPassword;
  }
 
  public String getRealMemberProofIp() {
    return realMemberProofIp;
  }

  public void setRealMemberProofIp(String realMemberProofIp) {
    this.realMemberProofIp = realMemberProofIp;
  }

  public int getRealMemberProofPort() {
    return realMemberProofPort;
  }

  public void setRealMemberProofPort(int realMemberProofPort) {
    this.realMemberProofPort = realMemberProofPort;
  }

  public int getBatchMemberApplyPort() {
    return batchMemberApplyPort;
  }

  public void setBatchMemberApplyPort(int batchMemberApplyPort) {
    this.batchMemberApplyPort = batchMemberApplyPort;
  }

  public int getBatchPaymentApplyPort() {
    return batchPaymentApplyPort;
  }

  public void setBatchPaymentApplyPort(int batchPaymentApplyPort) {
    this.batchPaymentApplyPort = batchPaymentApplyPort;
  }

  public int getRealCmsAccountSearchPort() {
    return realCmsAccountSearchPort;
  }

  public void setRealCmsAccountSearchPort(int realCmsAccountSearchPort) {
    this.realCmsAccountSearchPort = realCmsAccountSearchPort;
  }
  
}