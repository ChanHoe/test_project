package com.kids.schole.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * PgCreditCardInitData은 PG 관련 초기화 데이터를 세팅한다. 세팅값은 classpath:config/payment.yml 또는
 * config/payment-release.yml에 정의되어 있다.
 * 
 * @version 1.0 2016.11.19
 * @author Jeongho Baek
 */
@Component
@ConfigurationProperties(prefix = "creditCard")
public class PgCreditCardProperties {

  private String version;
  private String serviceId;
  private String itemCode;
  private String dealTypeCE;
  private String dealTypeCES;
  private String certType;
  private String usingType;
  private String currency;
  private String opcode;

  private String cpaAdminUrl;
  private String cpaAgentId;
  private String cpaMerchantId;
  private String cpaAdminPassword;

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getServiceId() {
    return serviceId;
  }

  public void setServiceId(String serviceId) {
    this.serviceId = serviceId;
  }

  public String getItemCode() {
    return itemCode;
  }

  public void setItemCode(String itemCode) {
    this.itemCode = itemCode;
  }

  public String getDealTypeCE() {
    return dealTypeCE;
  }

  public void setDealTypeCE(String dealTypeCE) {
    this.dealTypeCE = dealTypeCE;
  }

  public String getDealTypeCES() {
    return dealTypeCES;
  }

  public void setDealTypeCES(String dealTypeCES) {
    this.dealTypeCES = dealTypeCES;
  }

  public String getCertType() {
    return certType;
  }

  public void setCertType(String certType) {
    this.certType = certType;
  }

  public String getUsingType() {
    return usingType;
  }

  public void setUsingType(String usingType) {
    this.usingType = usingType;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getOpcode() {
    return opcode;
  }

  public void setOpcode(String opcode) {
    this.opcode = opcode;
  }

  public String getCpaAdminUrl() {
    return cpaAdminUrl;
  }

  public void setCpaAdminUrl(String cpaAdminUrl) {
    this.cpaAdminUrl = cpaAdminUrl;
  }

  public String getCpaAgentId() {
    return cpaAgentId;
  }

  public void setCpaAgentId(String cpaAgentId) {
    this.cpaAgentId = cpaAgentId;
  }

  public String getCpaMerchantId() {
    return cpaMerchantId;
  }

  public void setCpaMerchantId(String cpaMerchantId) {
    this.cpaMerchantId = cpaMerchantId;
  }

  public String getCpaAdminPassword() {
    return cpaAdminPassword;
  }

  public void setCpaAdminPassword(String cpaAdminPassword) {
    this.cpaAdminPassword = cpaAdminPassword;
  }

}