package com.kids.schole.common.util;

import java.util.Map;
import java.util.Random;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class ApiKeyUtil {
	
	private final static String[] API_KEY = { "A3JR7sXQN7","ssxnV14Taj","t+x8Nf4+XJ","pZwfcneoCG","qxgdv+20iZ","A22iK1iQre","LaEGfkCwPp","fc4K7GdmIG","pUNWV8F1zt","LcBUYozKLT" };

	/*******************************************************************************************************/
	public static String[] getAPI_KEY () {
		return API_KEY;
	}
	/*******************************************************************************************************/
	public static int getSeed () {
		
		return new Random().nextInt(9);
	}
	/*******************************************************************************************************/
	public static long getTimeStamp () {
		
		return System.currentTimeMillis() / 1000;
	}
	/*******************************************************************************************************/
	public static String getFingerPrintForObjectMap(
			Map<String, Object>		params,
			int						seed
	) {
		StringBuilder paramString = new StringBuilder();
		for (String entry : params.keySet()) {
			
			Object obj = params.get(entry);
			String value = null;
			
			if(obj instanceof Integer)	       	value = String.valueOf(obj);
	        if(obj instanceof Long)	        	value = String.valueOf(obj);
	        if(obj instanceof String)	       	value = (String) obj;
	        
			if( null != value )
				paramString.append( value );
		}
		return encryption( seed, paramString.toString() );
	}
	/*******************************************************************************************************/
	public static String getFingerPrint(
			Map<String, String>		params,
			int						seed
	) {
		StringBuilder paramString = new StringBuilder();
		for (String entry : params.keySet()) {
			
			String obj = params.get(entry);
			paramString.append( obj );
			
		}
		return encryption( seed, paramString.toString() );
	}
	/*******************************************************************************************************/
	public static synchronized String encryption(int seed, String message) {
		
		try {		
			String secret = API_KEY[seed];
			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
			sha256_HMAC.init(secret_key);

			String hash = Base64.encodeBase64String(sha256_HMAC.doFinal(message.getBytes()));
			return hash;
			
		} catch (Exception e) {
			throw new IllegalArgumentException("API encryption Exception");
		}	
		
	}
	/*******************************************************************************************************/
	public static void setTimeStampFingerPrintSeedForObjectMap(
			Map<String, Object>		params
	) {
		int seed = getSeed();
		params.put("timestamp"		, String.valueOf( getTimeStamp() ) );
		
		String fingerPrint = getFingerPrintForObjectMap( params, seed );
		
		params.put("seed"			, String.valueOf(seed));
		params.put("fingerprint"	, fingerPrint);
	}
	/*******************************************************************************************************/
	public static void setTimeStampFingerPrintSeed(
			Map<String, String>		params
	) {
		int seed = getSeed();
		params.put("timestamp"		, String.valueOf( getTimeStamp() ) );
		
		String fingerPrint = getFingerPrint( params, seed );
		
		params.put("seed"			, String.valueOf(seed));
		params.put("fingerprint"	, fingerPrint);
	}
	/*******************************************************************************************************/
}
