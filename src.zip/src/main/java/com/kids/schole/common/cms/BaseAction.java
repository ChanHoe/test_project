package com.kids.schole.common.cms;

public interface BaseAction {

  public int connect(String ip, int port);

  public boolean sendData(String data);

  public byte[] recvData();

  public int close();
  
}
