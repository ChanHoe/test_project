package com.kids.schole.common.constant;

public class PaymentConst {

  // Card_payment_request - pg_code (공통 코드) : 효성
  public static final String PG_CODE_HYOSUNG = "hyosung";
  // 공통코드 상태 - 대기
  public static final String REQUEST_STATUS_READY = "ready";
  // 공통코드 상태 - 승인
  public static final String REQUEST_STATUS_APPROVAL = "approval";
  // 공통코드 상태 - 승인실패
  public static final String REQUEST_STATUS_APPROVAL_FAIL = "app-fail";
  // 공통코드 상태 - 승인취소
  public static final String REQUEST_STATUS_APPROVAL_CANCEL = "app-cancel";
  // 공통 코드 상태 - 매입
  public static final String REQUEST_STATUS_PURCHASE = "purchase";
  // 공통 코드 상태 - 매입 실패
  public static final String REQUEST_STATUS_PURCHASE_FAIL = "pur-fail";
  // 공통 코드 상태 - 매입 취소
  public static final String REQUEST_STATUS_PURCHASE_CANCEL = "pur-cancel";
  // 공통 코드 상태 - 부분 매입 취소
  public static final String REQUEST_STATUS_PURCHASE_PART_CANCEL = "pur-part-cancel";

  public static final String REQUEST_STATUS_WAIT = "wait";
  // 공통코드 상태 - 요청
  public static final String REQUEST_STATUS_REQUEST = "request";
  // 공통코드 상태 - 미수
  public static final String REQUEST_STATUS_UNPAID = "unpaid";
  // 공통코드 상태 - 완료
  public static final String REQUEST_STATUS_DONE = "done";
  // 공통코드 상태 - 취소
  public static final String REQUEST_STATUS_CANCEL = "cancel";

  // 공통코드 상태 - 대기
  public static final String ALLOT_STATUS_READY = "ready";
  // 공통코드 상태 - 배분
  public static final String ALLOT_STATUS_ALLOT = "allot";
  // 공통코드 상태 - 완료
  public static final String ALLOT_STATUS_DONE = "done";

  // 공통코드 상태 - 통합
  public static final String COMBINE_STATUS_COMBINE = "combine";
  // 공통코드 상태 - 취소
  public static final String COMBINE_STATUS_CANCEL = "cancel";

  // PG 요청 타입 : 승인
  public static final String PG_TRANSACTION_TYPE_APPROVAL = "approval";
  // PG 요청 타입 : 승인 취소
  public static final String PG_TRANSACTION_TYPE_APPROVAL_CANCEL = "app-cancel";
  // PG 요청 타입 : 매입
  public static final String PG_TRANSACTION_TYPE_PURCAHSE = "purchase";
  // PG 요청 타입 : 매입 취소
  public static final String PG_TRANSACTION_TYPE_PURCHASE_CANCEL = "pur-cancel";
  // PG 요청 타입 : 부분 매입 취소
  public static final String PG_TRANSACTION_TYPE_PURCHASE_PART_CANCEL = "pur-part-cancel";

  // 가상계좌 : 입급대기, 입금 되어야 접수
  public static final String ORDER_STATUS_CBBK_READY = "cbbk-ready";
  // 접수 (카드 승인, 가상계좌 입금, 즉시출금 입금)
  public static final String ORDER_STATUS_ACCEPTED = "accepted";

  // 결제완료 (계좌완료, 매입)
  public static final String PAY_STATUS_DONE = "done";

  // 고객별 가상계좌 여부 - 사용
  public static final String USE = "use";
  // 고객별 가상계좌 여부 - 미사용
  public static final String NOT_USE = "not_use";

  // 할부요청 회원신청유형
  public static final String INSTALLMENT_PAYMENT_REQUEST_APPLICATION_TYPE_NEW = "new";
  public static final String INSTALLMENT_PAYMENT_REQUEST_APPLICATION_TYPE_MODIFY = "modify";
  public static final String INSTALLMENT_PAYMENT_REQUEST_APPLICATION_TYPE_DELETE = "delete";

  // 할부요청 회원신청상태
  public static final String INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_WAIT = "wait";
  public static final String INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_PROCESSING = "processing";
  public static final String INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_DONE = "done";
  public static final String INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_FAIL = "fail";

  /** 가상계좌 관련 */
  public static final String NEVER_ENDING_DATETIME = "9999-12-31";

  /** 메시지 관련 */

  // 가상계좌생성에서 sms발송되는 내용
  public static final String SMS_MSG_CUSTOMER_CBBK = "[ST Unitas] [NAME]님의 전용계좌번호는 [BANKNAME] [BANKACCOUNT] 입니다.";

  // 가상계좌통합처리에서 sms발송되는 내용
  public static final String SMS_MSG_CUSTOMER_PAYMENT_AMT = "[ST Unitas] [NAME]님 [PAYMENTAMT]원을 [BANKNAME] [BANKACCOUNT]계좌로 입금바랍니다.";

  // --------------------------------------------------------------------------------------------------------------
  // 현금영수증 관련

  /** 배치유형 : 발행요청 */
  public static final String CASH_RECEIPT_BATCH_REQUEST_TYPE_ISSUE = "issue";
  /** 배치유형 : 결과조회 */
  public static final String CASH_RECEIPT_BATCH_REQUEST_TYPE_RESULT = "result";

  /** 배치 결과조회 : 배치 결과 요청 */
  public static final String CASH_RECEIPT_BATCH_RESULT_TYPE_BATCH = "01";
  /** 배치 결과조회 : 현금영수증 결과 요청 */
  public static final String CASH_RECEIPT_BATCH_RESULT_TYPE_RECEIPT = "02";

  /** 거래구분 : 승인거래 */
  public static final String CASH_RECEIPT_DEAL_TYPE_ISSUE = "approval";
  /** 거래구분 : 취소거래 */
  public static final String CASH_RECEIPT_DEAL_TYPE_CANCEL = "cancel";

  /** 거래자 구분 : 소비자 소득공제용 */
  public static final String CASH_RECEIPT_USING_TYPE_INCOME_TAX_DEDUCTION = "0";
  /** 거래자 구분 : 사업자 지출증빙용 */
  public static final String CASH_RECEIPT_USING_TYPE_EXPENSE_EVIDENCE = "1";

  /** 현금영수증 발행 타입 : 주민번호 */
  public static final String CASH_RECEIPT_IDENTIFIER_TYPE_RESIDENT_REGISTRATION_NUMBER = "10";
  /** 현금영수증 발행 타입 : 핸드폰번호 */
  public static final String CASH_RECEIPT_IDENTIFIER_TYPE_MOBILE_NUMBER = "20";
  /** 현금영수증 발행 타입 : 사업자번호 */
  public static final String CASH_RECEIPT_IDENTIFIER_TYPE_CORPORATE_REGISTRATION_NUMBER  = "30";
  /** 현금영수증 발행 타입 : 카드번호 */
  public static final String CASH_RECEIPT_IDENTIFIER_TYPE_CARD_NUMBER  = "40";

  /** 사업자 유형 : 일반 */
  public static final int CASH_RECEIPT_CORPORATE_TYPE_GENERAL  = 1;
  /** 사업자 유형 : 간이 */
  public static final int CASH_RECEIPT_CORPORATE_TYPE_EASY  = 2;
  /** 사업자 유형 : 기타 */
  public static final int CASH_RECEIPT_CORPORATE_TYPE_ETC  = 3;
  /** 사업자 유형 : 면세 */
  public static final int CASH_RECEIPT_CORPORATE_TYPE_TAX_FREE = 4;
  /** 사업자 유형 : 법인 */
  public static final int CASH_RECEIPT_CORPORATE_TYPE_CORPORATE = 5;

  /** 취소사유 : 거래취소 */
  public static final String CASH_RECEIPT_CANCEL_REASON_GENERAL = "cancel_deal";
  /** 취소사유 : 오류발급 */
  public static final String CASH_RECEIPT_CANCEL_REASON_ERROR = "cancel_error";
  /** 취소사유 : 기타 */
  public static final String CASH_RECEIPT_CANCEL_REASON_ETC = "cancel_etc";

  /** 발행유형 : 신규 */
  public static final String CASH_RECEIPT_ISSUE_TYPE_NEW = "cash_new";
  /** 발행유형 : 누락 */
  public static final String CASH_RECEIPT_ISSUE_TYPE_MISSING = "cash_missing";
  /** 발행유형 : 정정 */
  public static final String CASH_RECEIPT_ISSUE_TYPE_CORRECTION = "cash_correction";
  /** 발행유형 : 취소 */
  public static final String CASH_RECEIPT_ISSUE_TYPE_CANCEL = "cash_cancel";
  /** 발행유형 : 오류 */
  public static final String CASH_RECEIPT_ISSUE_TYPE_ERROR = "cash_error";

  /** 결제방법 : 가상계좌 */
  public static final String CASH_RECEIPT_PAY_TYPE_CBBK = "cbbk";
  /** 결제방법 : 즉시출금 */
  public static final String CASH_RECEIPT_PAY_TYPE_CMS = "cms";
  /** 결제방법 : 할부 계좌이체 */
  public static final String CASH_RECEIPT_PAY_TYPE_BANK = "bank";
  /** 결제방법 : 가상계좌(대체결제) */
  public static final String CASH_RECEIPT_PAY_TYPE_CBBK_SUB = "cbbk_sub";
  /** 결제방법 : 즉시출금(대체결제) */
  public static final String CASH_RECEIPT_PAY_TYPE_CMS_SUB = "cms_sub";
  /** 결제방법 : 은행이체(낱권유상용. 임시) */
  public static final String CASH_RECEIPT_PAY_TYPE_BANK_SINGLE_COPY = "bank_sc";

  /** 요청상태 : 준비(ready) */
  public static final String CASH_RECEIPT_REQUEST_STATUS_READY = "ready";
  /** 요청상태 : 진행중(processing) */
  public static final String CASH_RECEIPT_REQUEST_STATUS_PROCESSING = "processing";
  /** 요청상태 : 실패(fail) */
  public static final String CASH_RECEIPT_REQUEST_STATUS_FAIL = "fail";
  /** 요청상태 : 성공(success) */
  public static final String CASH_RECEIPT_REQUEST_STATUS_SUCCESS = "success";

  /** 성공 */
  public static final String CASH_RECEIPT_SUCCESS = "성공";
  /** 성공코드 */
  public static final String CASH_RECEIPT_SUCCESS_CODE = "0000";
  /** 승인성공 */
  public static final String CASH_RECEIPT_REQUEST_SUCCESS = "승인성공";
  /** 실패 */
  public static final String CASH_RECEIPT_REQUEST_FAIL = "실패";

}
