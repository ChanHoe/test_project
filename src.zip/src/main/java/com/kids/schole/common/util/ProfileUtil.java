package com.kids.schole.common.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * ProfileUtil은 Sprign 환경설정에서 Profile 관련 유틸 클래스입니다.
 * 
 * @version 1.0 2016.11.19
 * @author Jeongho Baek
 */
@Component
public class ProfileUtil {

  private static Environment environment;

  @Autowired
  @SuppressWarnings("static-access")
  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  /**
   * 현재 Spring profile을 읽어서 실서버인지 아닌지 체크한다.
   *
   * @return boolean 실서버 판단값
   */
  public static boolean isRelease() {

    boolean releaseFlag = false;

    for (String profile : environment.getActiveProfiles()) {
      if (profile.equals("release")) {
        releaseFlag = true;
        break;
      }
    }

    return releaseFlag;

  }

  /**
   * 현재 Spring profile을 반환한다..
   *
   * @return String profile설정
   */
  public static String getActiveProfile() {

    String activeProfile = "";

    for (String profile : environment.getActiveProfiles()) {
      if (profile.equals("local")) {
        activeProfile = "local";
        break;
      } else if (profile.equals("dev")) {
        activeProfile = "dev";
        break;
      } else if (profile.equals("qa")) {
        activeProfile = "qa";
        break;
      } else if (profile.equals("release")) {
        activeProfile = "release";
        break;
      } else {
        activeProfile = "local";
        break;
      }
    }

    return activeProfile;

  }


}
