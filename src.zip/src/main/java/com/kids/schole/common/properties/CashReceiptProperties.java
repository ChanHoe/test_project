package com.kids.schole.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "cash")
public class CashReceiptProperties {

  /** 프로토콜 버전 */
  private String protocolVersion;
  /** 가맹점 ID(연계형) */
  private String mid;
  /** 가맹점 ID(비연계형) */
  private String mid2;
  /** 서비스코드 */
  private String serviceCode;
  /** 암호화 키 */
  private String encryptKey;
  /** 암호화 IV */
  private String encryptIv;
  /** 배치파일 경로(요청) */
  private String requestFilePath;
  /** 배치파일 경로(응답) */
  private String responseFilePath;


  public String getProtocolVersion() {
    return protocolVersion;
  }
  public void setProtocolVersion(String protocolVersion) {
    this.protocolVersion = protocolVersion;
  }
  public String getMid() {
    return mid;
  }
  public void setMid(String mid) {
    this.mid = mid;
  }
  public String getServiceCode() {
    return serviceCode;
  }
  public void setServiceCode(String serviceCode) {
    this.serviceCode = serviceCode;
  }
  public String getEncryptKey() {
    return encryptKey;
  }
  public void setEncryptKey(String encryptKey) {
    this.encryptKey = encryptKey;
  }
  public String getEncryptIv() {
    return encryptIv;
  }
  public void setEncryptIv(String encryptIv) {
    this.encryptIv = encryptIv;
  }
  public String getRequestFilePath() {
    return requestFilePath;
  }
  public void setRequestFilePath(String requestFilePath) {
    this.requestFilePath = requestFilePath;
  }
  public String getResponseFilePath() {
    return responseFilePath;
  }
  public void setResponseFilePath(String responseFilePath) {
    this.responseFilePath = responseFilePath;
  }
  public String getMid2() {
    return mid2;
  }
  public void setMid2(String mid2) {
    this.mid2 = mid2;
  }



}