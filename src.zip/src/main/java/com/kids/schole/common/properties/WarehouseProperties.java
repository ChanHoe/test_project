package com.kids.schole.common.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "warehouse")
public class WarehouseProperties {

  private String url;
  private String bizCode;
  private String senderName;
  private String senderTel;
  private String senderAddr;
  private String trackingUrl;

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getBizCode() {
    return bizCode;
  }

  public void setBizCode(String bizCode) {
    this.bizCode = bizCode;
  }

  public String getSenderName() {
    return senderName;
  }

  public void setSenderName(String senderName) {
    this.senderName = senderName;
  }

  public String getSenderTel() {
    return senderTel;
  }

  public void setSenderTel(String senderTel) {
    this.senderTel = senderTel;
  }

  public String getSenderAddr() {
    return senderAddr;
  }

  public void setSenderAddr(String senderAddr) {
    this.senderAddr = senderAddr;
  }

  public String getTrackingUrl() {
    return trackingUrl;
  }

  public void setTrackingUrl(String trackingUrl) {
    this.trackingUrl = trackingUrl;
  }

}
