package com.kids.schole.common.cms.util;

public class CmsErrorCode {

  public static String getErrorMessage(String errorCode) {

    String errorMessage = "";
    
    switch(errorCode) {
      case "R000" :
        errorMessage = "정상";
        break;
      case "R001" :
        errorMessage = "업체아이디인증실패";
        break;
      case "R002" :
        errorMessage = "송신일자오류";
        break;
      case "R003" :
        errorMessage = "미처리업무";
        break;
      case "R004" :
        errorMessage = "기처리요청건(중복연번)";
        break;
      case "R005" :
        errorMessage = "미처리은행";
        break;
      case "R006" :
        errorMessage = "계좌번호입력오류";
        break;
      case "R007" :
        errorMessage = "생년월일/사업자번호오류";
        break;
      case "R010" :
      case "R999" :
        errorMessage = "내부오류";
        break;
      case "R011" :
        errorMessage = "업체상태오류";
        break;
      case "R021" :
        errorMessage = "프로그램업체인증실패";
        break;
      case "R333" :
        errorMessage = "포맷오류";
        break;
      case "R055" :
        errorMessage = "요청처리실패";
        break;
      case "R066" :
        errorMessage = "수신실패";
        break;
      case "R077" :
        errorMessage = "처리중";
        break;
      case "R402" :
        errorMessage = "은행코드입력오류";
        break;
      case "R991" :
        errorMessage = "업무시간외 거래";
        break;
      case "NH01" :
        errorMessage = "전문길이오류";
        break;
      case "NH02" :
        errorMessage = "전문포맷오류";
        break;
      case "NH03" :
        errorMessage = "계좌번호입력오류";
        break;
      case "NH04" :
        errorMessage = "생년월일/사업자번호입력오류";
        break;
      case "NH06" :
      case "NH12" :
      case "NH13" :
      case "NH14" :
      case "NH21" :
      case "NH22" :
      case "NH23" :
        errorMessage = "전문포맷오류";
        break;
      case "NH07" :
      case "NH19" :
        errorMessage = "내부오류";
        break;
      case "NH09" :
        errorMessage = "결과수신실패";
        break;
      case "NH10" :
        errorMessage = "처리일자오류";
        break;
      case "NH11" :
        errorMessage = "처리구분오류";
        break;
      case "NH20" :
        errorMessage = "미처리업무";
        break;
      case "NH77" :
        errorMessage = "이중출금신청";
        break;
      case "NH99" :
        errorMessage = "전송실패(내부오류)";
        break;
      case "0000" :
        errorMessage = "정상";
        break;
      case "1001" :
        errorMessage = "계좌번호오류";
        break;
      case "1002" :
        errorMessage = "해지/이관계좌";
        break;
      case "1003" :
        errorMessage = "1종사고계좌";
        break;
      case "1004" :
        errorMessage = "2종사고계좌";
        break;
      case "1005" :
        errorMessage = "해당계좌없음";
        break;
      case "1006" :
        errorMessage = "증명원발급";
        break;
      case "1007" :
        errorMessage = "법적제한계좌";
        break;
      case "1009" :
        errorMessage = "기타수취불가계좌";
        break;
      case "1010" :
        errorMessage = "비밀번호오류횟수초과";
        break;
      case "2001" :
        errorMessage = "생년월일/사업자번호불일치";
        break;
      case "2002" :
        errorMessage = "실명미등록계좌";
        break;
      case "9001" :
        errorMessage = "생년월일/사업자번호불일치";
        break;
      case "9002" :
        errorMessage = "은행시스템장애";
        break;
      case "9003" :
        errorMessage = "은행연동장애";
        break;
      case "9999" :
        errorMessage = "기타오류";
        break;
      default :
        errorMessage = "알수없는오류";
    }
    
    return errorMessage;
    
  }
  
}
