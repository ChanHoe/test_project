package com.kids.schole.common.util;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Random;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import com.kids.schole.common.constant.WarehouseConst;


public class WarehouseUtil {

  public static int getSeed() {
    return new Random().nextInt(9);
  }

  public static String getTimeStamp() {
    return String.valueOf(System.currentTimeMillis() / 1000);
  }

  public static Map<String, String> setTimeStampNFingerPrint(Map<String, String> warehouseMap) {

    int seed = new Random().nextInt(9);
    long timestamp = System.currentTimeMillis() / 1000;

    warehouseMap.put("timestamp", String.valueOf(timestamp));
    warehouseMap.put("fingerprint", getFingerPrint(warehouseMap, seed));
    warehouseMap.put("seed", String.valueOf(seed));

    return warehouseMap;

  }

  public static String getFingerPrint(Map<String, String> warehouseMap, int seed) {

    StringBuilder paramString = new StringBuilder();
    for (String entry : warehouseMap.keySet()) {
      paramString.append(warehouseMap.get(entry));
    }
    return encryption(seed, paramString.toString());
  }

  private static String encryption(int seed, String message) {

    String secret = WarehouseConst.API_KEY[seed];
    Mac sha256HMAC;
    String hash = "";

    try {
      sha256HMAC = Mac.getInstance("HmacSHA256");
      SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
      sha256HMAC.init(secretKey);
      hash = Base64.encodeBase64String(sha256HMAC.doFinal(message.getBytes()));
      return hash.trim();
    } catch (NoSuchAlgorithmException | InvalidKeyException e) {
      e.printStackTrace();
    }

    return hash.trim();

  }

  public static String getPaymentDateForDelay(String paymentTime) {

    Date now = new Date();
    Date paymentDate = null;

    try {
      paymentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(paymentTime);
    } catch (ParseException pe) {
      pe.printStackTrace();
    }

    long diff = now.getTime() - paymentDate.getTime();
    long diffHours = diff / (60 * 60 * 1000);

    if (diffHours > 0) {
      return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(now);
    } else {
      return paymentTime;
    }

  }

}
