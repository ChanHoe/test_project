package com.kids.schole.common.constant;

public class WarehouseConst {

  public static final String[] API_KEY = {"A3JR7sXQN7", "ssxnV14Taj", "t+x8Nf4+XJ", "pZwfcneoCG",
      "qxgdv+20iZ", "A22iK1iQre", "LaEGfkCwPp", "fc4K7GdmIG", "pUNWV8F1zt", "LcBUYozKLT"};

  // 센터 관련 API URL GET방식
  public static final String WAREHOUSE_LISTS_URL = "/warehouse/lists";
  // 컨텐츠 관련 조회 API URL GET방식
  public static final String CONTENT_RECORD_URL = "/contents/record";
  // 컨텐츠 관련 목록 조회 API URL GET방식
  public static final String CONTENT_LISTS_URL = "/contents/record";
  // 컨텐츠 관련 형태조회 API URL GET방식
  public static final String CONTENT_TYPE_LISTS_URL = "/contents/type_lists";
  // 컨텐츠 관련 입고 API URL POST방식
  public static final String CONTENT_STORE_URL = "/contents/store";
  // 컨텐츠 관련 출고 API URL POST방식
  public static final String CONTENT_RELEASE_URL = "/contents/release";

  // 배송 정보 관련 배송 정보 등록 API URL POST 방식
  public static final String DELIVERY_INSERT_URL = "/delivery/insert";

  // 배송 정보 관련 배송 취소
  public static final String RECEPTION_RETURN_CONTENTS_URL = "/reception/return_contents";

  public static final String INVOICE_CJ = "/invoice/CJ/";
}
