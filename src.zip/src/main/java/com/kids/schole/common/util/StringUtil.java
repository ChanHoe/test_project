package com.kids.schole.common.util;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class StringUtil extends org.apache.commons.lang3.StringUtils {

	/**
    *
    * 문자열 특정기호로 나누기 (빈값은 삭제)
    * 3/3///3 ==> String[3]
    * @param str String value
    * @param delim 구분자
    * @return String[]
    */
   public static String[] split(String str, String delim) {
   	if(str == null){
   		return new String[0];
   	}

       StringTokenizer token = new StringTokenizer(str, delim);
       String[] result = new String[token.countTokens()];

       for (int i = 0; token.hasMoreTokens(); i++) {
           result[i] = token.nextToken();
       }

       return result;
   }

   /**
    *
    * 문자열 특정기호로 나누기
    *
    * @param str String value
    * @param delim 구분자
    * @return List<String>
    */
   public static List<String> split2Iterate(String str, String delim) {
       List<String> result = new ArrayList<String>();

       if(isNull(str))
       	return result;

       StringTokenizer token = new StringTokenizer(str, delim);
       for (; token.hasMoreTokens();) {
           result.add( token.nextToken() );
       }

       return result;
   }

	/**
	 *
	 * null 여부 체크
	 *
	 * @param str 문자열
	 * @return boolean
	 */
	public static boolean isNull(String str) {
		return (str == null || "".equals(str))? true:false;
	}

	/**
	 *
	 * null 여부 체크
	 *
	 * @param str Object 객체
	 * @return boolean
	 */
	public static boolean isNull(Object str) {
		return (str == null || "".equals(str))? true:false;
	}


   	/**
   	 *
   	 * String -> int 변환
   	 *
   	 * @param arg String value
   	 * @return int
   	 */
   	public static int toInt(String arg) { return toInt(arg, 0); }

   	/**
  	 *
  	 * String -> int 변환
  	 *
  	 * @param intStr String value
  	 * @param initValue 디폴트 value
  	 * @return int
  	 */
  	public static int toInt(String intStr, int initValue) {
  		int retInt = initValue;
  		try {
  			if (intStr != null && intStr.trim().length() > 0) {
  				retInt = Integer.parseInt(intStr.trim());
  			}
  		} catch (NumberFormatException e) {}
  		return retInt;
  	}
}
