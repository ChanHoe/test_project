package com.kids.schole.common.constant;

public class IConst {

	// 시스템 구분
	public static String CONF_SYSTEM_TYPE;
}
