package com.kids.schole.common.util;

import java.util.Random;

/**
 * MathUtil은 수학 관련 유틸리티 클래스입니다.
 * 
 * @version 1.0 2016.11.19
 * @author Jeongho Baek
 */
public class MathUtil {

  /**
   * 절상, 절하, 반올림 처리
   * 
   * @param strMode - 수식
   * @param nCalcVal - 처리할 값(소수점 이하 데이터 포함)
   * @param nDigit - 연산 기준 자릿수(오라클의 ROUND함수 자릿수 기준) -2:십단위 , -1:원단위 , 0:소수점 1자리 , 1:소수점 2자리 , 2:소수점
   *        3자리 , 3:소수점 4자리 , 4:소수점 5자리 처리
   * @return double nCalcVal
   */
  public static double calcFigures(String strMode, double nCalcVal, int nDigit) {
    if ("CEIL".equals(strMode)) { // 절상
      if (nDigit < 0) {
        nDigit = -(nDigit);
        nCalcVal = Math.ceil(nCalcVal / Math.pow(10, nDigit)) * Math.pow(10, nDigit);
      } else {
        nCalcVal = Math.ceil(nCalcVal * Math.pow(10, nDigit)) / Math.pow(10, nDigit);
      }
    } else if ("FLOOR".equals(strMode)) { // 절하
      if (nDigit < 0) {
        nDigit = -(nDigit);
        nCalcVal = Math.floor(nCalcVal / Math.pow(10, nDigit)) * Math.pow(10, nDigit);
      } else {
        nCalcVal = Math.floor(nCalcVal * Math.pow(10, nDigit)) / Math.pow(10, nDigit);
      }
    } else { // 반올림
      if (nDigit < 0) {
        nDigit = -(nDigit);
        nCalcVal = Math.round(nCalcVal / Math.pow(10, nDigit)) * Math.pow(10, nDigit);
      } else {
        nCalcVal = Math.round(nCalcVal * Math.pow(10, nDigit)) / Math.pow(10, nDigit);
      }
    }
    return nCalcVal;
  }

  public static int getRandomNumber(int length) {

    String numStr = "1";
    String plusNumStr = "1";

    for (int i = 0; i < length; i++) {
      numStr += "0";

      if (i != length - 1) {
        plusNumStr += "0";
      }
    }

    Random random = new Random();
    int result = random.nextInt(Integer.parseInt(numStr)) + Integer.parseInt(plusNumStr);

    if (result > Integer.parseInt(numStr)) {
      result = result - Integer.parseInt(plusNumStr);
    }

    return result;
  }



}
