package com.kids.schole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@SpringBootApplication
@EnableScheduling
@Controller
public class KidsScholeBatchApplication {

  public static void main(String[] args) {
    SpringApplication.run(KidsScholeBatchApplication.class, args);
  }
  
  @RequestMapping(value = "/")
  public String index(Model model) throws Exception {
    return "redirect:/executeList";
  }
  
  @RequestMapping(value = "/executeList")
  public String orderMainIndex(Model model) throws Exception {
    return "/execute_list";
  }
  
}
