package com.kids.schole.batch.support.card.domain;

/**
 * CardPaymentRequest는 카드 결제 요청 클래스입니다.
 * 
 * @version 1.0 2016.11.14
 * @author Jeongwon Son
 */
public class CardPaymentRequest {

  private int cardPaymentRequestId;
  private int paymentId;
  private String pgCode;
  private String cardCode;
  private String cardName;
  private String cardNumber;
  private String expiredYear;
  private String expiredMonth;
  private int installmentPaymentCount;
  private long paymentAmt;
  private long refundAmt;
  private String payerName;
  private String payerNumber;
  private String payerRelation;
  private String requestStatus;
  private String registeredIp;
  private long authAmt;
  private String authDate;
  private int authNumber;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  // pg 연동 로그 - 필요한 값
  private String pgTransactionId;

  // 카드 접수 조회에 필요한 값
  private int orderId;
  private String payAction;
  private String orderNumber;
  private String requestStatusName;
  private String orderStatus;
  private String orderStatusName;
  private String name;
  private String orderRegisteredDatetime; // 원매출일자, 매출일자
  private String pgRegisteredDatetime; // 확정일자
  private String superOrganizationName; // 접수처명
  private String cdEmpName; // 접수자
  private String pgTransacionType;
  private String pgFailMsg; // 반송사유
  
  private int singleCopyOrderId;  // 낱권 주문id

  public int getCardPaymentRequestId() {
    return cardPaymentRequestId;
  }

  public void setCardPaymentRequestId(int cardPaymentRequestId) {
    this.cardPaymentRequestId = cardPaymentRequestId;
  }

  public int getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(int paymentId) {
    this.paymentId = paymentId;
  }

  public String getPgCode() {
    return pgCode;
  }

  public void setPgCode(String pgCode) {
    this.pgCode = pgCode;
  }

  public String getCardCode() {
    return cardCode;
  }

  public void setCardCode(String cardCode) {
    this.cardCode = cardCode;
  }

  public String getCardName() {
    return cardName;
  }

  public void setCardName(String cardName) {
    this.cardName = cardName;
  }

  public String getCardNumber() {
    return cardNumber;
  }

  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  public String getExpiredYear() {
    return expiredYear;
  }

  public void setExpiredYear(String expiredYear) {
    this.expiredYear = expiredYear;
  }

  public String getExpiredMonth() {
    return expiredMonth;
  }

  public void setExpiredMonth(String expiredMonth) {
    this.expiredMonth = expiredMonth;
  }

  public int getInstallmentPaymentCount() {
    return installmentPaymentCount;
  }

  public void setInstallmentPaymentCount(int installmentPaymentCount) {
    this.installmentPaymentCount = installmentPaymentCount;
  }

  public long getPaymentAmt() {
    return paymentAmt;
  }

  public void setPaymentAmt(long paymentAmt) {
    this.paymentAmt = paymentAmt;
  }

  public long getRefundAmt() {
    return refundAmt;
  }

  public void setRefundAmt(long refundAmt) {
    this.refundAmt = refundAmt;
  }

  public String getPayerName() {
    return payerName;
  }

  public void setPayerName(String payerName) {
    this.payerName = payerName;
  }

  public String getPayerNumber() {
    return payerNumber;
  }

  public void setPayerNumber(String payerNumber) {
    this.payerNumber = payerNumber;
  }

  public String getPayerRelation() {
    return payerRelation;
  }

  public void setPayerRelation(String payerRelation) {
    this.payerRelation = payerRelation;
  }

  public String getRequestStatus() {
    return requestStatus;
  }

  public void setRequestStatus(String requestStatus) {
    this.requestStatus = requestStatus;
  }

  public String getRegisteredIp() {
    return registeredIp;
  }

  public void setRegisteredIp(String registeredIp) {
    this.registeredIp = registeredIp;
  }

  public long getAuthAmt() {
    return authAmt;
  }

  public void setAuthAmt(long authAmt) {
    this.authAmt = authAmt;
  }

  public String getAuthDate() {
    return authDate;
  }

  public void setAuthDate(String authDate) {
    this.authDate = authDate;
  }

  public int getAuthNumber() {
    return authNumber;
  }

  public void setAuthNumber(int authNumber) {
    this.authNumber = authNumber;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public String getPgTransactionId() {
    return pgTransactionId;
  }

  public void setPgTransactionId(String pgTransactionId) {
    this.pgTransactionId = pgTransactionId;
  }

  public int getOrderId() {
    return orderId;
  }
  
  public String getPayAction() {
    return payAction;
  }

  public void setPayAction(String payAction) {
    this.payAction = payAction;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public String getOrderNumber() {
    return orderNumber;
  }

  public void setOrderNumber(String orderNumber) {
    this.orderNumber = orderNumber;
  }

  public String getRequestStatusName() {
    return requestStatusName;
  }

  public void setRequestStatusName(String requestStatusName) {
    this.requestStatusName = requestStatusName;
  }

  public String getOrderStatus() {
    return orderStatus;
  }

  public void setOrderStatus(String orderStatus) {
    this.orderStatus = orderStatus;
  }

  public String getOrderStatusName() {
    return orderStatusName;
  }

  public void setOrderStatusName(String orderStatusName) {
    this.orderStatusName = orderStatusName;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getOrderRegisteredDatetime() {
    return orderRegisteredDatetime;
  }

  public void setOrderRegisteredDatetime(String orderRegisteredDatetime) {
    this.orderRegisteredDatetime = orderRegisteredDatetime;
  }

  public String getPgRegisteredDatetime() {
    return pgRegisteredDatetime;
  }

  public void setPgRegisteredDatetime(String pgRegisteredDatetime) {
    this.pgRegisteredDatetime = pgRegisteredDatetime;
  }

  public String getSuperOrganizationName() {
    return superOrganizationName;
  }

  public void setSuperOrganizationName(String superOrganizationName) {
    this.superOrganizationName = superOrganizationName;
  }

  public String getCdEmpName() {
    return cdEmpName;
  }

  public void setCdEmpName(String cdEmpName) {
    this.cdEmpName = cdEmpName;
  }

  public String getPgTransacionType() {
    return pgTransacionType;
  }

  public void setPgTransacionType(String pgTransacionType) {
    this.pgTransacionType = pgTransacionType;
  }

  public String getPgFailMsg() {
    return pgFailMsg;
  }

  public void setPgFailMsg(String pgFailMsg) {
    this.pgFailMsg = pgFailMsg;
  }

  public int getSingleCopyOrderId() {
    return singleCopyOrderId;
  }

  public void setSingleCopyOrderId(int singleCopyOrderId) {
    this.singleCopyOrderId = singleCopyOrderId;
  }

}
