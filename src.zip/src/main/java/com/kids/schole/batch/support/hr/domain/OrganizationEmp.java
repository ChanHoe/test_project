package com.kids.schole.batch.support.hr.domain;

public class OrganizationEmp {

  private Integer organizationId;
  private Integer empNumber;
  private String jobTitleCode;
  private Integer registeredEmpNumber;
  private String registeredDatetime;
  private Integer lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  public Integer getOrganizationId() {
    return organizationId;
  }
  public void setOrganizationId(Integer organizationId) {
    this.organizationId = organizationId;
  }
  public Integer getEmpNumber() {
    return empNumber;
  }
  public void setEmpNumber(Integer empNumber) {
    this.empNumber = empNumber;
  }
  public String getJobTitleCode() {
    return jobTitleCode;
  }
  public void setJobTitleCode(String jobTitleCode) {
    this.jobTitleCode = jobTitleCode;
  }
  public Integer getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(Integer registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public Integer getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(Integer lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
}
