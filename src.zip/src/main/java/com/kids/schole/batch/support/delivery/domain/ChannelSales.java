package com.kids.schole.batch.support.delivery.domain;

/**
 * 채널 매출 현황
 *
 * @author 최인혜
 *
 */
public class ChannelSales {

  private int channelSalesId; // 채널매출ID
  private String saleDate; // 주문일자
  private String empKey; // 사원 키
  private String empName; // 사원 이름
  private int empNumber; // 사원 번호
  private long saleAmt; // 판매금액

  private String deliveryRequestDate; // 배송요청일자
  private String customerName; // 고객명
  private String customerMobileNumber; //고객 연락처
  private String deliveryAddress; //배송 주소
  private String deliveryAddressDetail; //배송 주소2
  private String deliveryPostcode; //배송 우편번호
  private String deliveryMessage; // 배송 특이사항
  private String orderChannelType; // 판매채널유형

  private int registeredEmpNumber; // 등록사원
  private String registeredDatetime; // 등록일시

  // 배송을 위함
  private int channelSalesDeliveryRequestId;
  private String warehouseContentsKey;


  public int getChannelSalesId() {
    return channelSalesId;
  }
  public void setChannelSalesId(int channelSalesId) {
    this.channelSalesId = channelSalesId;
  }
  public String getSaleDate() {
    return saleDate;
  }
  public void setSaleDate(String saleDate) {
    this.saleDate = saleDate;
  }
  public String getEmpKey() {
    return empKey;
  }
  public void setEmpKey(String empKey) {
    this.empKey = empKey;
  }
  public String getEmpName() {
    return empName;
  }
  public void setEmpName(String empName) {
    this.empName = empName;
  }
  public int getEmpNumber() {
    return empNumber;
  }
  public void setEmpNumber(int empNumber) {
    this.empNumber = empNumber;
  }
  public long getSaleAmt() {
    return saleAmt;
  }
  public void setSaleAmt(long saleAmt) {
    this.saleAmt = saleAmt;
  }
  public String getDeliveryRequestDate() {
    return deliveryRequestDate;
  }
  public void setDeliveryRequestDate(String deliveryRequestDate) {
    this.deliveryRequestDate = deliveryRequestDate;
  }
  public String getCustomerName() {
    return customerName;
  }
  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }
  public String getCustomerMobileNumber() {
    return customerMobileNumber;
  }
  public void setCustomerMobileNumber(String customerMobileNumber) {
    this.customerMobileNumber = customerMobileNumber;
  }
  public String getDeliveryAddress() {
    return deliveryAddress;
  }
  public void setDeliveryAddress(String deliveryAddress) {
    this.deliveryAddress = deliveryAddress;
  }
  public String getDeliveryPostcode() {
    return deliveryPostcode;
  }
  public void setDeliveryPostcode(String deliveryPostcode) {
    this.deliveryPostcode = deliveryPostcode;
  }
  public String getDeliveryMessage() {
    return deliveryMessage;
  }
  public void setDeliveryMessage(String deliveryMessage) {
    this.deliveryMessage = deliveryMessage;
  }
  public String getOrderChannelType() {
    return orderChannelType;
  }
  public void setOrderChannelType(String orderChannelType) {
    this.orderChannelType = orderChannelType;
  }
  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public int getChannelSalesDeliveryRequestId() {
    return channelSalesDeliveryRequestId;
  }
  public void setChannelSalesDeliveryRequestId(int channelSalesDeliveryRequestId) {
    this.channelSalesDeliveryRequestId = channelSalesDeliveryRequestId;
  }
  public String getWarehouseContentsKey() {
    return warehouseContentsKey;
  }
  public void setWarehouseContentsKey(String warehouseContentsKey) {
    this.warehouseContentsKey = warehouseContentsKey;
  }
  public String getDeliveryAddressDetail() {
    return deliveryAddressDetail;
  }
  public void setDeliveryAddressDetail(String deliveryAddressDetail) {
    this.deliveryAddressDetail = deliveryAddressDetail;
  }

}
