package com.kids.schole.batch.support.customer.domain;

public class CsConsultation {

  private Integer csConsultationId;     // CS상담 ID
  private String csIncomeType;          // 유입경로
  private String name;                  // 이름
  private String postcode;              // 우편번호
  private String address;               // 주소
  private String addressDetail;         // 상세주소
  private String phoneNumber;           // 전화번호(내선번호)
  private String mobileNumber;          // 휴대전화번호
  private Integer childAge;             // 아이 연령
  private Integer isAgree;              // 동의여부
  private Integer allotOrganizationId;  // 배분조직 ID
  private String allotOrganizationName; // 배분조직 이름
  private Integer registeredEmpNumber;  // 등록사원번호
  private String registeredDatetime;    // 등록일시(온라인 상담 신청일)
  private String allotStatus;           // 분배 상태
  private Integer rowNum;               // 번호
  
  // CS 상담 배분 컬럼
  private String organizationName;      // 분배된 지점명
  private String allotDatetime;         // 분배된 일자
  private String consultationDatetime;  // 상담 일자
  private String csConsultationStatus;  // 상담 상태
  
  // 검색을 위해 추가
  private String searchStartDate;       // 검색 시작 기간
  private String searchEndDate;         // 검색 종료 기간
  private Integer parentOrganizationId; // 상위 조직 ID
  private Integer organizationId;       // 라운지 ID
  private String authority;             // 사용자 권한
  private String incomeType;            // 검색 유입경로
  private String consultationStatus;    // 검색 상담상태
  
  public Integer getCsConsultationId() {
    return csConsultationId;
  }
  public void setCsConsultationId(Integer csConsultationId) {
    this.csConsultationId = csConsultationId;
  }
  public String getCsIncomeType() {
    return csIncomeType;
  }
  public void setCsIncomeType(String csIncomeType) {
    this.csIncomeType = csIncomeType;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public String getPostcode() {
    return postcode;
  }
  public void setPostcode(String postcode) {
    this.postcode = postcode;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
  public String getAddressDetail() {
    return addressDetail;
  }
  public void setAddressDetail(String addressDetail) {
    this.addressDetail = addressDetail;
  }
  public String getPhoneNumber() {
    return phoneNumber;
  }
  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }
  public String getMobileNumber() {
    return mobileNumber;
  }
  public void setMobileNumber(String mobileNumber) {
    this.mobileNumber = mobileNumber;
  }
  public Integer getChildAge() {
    return childAge;
  }
  public void setChildAge(Integer childAge) {
    this.childAge = childAge;
  }
  public Integer getIsAgree() {
    return isAgree;
  }
  public void setIsAgree(Integer isAgree) {
    this.isAgree = isAgree;
  }
  public Integer getAllotOrganizationId() {
    return allotOrganizationId;
  }
  public void setAllotOrganizationId(Integer allotOrganizationId) {
    this.allotOrganizationId = allotOrganizationId;
  }
  public String getAllotOrganizationName() {
    return allotOrganizationName;
  }
  public void setAllotOrganizationName(String allotOrganizationName) {
    this.allotOrganizationName = allotOrganizationName;
  }
  public Integer getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(Integer registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public String getAllotStatus() {
    return allotStatus;
  }
  public void setAllotStatus(String allotStatus) {
    this.allotStatus = allotStatus;
  }
  public Integer getRowNum() {
    return rowNum;
  }
  public void setRowNum(Integer rowNum) {
    this.rowNum = rowNum;
  }
  public String getOrganizationName() {
    return organizationName;
  }
  public void setOrganizationName(String organizationName) {
    this.organizationName = organizationName;
  }
  public String getAllotDatetime() {
    return allotDatetime;
  }
  public void setAllotDatetime(String allotDatetime) {
    this.allotDatetime = allotDatetime;
  }
  public String getConsultationDatetime() {
    return consultationDatetime;
  }
  public void setConsultationDatetime(String consultationDatetime) {
    this.consultationDatetime = consultationDatetime;
  }
  public String getCsConsultationStatus() {
    return csConsultationStatus;
  }
  public void setCsConsultationStatus(String csConsultationStatus) {
    this.csConsultationStatus = csConsultationStatus;
  }
  public String getSearchStartDate() {
    return searchStartDate;
  }
  public void setSearchStartDate(String searchStartDate) {
    this.searchStartDate = searchStartDate;
  }
  public String getSearchEndDate() {
    return searchEndDate;
  }
  public void setSearchEndDate(String searchEndDate) {
    this.searchEndDate = searchEndDate;
  }
  public Integer getParentOrganizationId() {
    return parentOrganizationId;
  }
  public void setParentOrganizationId(Integer parentOrganizationId) {
    this.parentOrganizationId = parentOrganizationId;
  }
  public Integer getOrganizationId() {
    return organizationId;
  }
  public void setOrganizationId(Integer organizationId) {
    this.organizationId = organizationId;
  }
  public String getAuthority() {
    return authority;
  }
  public void setAuthority(String authority) {
    this.authority = authority;
  }
  public String getIncomeType() {
    return incomeType;
  }
  public void setIncomeType(String incomeType) {
    this.incomeType = incomeType;
  }
  public String getConsultationStatus() {
    return consultationStatus;
  }
  public void setConsultationStatus(String consultationStatus) {
    this.consultationStatus = consultationStatus;
  }
  
}
