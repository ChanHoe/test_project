package com.kids.schole.batch.support.delivery.domain;

/**
 * 채널주문의 배송요청
 *
 * @author 최인혜
 *
 */
public class ChannelSalesDeliveryRequest {

  private int channelSalesDeliveryRequestId;
  private int channelSalesId;
  private String deliveryRequestStatus;
  private String invoiceNumber;
  private String warehouseContentsKey;
  private String warehouseCompleteKey;

  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  // 배송정보 조회를 위해 추가
  private String deliveryRequestStatusName;
  private String materialName;

  public String getDeliveryRequestStatus() {
    return deliveryRequestStatus;
  }
  public void setDeliveryRequestStatus(String deliveryRequestStatus) {
    this.deliveryRequestStatus = deliveryRequestStatus;
  }
  public String getInvoiceNumber() {
    return invoiceNumber;
  }
  public void setInvoiceNumber(String invoiceNumber) {
    this.invoiceNumber = invoiceNumber;
  }
  public String getWarehouseContentsKey() {
    return warehouseContentsKey;
  }
  public void setWarehouseContentsKey(String warehouseContentsKey) {
    this.warehouseContentsKey = warehouseContentsKey;
  }
  public String getWarehouseCompleteKey() {
    return warehouseCompleteKey;
  }
  public void setWarehouseCompleteKey(String warehouseCompleteKey) {
    this.warehouseCompleteKey = warehouseCompleteKey;
  }
  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public String getDeliveryRequestStatusName() {
    return deliveryRequestStatusName;
  }
  public void setDeliveryRequestStatusName(String deliveryRequestStatusName) {
    this.deliveryRequestStatusName = deliveryRequestStatusName;
  }
  public String getMaterialName() {
    return materialName;
  }
  public void setMaterialName(String materialName) {
    this.materialName = materialName;
  }
  public int getChannelSalesDeliveryRequestId() {
    return channelSalesDeliveryRequestId;
  }
  public void setChannelSalesDeliveryRequestId(int channelSalesDeliveryRequestId) {
    this.channelSalesDeliveryRequestId = channelSalesDeliveryRequestId;
  }
  public int getChannelSalesId() {
    return channelSalesId;
  }
  public void setChannelSalesId(int channelSalesId) {
    this.channelSalesId = channelSalesId;
  }


}