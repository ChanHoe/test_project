package com.kids.schole.batch.support.delivery.domain;

public class TrackingNumberAllStepData {

  private String stepText;
  private String stepTime;
  private String stepDetail;
  private String stepCenter;
  private String stepNote;

  public String getStepText() {
    return stepText;
  }

  public void setStepText(String stepText) {
    this.stepText = stepText;
  }

  public String getStepTime() {
    return stepTime;
  }

  public void setStepTime(String stepTime) {
    this.stepTime = stepTime;
  }

  public String getStepDetail() {
    return stepDetail;
  }

  public void setStepDetail(String stepDetail) {
    this.stepDetail = stepDetail;
  }

  public String getStepCenter() {
    return stepCenter;
  }

  public void setStepCenter(String stepCenter) {
    this.stepCenter = stepCenter;
  }

  public String getStepNote() {
    return stepNote;
  }

  public void setStepNote(String stepNote) {
    this.stepNote = stepNote;
  }

}