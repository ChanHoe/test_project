package com.kids.schole.batch.execute.cbbk.settlebank;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.settlebank.domain.Vacs;
import com.kids.schole.batch.support.settlebank.service.SettleBankService;

@Component
public class SettleBankDepositTasklet implements Tasklet {

  @Autowired
  private SettleBankService settleBankService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    List<Vacs> vacsList = settleBankService.getVacsAhstLogList();

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("vacsList", vacsList);

    return RepeatStatus.FINISHED;
    
  }

}
