package com.kids.schole.batch.support.customer.domain;

public class CsConsultationAllot {

  private Integer csConsultationAllotId;    // CS상담 배분 ID
  private Integer csConsultationId;         // CS상담 ID
  private Integer organizationId;           // 조직 ID
  private String organizationName;          // 조직이름
  private Integer cdEmpNumber;              // CD 사원번호
  private String consultationContents;      // 상담내용
  private String consultationDatetime;      // 상담일자
  private String consultationStatus;        // 상담상태
  private Integer registeredEmpNumber;      // 등록사원번호
  private String registeredDatetime;        // 등록일시
  private Integer lastUpdatedEmpNumber;     // 최종변경 사원번호
  private String lastUpdatedDatetime;       // 최종변경 일시
  
  public Integer getCsConsultationAllotId() {
    return csConsultationAllotId;
  }
  public void setCsConsultationAllotId(Integer csConsultationAllotId) {
    this.csConsultationAllotId = csConsultationAllotId;
  }
  public Integer getCsConsultationId() {
    return csConsultationId;
  }
  public void setCsConsultationId(Integer csConsultationId) {
    this.csConsultationId = csConsultationId;
  }
  public Integer getOrganizationId() {
    return organizationId;
  }
  public void setOrganizationId(Integer organizationId) {
    this.organizationId = organizationId;
  }
  public String getOrganizationName() {
    return organizationName;
  }
  public void setOrganizationName(String organizationName) {
    this.organizationName = organizationName;
  }
  public Integer getCdEmpNumber() {
    return cdEmpNumber;
  }
  public void setCdEmpNumber(Integer cdEmpNumber) {
    this.cdEmpNumber = cdEmpNumber;
  }
  public String getConsultationContents() {
    return consultationContents;
  }
  public void setConsultationContents(String consultationContents) {
    this.consultationContents = consultationContents;
  }
  public String getConsultationDatetime() {
    return consultationDatetime;
  }
  public void setConsultationDatetime(String consultationDatetime) {
    this.consultationDatetime = consultationDatetime;
  }
  public String getConsultationStatus() {
    return consultationStatus;
  }
  public void setConsultationStatus(String consultationStatus) {
    this.consultationStatus = consultationStatus;
  }
  public Integer getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(Integer registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public Integer getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(Integer lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
}
