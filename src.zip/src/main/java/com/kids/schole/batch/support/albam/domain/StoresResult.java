package com.kids.schole.batch.support.albam.domain;

import java.util.List;

public class StoresResult {

  private String accessToken;
  private Integer expiredAt;
  private List<StoreList> storeList;

  public String getAccessToken() {
    return accessToken;
  }
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }
  public Integer getExpiredAt() {
    return expiredAt;
  }
  public void setExpiredAt(Integer expiredAt) {
    this.expiredAt = expiredAt;
  }
  public List<StoreList> getStoreList() {
    return storeList;
  }
  public void setStoreList(List<StoreList> storeList) {
    this.storeList = storeList;
  }
  
}
