package com.kids.schole.batch.execute.cbbk.autoAllot;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequest;
import com.kids.schole.batch.support.cbbk.service.CbbkService;

@Component
public class OrderStatusCbbkReadyTasklet implements Tasklet {

  @Autowired
  private CbbkService cbbkService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    List<CbbkPaymentRequest> cbbkPaymentRequestReadyList =
        cbbkService.getCbbkPaymentRequestReadyList();
    
    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("cbbkPaymentRequestReadyList", cbbkPaymentRequestReadyList);

    return RepeatStatus.FINISHED;
  }

}
