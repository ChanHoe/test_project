package com.kids.schole.batch.execute.sales;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;
import com.kids.schole.common.util.DateUtil;

/**
 * SalesEmpInfoConfig는 인원별 매출 집계를 처리하는 클래스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
@Configuration
@EnableBatchProcessing
public class SalesEmpInfoConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private EmpSalesInfoTasklet empSalesInfoTasklet;
  
  @Autowired
  private OrgSalesInfoTasklet orgSalesInfoTasklet;
  
  // 매월 마지막날 21시 30분 -  "0 30 21 *L * ?"
  
  // 10시 30분, 16시 30분 - 알밤데이터 때문에 매일 2회 진행 ( 9시 20분에 알밤 연동 ) 
  @Scheduled(cron="0 30 10,16 * * ?")	
  public String runSalesInfo() throws Exception {
    
    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
    
    JobExecution execution = jobLauncher.run(empOrgSalesInfoJob(), param);
    
    // TODO 실행확인용 - 안정후 삭제
    System.out.println("########");
    System.out.println("######## "+DateUtil.getSysYearSecond());
    System.out.println("########");
    
    return execution.getStatus().toString();
  }
  
  // 웹에서의 파라미터 지정 호출용
  public String runSalesInfo(String firstDate) throws Exception {
    
    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis()))
    	.addString("firstDate", firstDate).toJobParameters();
    
    JobExecution execution = jobLauncher.run(empOrgSalesInfoJob(), param);
    
    return execution.getStatus().toString();
  }
  
  @Bean
  public Job empOrgSalesInfoJob() {
    
    return jobBuilderFactory
        .get("empOrgSalesInfoJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(empSalesInfoStep())
        .next(orgSalesInfoStep())
        .build();
  }
  
  // 인원별 매출 집계
  @Bean
  public Step empSalesInfoStep() {
    
    return stepBuilderFactory
        .get("empSalesInfoStep")
        .tasklet(empSalesInfoTasklet)
        .build();
  }
  
  // 조직별 매출 집계
  @Bean
  public Step orgSalesInfoStep() {
   
    return stepBuilderFactory
       .get("orgSalesInfoStep")
       .tasklet(orgSalesInfoTasklet)
       .build();
  }
 
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
  
}
