package com.kids.schole.batch.execute.albam;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * AlbamConfig는 알밤에 교사들을 등록, 수정하고
 * 출근을 정보를 조회해서 월별출결현황에 처리하는 클래스입니다.
 * 
 * @version 1.0 2016.01.06
 * @author Jeongwon Son
 */
@Configuration
@EnableBatchProcessing
public class AlbamConfig {
  
  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private EmpInfoUpdateTasklet empInfoUpdateTasklet;
  
  @Autowired
  private DailyMeetingInfoTasklet dailyMeetingInfoTasklet;
  
  @Autowired
  private AlbamAuthenticateTasklet albamAuthenticateTasklet;
  
  @Autowired
  private StoresListTasklet storesListTasklet;
  
  /**
   * CD 판매사원들의 정보를 보내고, 알밤에 등록, 업데이트 시킨다.
   * 알밤에 등록되고 업데이트된 값을 월별출결현황에 등록시킨다.
   */
  //매일 오전 10시 20분에 실행
  @Scheduled(cron = "0 20 10 * * ?")
  public String runAlbamRolls() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(albamRollsJob(), param);

    return execution.getStatus().toString();
  }
  
  // 웹에서 특정날짜를 넣고 조회를 하는 경우에 사용
  public String runAlbamRolls(String inputYear,String inputMonth ,String startDate, String endDate, String empKey) throws Exception {
    
    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis()))
        .addString("inputYear", inputYear)
        .addString("inputMonth", inputMonth)
        .addString("startDate", startDate)
        .addString("endDate", endDate)
        .addString("empKey", empKey).toJobParameters();
    
    JobExecution execution = jobLauncher.run(albamRollsJob(), param);
    
    return execution.getStatus().toString();
  }
  
  @Bean
  public Job albamRollsJob() {

    return jobBuilderFactory
        .get("albamRollsJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(empInfoUpdateStep())
        .next(dailyMeetingInfoStep())
        .build();
  }
  
  // 알밤에 CD급 판매직원들의 정보를 전송해서 등록, 수정한다.
  @Bean
  public Step empInfoUpdateStep() {

   return stepBuilderFactory
       .get("empInfoUpdateStep")
       .tasklet(empInfoUpdateTasklet)
       .build();
  }
  
  // 어제의 날짜로 CD급 판매직원들의 출결현황을 조회해서 등록한다.
  @Bean
  public Step dailyMeetingInfoStep() {
    return stepBuilderFactory
        .get("dailyMeetingInfoStep")
        .tasklet(dailyMeetingInfoTasklet)
        .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
  
  /**
   * 최초 한번 인증받기 위함
   */
  public String runAlbamAuthenticate() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(albamAuthenticateJob(), param);

    return execution.getStatus().toString();
  }
  
  @Bean
  public Job albamAuthenticateJob() {

    return jobBuilderFactory
        .get("albamAuthenticateJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(albamAuthenticateStep())
        .build();
  }
  
  @Bean
  public Step albamAuthenticateStep() {

   return stepBuilderFactory
       .get("albamAuthenicateStep")
       .tasklet(albamAuthenticateTasklet)
       .build();
  }
  
  /**
   * access_token을 보내서 상점목록 정보를 받는다.
   */
  public String runStoresList() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(storesListJob(), param);

    return execution.getStatus().toString();
  }
  
  @Bean
  public Job storesListJob() {

    return jobBuilderFactory
        .get("storesListJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(storesListStep())
        .build();
  }
  
  @Bean
  public Step storesListStep() {

   return stepBuilderFactory
       .get("storesListStep")
       .tasklet(storesListTasklet)
       .build();
  }

}
