package com.kids.schole.batch.execute.cms.installment;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class InstallmentSearchConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private InstallPaymentSearchTasklet installPaymentSearchTasklet;

  // 12시 10분에 실행
  // @Scheduled(cron = "0 10 12 * * ?")
  public String runInstallmentSearch() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(cmsInstallmentSearchJob(), param);

    return execution.getStatus().toString();
  }
  
  @Bean
  public Job cmsInstallmentSearchJob() {

    return jobBuilderFactory
        .get("cmsInstallmentSearchJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(installPaymentSearchStep())
        .build();
  }
  
  // 할부요청대상 조회
  @Bean
  public Step installPaymentSearchStep() {
    return stepBuilderFactory
       .get("installPaymentSearchStep")
       .tasklet(installPaymentSearchTasklet)
       .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}
