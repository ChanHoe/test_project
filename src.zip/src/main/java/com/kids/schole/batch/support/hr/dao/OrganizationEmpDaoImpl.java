package com.kids.schole.batch.support.hr.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.hr.domain.OrganizationEmp;

@Repository
public class OrganizationEmpDaoImpl implements OrganizationEmpDao {

  @Autowired
  private SqlSession sqlSession;

  @Override
  public void updateOrganizationId(OrganizationEmp organizationEmp) {

    sqlSession.update("hr.updateOrganizationId", organizationEmp);
  }

}
