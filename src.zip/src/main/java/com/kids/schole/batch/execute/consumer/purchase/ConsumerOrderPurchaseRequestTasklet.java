package com.kids.schole.batch.execute.consumer.purchase;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.service.ConsumerOrderService;

@Component
public class ConsumerOrderPurchaseRequestTasklet implements Tasklet {

  @Autowired
  private ConsumerOrderService consumerOrderService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<CardPaymentRequest> cardPaymentRequestList =
        (List<CardPaymentRequest>) chunkContext.getStepContext().getStepExecution()
            .getJobExecution().getExecutionContext().get("cardPaymentRequestList");

    List<Integer> tempCardPaymentRequestIdList = new ArrayList<Integer>();
    for (CardPaymentRequest cardPaymentRequest : cardPaymentRequestList) {
      tempCardPaymentRequestIdList.add(cardPaymentRequest.getCardPaymentRequestId());
    }
    
    List<Integer> cardPaymentRequestIdList = new ArrayList<Integer>(new HashSet<Integer>(tempCardPaymentRequestIdList));
    
    List<Order> orderList = new ArrayList<Order>();
    
    for(int cardPaymentRequestId : cardPaymentRequestIdList) {
      CardPaymentRequest tempCardPaymentRequest = 
          consumerOrderService.getConsumerCardPaymentRequestPurchase(cardPaymentRequestId);
      
      if(tempCardPaymentRequest != null) {
        Order order  = new Order();
        order.setOrderId(tempCardPaymentRequest.getOrderId());
        order.setPayDoneAmt(tempCardPaymentRequest.getAuthAmt());
        order.setLastUpdatedEmpNumber(99999);
        orderList.add(order);
      }
    }
    
    for(Order order : orderList) {
      consumerOrderService.modifyConsumerOrderPayDoneAmt(order);
    }
    
    
    // 주문정보 ID가 여러개 중복되어 있어서 중복제거를 한다.
    /*List<Integer> tempOrderIdList = new ArrayList<Integer>();
    for (CardPaymentRequest cardPaymentRequest : cardPaymentRequestList) {
      tempOrderIdList.add(cardPaymentRequest.getOrderId());
    }
    List<Integer> orderIdList = new ArrayList<Integer>(new HashSet<Integer>(tempOrderIdList));

    for (int orderId : orderIdList) {
      // 주문 테이블에서 실제 결제된 금액만 업데이트 한다.
      Order order = new Order();
      order.setOrderId(orderId);
      order.setLastUpdatedEmpNumber(99999);
      consumerOrderService.modifyConsumerOrderPayDoneAmt(order);
    }*/

    return RepeatStatus.FINISHED;

  }

}
