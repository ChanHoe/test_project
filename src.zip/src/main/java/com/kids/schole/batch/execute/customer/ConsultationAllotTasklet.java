package com.kids.schole.batch.execute.customer;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.customer.service.ConsultationService;

@Component
public class ConsultationAllotTasklet implements Tasklet {
  
  @Autowired
  private ConsultationService consultationService;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {
    
	  consultationService.modifyCsConsultationVDAllot();
    
    return RepeatStatus.FINISHED;
  }

}
