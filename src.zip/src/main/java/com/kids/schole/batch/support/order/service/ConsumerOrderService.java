package com.kids.schole.batch.support.order.service;

import java.util.List;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

public interface ConsumerOrderService {
  
  public List<CardPaymentRequest> getConsumerOrderApprovalList();
  
  public void modifyConsumerOrderPayDoneAmt(Order order);
  
  public void modifyConsumerOrderStatusDone(Order order);
  
  public CardPaymentRequest getConsumerCardPaymentRequestPurchase(int cardPaymentRequestId);
  
  public List<CardPaymentRequest> getSingleCopyOrderApprovalList();
  
  public CardPaymentRequest getSingleCopyCardPaymentRequestPurchase(int cardPaymentRequestId);
  
  public void modifySingleCopyPaymentAmt(SingleCopyOrder singleCopyOrder);
  
  public void modifySingleCopyOrderStatus(SingleCopyOrder singleCopyOrder);
  
  public void modifySingleCopyOrderStatusDone(SingleCopyOrder singleCopyOrder);
}
