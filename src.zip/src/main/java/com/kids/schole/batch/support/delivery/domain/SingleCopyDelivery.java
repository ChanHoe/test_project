package com.kids.schole.batch.support.delivery.domain;

public class SingleCopyDelivery {
  private int singleCopyDeliveryId;
  private int singleCopyOrderId;// 낱권주문ID
  private int productId; // 제품ID
  private int customerId; // 고객ID
  private String singleCopyDeliveryStatus;
  private String invoiceNumber;
  private String warehouseContentsKey;
  private String warehouseCompleteKey;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private String deliveryDoneDate;
  private String lastUpdatedDatetime;
  
  private TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus;
  
  
  public int getSingleCopyDeliveryId() {
    return singleCopyDeliveryId;
  }
  public void setSingleCopyDeliveryId(int singleCopyDeliveryId) {
    this.singleCopyDeliveryId = singleCopyDeliveryId;
  }
  public int getSingleCopyOrderId() {
    return singleCopyOrderId;
  }
  public void setSingleCopyOrderId(int singleCopyOrderId) {
    this.singleCopyOrderId = singleCopyOrderId;
  }
  public int getProductId() {
    return productId;
  }
  public void setProductId(int productId) {
    this.productId = productId;
  }
  public int getCustomerId() {
    return customerId;
  }
  public void setCustomerId(int customerId) {
    this.customerId = customerId;
  }
  public String getSingleCopyDeliveryStatus() {
    return singleCopyDeliveryStatus;
  }
  public void setSingleCopyDeliveryStatus(String singleCopyDeliveryStatus) {
    this.singleCopyDeliveryStatus = singleCopyDeliveryStatus;
  }
  public String getInvoiceNumber() {
    return invoiceNumber;
  }
  public void setInvoiceNumber(String invoiceNumber) {
    this.invoiceNumber = invoiceNumber;
  }
  public String getWarehouseContentsKey() {
    return warehouseContentsKey;
  }
  public void setWarehouseContentsKey(String warehouseContentsKey) {
    this.warehouseContentsKey = warehouseContentsKey;
  }
  public String getWarehouseCompleteKey() {
    return warehouseCompleteKey;
  }
  public void setWarehouseCompleteKey(String warehouseCompleteKey) {
    this.warehouseCompleteKey = warehouseCompleteKey;
  }
  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public String getDeliveryDoneDate() {
    return deliveryDoneDate;
  }
  public void setDeliveryDoneDate(String deliveryDoneDate) {
    this.deliveryDoneDate = deliveryDoneDate;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public TrackingNumberTraceResponseStatus getTrackingNumberTraceResponseStatus() {
    return trackingNumberTraceResponseStatus;
  }
  public void setTrackingNumberTraceResponseStatus(
      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus) {
    this.trackingNumberTraceResponseStatus = trackingNumberTraceResponseStatus;
  }
}
