package com.kids.schole.batch.execute.product;

/**
 * ProductStatusConfig는 주문 상태값을 처리하는 클래스입니다.
 * 
 * @version 1.0 2016.12.17
 * @author Jeongho Baek
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class ProductStatusConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private ProductStatusTasklet productStatusTasklet;
  
  @Scheduled(cron="0 0 1 * * ?") // 모든요일, 매월 매일 새벽 1시에 실행
  public String runProductStatus() throws Exception {
    
    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
    
    JobExecution execution = jobLauncher.run(productStatusJob(), param);
    
    return execution.getStatus().toString();
  }
  
  @Bean
  public Job productStatusJob() {
    
    return jobBuilderFactory
        .get("productStatusJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(productStatusStep())
        .build();
  }
  
  // 제품테이블의 제품상태를 업데이트 한다.
  @Bean
  public Step productStatusStep() {
    
    return stepBuilderFactory
        .get("productStatusStep")
        .tasklet(productStatusTasklet)
        .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
  
}
