package com.kids.schole.batch.execute.consumer.purchase;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.delivery.service.ConsumerDeliveryService;
import com.kids.schole.common.constant.DeliveryConst;

@Component
public class SingleCopyDeliveryWaitTasklet implements Tasklet {

  @Autowired
  private ConsumerDeliveryService consumerDeliveryService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<CardPaymentRequest> cardPaymentRequestList =
        (List<CardPaymentRequest>) chunkContext.getStepContext().getStepExecution()
            .getJobExecution().getExecutionContext().get("cardPaymentRequestList");

    // 주문정보 ID가 여러개 중복되어 있어서 중복제거를 한다.
    List<Integer> tempSingleCopyOrderIdList = new ArrayList<Integer>();
    for (CardPaymentRequest cardPaymentRequest : cardPaymentRequestList) {
      tempSingleCopyOrderIdList.add(cardPaymentRequest.getSingleCopyOrderId());
    }
    List<Integer> singleCopyOrderIdList = new ArrayList<Integer>(new HashSet<Integer>(tempSingleCopyOrderIdList));

    for (int singleCopyOrderId : singleCopyOrderIdList) {
      SingleCopyDelivery singleCopyDelivery = new SingleCopyDelivery();
      singleCopyDelivery.setSingleCopyOrderId(singleCopyOrderId);
      singleCopyDelivery.setSingleCopyDeliveryStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_WAIT);
      consumerDeliveryService.modifySingleCopyDeliveryStatusWait(singleCopyDelivery);
    }

    return RepeatStatus.FINISHED;
    
  }

}
