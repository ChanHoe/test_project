package com.kids.schole.batch.support.hr.domain;

/**
 * PERSONNEL_CHANGE 테이블과 매핑하기 위한 도메인 클래스입니다.
 *
 * @version 1.0 2016. 11. 10.
 * @author Eunsung Ju
 */
public class PersonnelChange {

  private Integer personnelChangeId;
  private Integer empNumber;
  private String workBeginDate;
  private String workEndDate;
  private String personnelChangeType;
  private String affiliationName;
  private Integer affiliationOrganizationId;
  private String positionCode;
  private Integer registeredEmpNumber;
  private String registeredDatetime;
  private Integer lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  // 공통코드
  private String personnelChangeTypeName;
  private String positionCodeName;

  public Integer getPersonnelChangeId() {
    return personnelChangeId;
  }
  public void setPersonnelChangeId(Integer personnelChangeId) {
    this.personnelChangeId = personnelChangeId;
  }
  public Integer getEmpNumber() {
    return empNumber;
  }
  public void setEmpNumber(Integer empNumber) {
    this.empNumber = empNumber;
  }
  public String getWorkBeginDate() {
    return workBeginDate;
  }
  public void setWorkBeginDate(String workBeginDate) {
    this.workBeginDate = workBeginDate;
  }
  public String getWorkEndDate() {
    return workEndDate;
  }
  public void setWorkEndDate(String workEndDate) {
    this.workEndDate = workEndDate;
  }
  public String getPersonnelChangeType() {
    return personnelChangeType;
  }
  public void setPersonnelChangeType(String personnelChangeType) {
    this.personnelChangeType = personnelChangeType;
  }
  public String getAffiliationName() {
    return affiliationName;
  }
  public void setAffiliationName(String affiliationName) {
    this.affiliationName = affiliationName;
  }
  public Integer getAffiliationOrganizationId() {
    return affiliationOrganizationId;
  }
  public void setAffiliationOrganizationId(Integer affiliationOrganizationId) {
    this.affiliationOrganizationId = affiliationOrganizationId;
  }
  public String getPositionCode() {
    return positionCode;
  }
  public void setPositionCode(String positionCode) {
    this.positionCode = positionCode;
  }
  public Integer getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(Integer registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public Integer getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(Integer lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public String getPersonnelChangeTypeName() {
    return personnelChangeTypeName;
  }
  public void setPersonnelChangeTypeName(String personnelChangeTypeName) {
    this.personnelChangeTypeName = personnelChangeTypeName;
  }
  public String getPositionCodeName() {
    return positionCodeName;
  }
  public void setPositionCodeName(String positionCodeName) {
    this.positionCodeName = positionCodeName;
  }
}
