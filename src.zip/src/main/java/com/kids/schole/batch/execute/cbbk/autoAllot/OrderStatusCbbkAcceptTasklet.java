package com.kids.schole.batch.execute.cbbk.autoAllot;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cbbk.service.CbbkService;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.OrderPayment;
import com.kids.schole.batch.support.order.service.OrderService;
import com.kids.schole.common.constant.OrderConst;

@Component
public class OrderStatusCbbkAcceptTasklet implements Tasklet {

  @Autowired
  private CbbkService cbbkService;

  @Autowired
  private OrderService orderService;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<Order> orderList = (List<Order>) chunkContext.getStepContext().getStepExecution()
        .getJobExecution().getExecutionContext().get("orderList");

    for (Order order : orderList) {
      
      order.setOrderStatus(OrderConst.ORDER_STATUS_ACCEPTED);
      order.setLastUpdatedEmpNumber(99999);
      cbbkService.modifyOrderStatusPayDoneAmt(order);
      
      OrderPayment orderPayment = new OrderPayment();
      orderPayment.setOrderId(order.getOrderId());
      orderPayment.setPayStatus(OrderConst.PAY_STATUS_DONE);
      orderPayment.setLastUpdatedEmpNumber(99999);
      orderService.modifyOrderPaymentPayStatus(orderPayment);
      
    }

    return RepeatStatus.FINISHED;
  }

}
