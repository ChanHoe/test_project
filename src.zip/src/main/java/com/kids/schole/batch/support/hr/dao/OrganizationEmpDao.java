package com.kids.schole.batch.support.hr.dao;

import com.kids.schole.batch.support.hr.domain.OrganizationEmp;

public interface OrganizationEmpDao {

  public void updateOrganizationId(OrganizationEmp organizationEmp);
}
