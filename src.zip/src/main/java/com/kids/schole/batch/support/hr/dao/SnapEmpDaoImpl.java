package com.kids.schole.batch.support.hr.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.hr.domain.SnapEmp;
import com.kids.schole.batch.support.hr.domain.SnapOrganization;
import com.kids.schole.batch.support.hr.domain.SnapOrganizationEmp;
import com.kids.schole.batch.support.hr.domain.SnapPersonnelChange;

@Repository
public class SnapEmpDaoImpl implements SnapEmpDao {

  @Autowired
  private SqlSession sqlSession;
  
  @Override
  public List<SnapEmp> selectEmpList() {
    // TODO Auto-generated method stub
    return sqlSession.selectList("snapshot.selectEmpList");
  }
  
  @Override
  public void deleteSnapEmp(SnapEmp snapEmp) {
    // TODO Auto-generated method stub
    sqlSession.delete("snapshot.deleteSnapEmp", snapEmp);
  }
  
  @Override
  public void insertSnapEmp(List<SnapEmp> snapEmpList) {
    // TODO Auto-generated method stub
    sqlSession.insert("snapshot.insertSnapEmp", snapEmpList);
  }
  
  @Override
  public List<SnapOrganizationEmp> selectOrganizationEmpList() {
    // TODO Auto-generated method stub
    return sqlSession.selectList("snapshot.selectOrganizationEmpList");
  }
  
  @Override
  public void deleteSnapOrganizationEmp(SnapOrganizationEmp snapOrganizationEmp) {
    // TODO Auto-generated method stub
    sqlSession.delete("snapshot.deleteSnapOrganizationEmp", snapOrganizationEmp);
  }
  
  @Override
  public void insertSnapOrganizationEmp(List<SnapOrganizationEmp> snapOrganizationEmpList) {
    // TODO Auto-generated method stub
    sqlSession.insert("snapshot.insertSnapOrganizationEmp", snapOrganizationEmpList);
  }
  
  @Override
  public List<SnapOrganization> selectOrganizationList() {
    // TODO Auto-generated method stub
    return sqlSession.selectList("snapshot.selectOrganizationList");
  }
  
  @Override
  public void deleteSnapOrganization(SnapOrganization snapOrganization) {
    // TODO Auto-generated method stub
    sqlSession.delete("snapshot.deleteSnapOrganization", snapOrganization);
  }
  
  @Override
  public void insertSnapOrganization(List<SnapOrganization> snapOrganizationList) {
    // TODO Auto-generated method stub
    sqlSession.insert("snapshot.insertSnapOrganization",snapOrganizationList);
  }
  
  @Override
  public List<SnapPersonnelChange> selectPersonnelChangeList() {
    // TODO Auto-generated method stub
    return sqlSession.selectList("snapshot.selectPersonnelChangeList");
  }
  
  @Override
  public void deleteSnapPersonnelChange(SnapPersonnelChange snapPersonnelChange) {
    // TODO Auto-generated method stub
    sqlSession.delete("snapshot.deleteSnapPersonnelChange", snapPersonnelChange);
  }
  
  @Override
  public void insertSnapPersonnelChange(List<SnapPersonnelChange> snapPersonnelChangeList) {
    // TODO Auto-generated method stub
    sqlSession.insert("snapshot.insertSnapPersonnelChange", snapPersonnelChangeList);
  }
}
