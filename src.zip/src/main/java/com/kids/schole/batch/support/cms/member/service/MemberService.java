package com.kids.schole.batch.support.cms.member.service;

import java.util.List;

import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.domain.OrderAttachedFile;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;

public interface MemberService {

  List<OrderAttachedFile> getOrderAttachedFileNewWaitList();

  void modifyMemberProofStatus(OrderAttachedFile orderAttachedFile);

  List<OrderAttachedFile> getOrderAttachedFileProcessingList();

  List<OrderAttachedFile> getOrderAttachedFileCancelList();

  List<Member> getMemberWaitList(InstallmentPaymentRequest installmentPaymentRequest);

  void modifyApplicationStatusProcessing(InstallmentPaymentRequest installmentPaymentRequest);

  void modifyApplicationStatusFail(InstallmentPaymentRequest installmentPaymentRequest);

  List<Member> getMemberProcessingList(InstallmentPaymentRequest installmentPaymentRequest);

  void modifyAllProcessingListDone(InstallmentPaymentRequest installmentPaymentRequest);

  /** 할부계좌 변경한 주문 목록 */
  List<Member> getModifyAccountInstallments(InstallmentPaymentRequest installmentPaymentRequest);
  /** 할부계좌 변경한 목록의 회원신청 종류와 상태를 변경해준다.  */
  void modifyApplicationStatusWaitAndModify(int installmentPaymentRequestId);

}
