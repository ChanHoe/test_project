package com.kids.schole.batch.execute.cms.member;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cms.member.domain.OrderAttachedFile;
import com.kids.schole.batch.support.cms.member.service.MemberService;
import com.kids.schole.common.cms.BaseAction;
import com.kids.schole.common.cms.XcJavaSocket;
import com.kids.schole.common.cms.util.UtilMethod;
import com.kids.schole.common.constant.OrderConst;
import com.kids.schole.common.constant.PaymentGateConst;
import com.kids.schole.common.properties.PgCmsProperties;

@Component
public class MemberProofSearchTasklet implements Tasklet {

  @Autowired
  private PgCmsProperties pgCmsProperties;

  @Autowired
  private MemberService memberService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    List<OrderAttachedFile> orderAttachedFileList =
        memberService.getOrderAttachedFileProcessingList();

    for (OrderAttachedFile orderAttachedFile : orderAttachedFileList) {

      BaseAction conn = new XcJavaSocket();
      conn.connect(pgCmsProperties.getRealMemberProofIp(),
          pgCmsProperties.getRealMemberProofPort());

      String contractFileName =
          orderAttachedFile.getAttachedFilePath() + orderAttachedFile.getHashFileName();
      File contractFile = new File(contractFileName);

      String contractFileNameExtension =
          FilenameUtils.getExtension(orderAttachedFile.getHashFileName());

      String memeberProofApplyTelegram = memeberProofStartTelegram(orderAttachedFile.getApplyDate(),
          PaymentGateConst.PG_REAL_MEMBER_PROOF_SEARCH_TELEGRAM_CODE,
          PaymentGateConst.PG_REAL_MEMBER_PROOF_SEARCH_PROCESS_CODE,
          orderAttachedFile.getInstallmentPaymentRequestId(), contractFileNameExtension,
          contractFile.length() + "");

      conn.sendData(memeberProofApplyTelegram);
      
      System.out.println("회원증빙 조회 시작전문 송신 : " + memeberProofApplyTelegram);

      byte[] tgr = null;
      tgr = conn.recvData();

      String startResult = new String(tgr, "euc-kr");
      System.out.println("회원증빙 조회 시작전문 수신 : " + startResult);

      if (startResult.substring(90, 91).equals("Y")) {
        orderAttachedFile
            .setApplyDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        orderAttachedFile.setProofStatus(OrderConst.PROOF_STATUS_DONE);
        orderAttachedFile.setFailedProofReason("");
        memberService.modifyMemberProofStatus(orderAttachedFile);
      } else {
        orderAttachedFile
            .setApplyDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        orderAttachedFile.setProofStatus(OrderConst.PROOF_STATUS_FAIL);
        orderAttachedFile.setFailedProofReason(UtilMethod.subString(startResult, 95, 30).trim());
        memberService.modifyMemberProofStatus(orderAttachedFile);
      }

      conn.close();

    }

    return RepeatStatus.FINISHED;
  }

  // 회원 증빙 시작전문
  private String memeberProofStartTelegram(String nowDate, String telegramType, String workType,
      int installmentPaymentRequestId, String fileExetension, String fileLength) {

    StringBuffer sb = new StringBuffer();

    sb.append("S");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyPassword(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getSwId(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getSwPassword(), 10, " "));
    sb.append(nowDate.replaceAll("-", ""));
    sb.append(telegramType);
    sb.append(workType);
    sb.append("B");
    sb.append(StringUtils.rightPad(installmentPaymentRequestId + "", 20, " ")); // 회원번호
    sb.append("01");
    sb.append(StringUtils.rightPad(fileExetension, 5, " "));
    sb.append(StringUtils.leftPad(fileLength, 6, "0"));
    sb.append(StringUtils.rightPad("", 110, " "));
    sb.append("\r\n");

    return sb.toString();

  }

}
