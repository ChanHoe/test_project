package com.kids.schole.batch.support.order.domain;

public class SingleCopyOrder {
  private int singleCopyOrderId;
  private int orderId;
  private int customerId;
  private String singleCopyOrderNumber;
  private long singleCopyOrderAmt;
  private long singleCopyPaymentAmt;
  private String singleCopyOrderStatus;
  private String singleCopyOrderStatusName;
  private String singleCopyPayType;
  private int isChargeOrder;
  private int isRejectAccept;
  private String receiverName;
  private String receiverPhoneNumber;
  private String receiverMobileNumber;
  private String receiverRelation;
  private String deliveryPostcode;
  private String deliveryAddress;
  private String deliveryAddressDetail;
  private String deliveryDoneDate;
  private String salesDoneDate;
  private String requestReason;
  private String requestDetailReason;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private String lastUpdatedDatetime;
  
  private int singleCopyDeliveryId;
  private int productId;
  private String warehouseContentsKey;
  
  public int getSingleCopyOrderId() {
    return singleCopyOrderId;
  }
  public void setSingleCopyOrderId(int singleCopyOrderId) {
    this.singleCopyOrderId = singleCopyOrderId;
  }
  public int getOrderId() {
    return orderId;
  }
  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }
  public int getCustomerId() {
    return customerId;
  }
  public void setCustomerId(int customerId) {
    this.customerId = customerId;
  }
  public String getSingleCopyOrderNumber() {
    return singleCopyOrderNumber;
  }
  public void setSingleCopyOrderNumber(String singleCopyOrderNumber) {
    this.singleCopyOrderNumber = singleCopyOrderNumber;
  }
  public long getSingleCopyOrderAmt() {
    return singleCopyOrderAmt;
  }
  public void setSingleCopyOrderAmt(long singleCopyOrderAmt) {
    this.singleCopyOrderAmt = singleCopyOrderAmt;
  }
  public long getSingleCopyPaymentAmt() {
    return singleCopyPaymentAmt;
  }
  public void setSingleCopyPaymentAmt(long singleCopyPaymentAmt) {
    this.singleCopyPaymentAmt = singleCopyPaymentAmt;
  }
  public String getSingleCopyOrderStatus() {
    return singleCopyOrderStatus;
  }
  public void setSingleCopyOrderStatus(String singleCopyOrderStatus) {
    this.singleCopyOrderStatus = singleCopyOrderStatus;
  }
  public String getSingleCopyOrderStatusName() {
    return singleCopyOrderStatusName;
  }
  public void setSingleCopyOrderStatusName(String singleCopyOrderStatusName) {
    this.singleCopyOrderStatusName = singleCopyOrderStatusName;
  }
  public String getSingleCopyPayType() {
    return singleCopyPayType;
  }
  public void setSingleCopyPayType(String singleCopyPayType) {
    this.singleCopyPayType = singleCopyPayType;
  }
  public int getIsChargeOrder() {
    return isChargeOrder;
  }
  public void setIsChargeOrder(int isChargeOrder) {
    this.isChargeOrder = isChargeOrder;
  }
  public int getIsRejectAccept() {
    return isRejectAccept;
  }
  public void setIsRejectAccept(int isRejectAccept) {
    this.isRejectAccept = isRejectAccept;
  }
  public String getReceiverName() {
    return receiverName;
  }
  public void setReceiverName(String receiverName) {
    this.receiverName = receiverName;
  }
  public String getReceiverPhoneNumber() {
    return receiverPhoneNumber;
  }
  public void setReceiverPhoneNumber(String receiverPhoneNumber) {
    this.receiverPhoneNumber = receiverPhoneNumber;
  }
  public String getReceiverMobileNumber() {
    return receiverMobileNumber;
  }
  public void setReceiverMobileNumber(String receiverMobileNumber) {
    this.receiverMobileNumber = receiverMobileNumber;
  }
  public String getReceiverRelation() {
    return receiverRelation;
  }
  public void setReceiverRelation(String receiverRelation) {
    this.receiverRelation = receiverRelation;
  }
  public String getDeliveryPostcode() {
    return deliveryPostcode;
  }
  public void setDeliveryPostcode(String deliveryPostcode) {
    this.deliveryPostcode = deliveryPostcode;
  }
  public String getDeliveryAddress() {
    return deliveryAddress;
  }
  public void setDeliveryAddress(String deliveryAddress) {
    this.deliveryAddress = deliveryAddress;
  }
  public String getDeliveryAddressDetail() {
    return deliveryAddressDetail;
  }
  public void setDeliveryAddressDetail(String deliveryAddressDetail) {
    this.deliveryAddressDetail = deliveryAddressDetail;
  }
  public String getDeliveryDoneDate() {
    return deliveryDoneDate;
  }
  public void setDeliveryDoneDate(String deliveryDoneDate) {
    this.deliveryDoneDate = deliveryDoneDate;
  }
  public String getSalesDoneDate() {
    return salesDoneDate;
  }
  public void setSalesDoneDate(String salesDoneDate) {
    this.salesDoneDate = salesDoneDate;
  }
  public String getRequestReason() {
    return requestReason;
  }
  public void setRequestReason(String requestReason) {
    this.requestReason = requestReason;
  }
  public String getRequestDetailReason() {
    return requestDetailReason;
  }
  public void setRequestDetailReason(String requestDetailReason) {
    this.requestDetailReason = requestDetailReason;
  }
  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public int getSingleCopyDeliveryId() {
    return singleCopyDeliveryId;
  }
  public void setSingleCopyDeliveryId(int singleCopyDeliveryId) {
    this.singleCopyDeliveryId = singleCopyDeliveryId;
  }
  public int getProductId() {
    return productId;
  }
  public void setProductId(int productId) {
    this.productId = productId;
  }
  public String getWarehouseContentsKey() {
    return warehouseContentsKey;
  }
  public void setWarehouseContentsKey(String warehouseContentsKey) {
    this.warehouseContentsKey = warehouseContentsKey;
  }
  
}
