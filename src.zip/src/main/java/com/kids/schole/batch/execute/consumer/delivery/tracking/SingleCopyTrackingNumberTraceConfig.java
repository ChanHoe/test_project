package com.kids.schole.batch.execute.consumer.delivery.tracking;

/**
 * SingleCopyTrackingNumberTraceConfig는 낱권 처리건 배송 중인 주문을 주기적으로 체크를 해서 
 * 주문 결과를 처리하는 클래스입니다.
 * 
 * @version 1.0 2017.10.26
 * @author chheo
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class SingleCopyTrackingNumberTraceConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private SingleCopyScmDeliveryTasklet singleCopyScmDeliveryTasklet;
  
  
  // 매 2시간마다 실행한다.
  @Scheduled(cron = "0 0 0/2 * * ?")
 // @Scheduled(cron = "0 0 0/1 * * ?")
  public String runSingleCopyTrackingNumberTrace() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(singleCopyTrackingNumberTraceJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job singleCopyTrackingNumberTraceJob() {
    
    return jobBuilderFactory
        .get("singleCopyTrackingNumberTraceJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(singleCopyScmDeliveryStep())
        .build();
  }

  // 배송 중인 리스트를 통해 배송추적을 한다.
  @Bean
  public Step singleCopyScmDeliveryStep() {
    return stepBuilderFactory
        .get("singleCopyScmDeliveryStep")
        .tasklet(singleCopyScmDeliveryTasklet)
        .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
}
