package com.kids.schole.batch.support.hr.service;

import java.util.List;

import com.kids.schole.batch.support.hr.domain.PersonnelChange;

public interface PersonnelChangeService {

  public List<PersonnelChange> getPersonnelChangeOfMonthly();

  public List<PersonnelChange> getPersonnelChangeByType();
}
