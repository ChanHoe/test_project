package com.kids.schole.batch.support.sales.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * SalesInfoDaoImpl은 매출 집계 처리를 위한 DAO 클래스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
@Repository
public class SalesInfoDaoImpl implements SalesInfoDao {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public int insertDailySaleInfo(HashMap<String, String> param) throws Exception{
		
		sqlSession.delete("salesinfo.deleteDailySaleInfo", param);
		return sqlSession.insert("salesinfo.insertDailySaleInfo", param);
	}

	@Override
	public int insertMonthlySaleInfo(HashMap<String, String> param) throws Exception{

		sqlSession.delete("salesinfo.deleteMonthlySaleInfo", param);
		return sqlSession.insert("salesinfo.insertMonthlySaleInfo", param);
	}

	// 현재월별 인원현황
	@Override
	public List<HashMap<String, Object>> selectCurrentMonthlyEMPSaleInfoList(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectList("salesinfo.selectCurrentMonthlyEMPSaleInfoList", param);
	}

	// 월별 인원현황
	@Override
	public List<HashMap<String, Object>> selectMonthlyEMPSaleInfoList(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectList("salesinfo.selectMonthlyEMPSaleInfoList", param);
	}
	
	// 현재최근 발령 내역
	@Override
	public HashMap<String, Object> selectCurrentPersonnelChange(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectOne("salesinfo.selectCurrentPersonnelChange", param);
	}
	
	// 최근 발령 내역
	@Override
	public HashMap<String, Object> selectPersonnelChange(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectOne("salesinfo.selectPersonnelChange", param);
	}
	
	// 인원별 누적금액
	@Override
	public HashMap<String, Object> selectMonthlySaleInfoSum(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectOne("salesinfo.selectMonthlySaleInfoSum", param);
	}

	// 월별 미팅 참여 수
	@Override
	public int selectDailyMeetingCount(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectOne("salesinfo.selectDailyMeetingCount", param);
	}
	

	// 월별 인원 삭제
	@Override
	public int deleteMonthlyEmpInfo(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.delete("salesinfo.deleteMonthlyEmpInfo", param);
	}
	
	// 월간 인원 현황 입력
	@Override
	public int insertMonthlyEmpInfo(HashMap<String, Object> param) throws Exception{

		return sqlSession.insert("salesinfo.insertMonthlyEmpInfo", param);
	}

	// 월간 지점 조직 현황 
	@Override
	public List<HashMap<String, Object>> selectMonthlyORGBranchInfoList(
			HashMap<String, Object> param) throws Exception {

		return sqlSession.selectList("salesinfo.selectMonthlyORGBranchInfoList", param);
	}

	// 현재월별 지점 조직 현황 인원 집계
	@Override
	public List<HashMap<String, Object>> selectCurrentMonthlyORGEmpCount(
			HashMap<String, Object> param) throws Exception {

		return sqlSession.selectList("salesinfo.selectCurrentMonthlyORGEmpCount", param);
	}

	// 월별 지점 조직 현황 인원 집계
	@Override
	public List<HashMap<String, Object>> selectMonthlyORGEmpCount(
			HashMap<String, Object> param) throws Exception {

		return sqlSession.selectList("salesinfo.selectMonthlyORGEmpCount", param);
	}
	
	// 현재월별 지점 조직 등록 인원
	@Override
	public int selectCurrentMonthlyORGRegisterEmpCount(HashMap<String, Object> param) throws Exception{

		return sqlSession.selectOne("salesinfo.selectCurrentMonthlyORGRegisterEmpCount", param);
	}
	
	// 월별 지점 조직 등록 인원
	@Override
	public int selectMonthlyORGRegisterEmpCount(HashMap<String, Object> param) throws Exception{

		return sqlSession.selectOne("salesinfo.selectMonthlyORGRegisterEmpCount", param);
	}
	
	// 현재월별 지점 조직 해약 인원
	@Override
	public int selectCurrentMonthlyORGExpireEmpCount(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectOne("salesinfo.selectCurrentMonthlyORGExpireEmpCount", param);
	}
	
	// 월별 지점 조직 해약 인원
	@Override
	public int selectMonthlyORGExpireEmpCount(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.selectOne("salesinfo.selectMonthlyORGExpireEmpCount", param);
	}

	// 월별 조직 삭제
	@Override
	public int deleteMonthlyORGInfo(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.insert("salesinfo.deleteMonthlyORGInfo", param);
	}
	
	// 월별 조직 입력
	@Override
	public int insertMonthlyORGInfo(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.insert("salesinfo.insertMonthlyORGInfo", param);
	}

	// 월별 라운지 조직 입력
	@Override
	public int insertMonthlyORGLoungeInfo(HashMap<String, Object> param) throws Exception{
		
		return sqlSession.insert("salesinfo.insertMonthlyORGLoungeInfo", param);
	}
	
}
