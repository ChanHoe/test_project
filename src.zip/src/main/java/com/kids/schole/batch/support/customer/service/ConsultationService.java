package com.kids.schole.batch.support.customer.service;

/**
 * ConsultationService는 온라인상담을 위한 인터페이스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
public interface ConsultationService {

  int modifyCsConsultationVDAllot();
  
  int csConsultationVDAllotNoti();
  
}
