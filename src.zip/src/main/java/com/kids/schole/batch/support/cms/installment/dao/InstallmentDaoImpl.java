package com.kids.schole.batch.support.cms.installment.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;

@Repository
public class InstallmentDaoImpl implements InstallmentDao {

  @Autowired
  private SqlSession sqlSession;

  @Override
  public List<InstallmentPayment> selectInstallmentPaymentStatusWaitList(
      InstallmentPayment installmentPayment) {
    return sqlSession.selectList("installment.selectInstallmentPaymentStatusWaitList",
        installmentPayment);
  }

  @Override
  public void updateInstallmentPaymentStatusProcessing(String nowDate) {
    sqlSession.update("installment.updateInstallmentPaymentStatusProcessing", nowDate);
  }

  @Override
  public void updateInstallmentPaymentStatusFail(InstallmentPayment installmentPayment) {
    sqlSession.update("installment.updateInstallmentPaymentStatusFail", installmentPayment);
  }

  @Override
  public void updateInstallmentPaymentRequestStatus(
      InstallmentPaymentRequest installmentPaymentRequest) {
    sqlSession.update("installment.updateInstallmentPaymentRequestStatus",
        installmentPaymentRequest);
  }

  @Override
  public List<InstallmentPayment> selectInstallmentPaymentProcessingList(
      InstallmentPayment installmentPayment) {
    return sqlSession.selectList("installment.selectInstallmentPaymentProcessingList",
        installmentPayment);
  }

  @Override
  public void updateAllProcessingListDone(InstallmentPayment installmentPayment) {
    sqlSession.update("installment.updateAllProcessingListDone", installmentPayment);
  }

  @Override
  public void updateOrderPayDoneAmt(String paymentDueDate) {
    sqlSession.update("installment.updateOrderPayDoneAmt", paymentDueDate);
  }
  
  @Override
  public void updateConsumerOrderPayDoneAmt(String paymentDueDate) {
    sqlSession.update("installment.updateConsumerOrderPayDoneAmt", paymentDueDate);
  }

  @Override
  public void updateInstallmentPaymentRequestCheckStatus() {
    sqlSession.selectList("installment.updateInstallmentPaymentRequestCheckStatus");
  }

}
