package com.kids.schole.batch.support.hr.service;

public interface OrganizationEmpService {

  public void modifyOrganizationIdByPersonnelChange();
}
