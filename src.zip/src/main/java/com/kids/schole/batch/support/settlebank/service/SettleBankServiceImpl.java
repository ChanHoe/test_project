package com.kids.schole.batch.support.settlebank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.settlebank.dao.SettleBankDao;
import com.kids.schole.batch.support.settlebank.domain.Vacs;

@Service
public class SettleBankServiceImpl implements SettleBankService {

  @Autowired
  private SettleBankDao settleBankDao;
  
  @Override
  public List<Vacs> getVacsAhstLogList() {
    return settleBankDao.selectVacsAhstLogList();
  }

  @Override
  public void modifyVacsAhstLogTerminate(Vacs vacs) {
    settleBankDao.updateVacsAhstLogTerminate(vacs);
  }

}
