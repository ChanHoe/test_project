package com.kids.schole.batch.support.hr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kids.schole.batch.support.hr.dao.EmpDao;
import com.kids.schole.batch.support.hr.domain.Emp;
import com.kids.schole.batch.support.hr.domain.PersonnelChange;

@Service
public class EmpServiceImpl implements EmpService {

  @Autowired
  private EmpDao empDao;

  @Autowired
  private PersonnelChangeService personnelChangeService;

  @Override
  @Transactional
  public void modifyPositionCode() {

    List<PersonnelChange> personnelChangeList =
        personnelChangeService.getPersonnelChangeOfMonthly();


    for (PersonnelChange pc : personnelChangeList) {

      Emp paramEmp = new Emp();

      paramEmp.setEmpNumber(pc.getEmpNumber());
      paramEmp.setPositionCode(pc.getPositionCode());

      if ( pc.getPersonnelChangeType().contains("expi")) {
        paramEmp.setEmpStatus("expire");
      }

      empDao.updatePositionCode(paramEmp);
    }

  }

}
