package com.kids.schole.batch.support.delivery.dao;

import java.util.List;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

public interface ConsumerDeliveryDao {
  void updateConsumerDeliveryRequestStatusWait(DeliveryRequest deliveryRequest);
  
  List<Order> selectConsumerDeliveryStatusWaitList();
  
  void updateConsumerDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest);
  
  List<DeliveryRequest> selectConsumerDeliveryStatusScmDeliveryList();
  
  void updateConsumerDeliveryRequestStatus(DeliveryRequest deliveryRequest);
  
  int selectConsumerDeliveryStatusNotScmShippedCount(int orderId);
  
  void updateSingleCopyDeliveryStatusWait(SingleCopyDelivery singleCopyDelivery);
  
  List<SingleCopyOrder> selectSingleCopyDeliveryStatusWaitList();
  
  void updateSingleCopyDeliveryStatusScmAccept(SingleCopyDelivery singleCopyDelivery);
  
  List<SingleCopyDelivery> selectSingleCopyDeliveryStatusScmDeliveryList();
  
  void updateSingleCopyDeliveryStatus(SingleCopyDelivery singleCopyDelivery);
  
  int selectSingleCopyDeliveryStatusNotScmShippedCount(int singleCopyOrderId);
}
