package com.kids.schole.batch.support.cbbk.domain;

/**
 * CbbkUseHistory는 가상계좌 결제 할당 도메인 클래스입니다.
 * 
 * @version 1.0 2016.11.14
 * @author Jeongwon Son
 */
public class CbbkPaymentAllot {

  private int cbbkPaymentAllotId;
  private int cbbkPaymentRequestId;
  private int cbbkDepositHistoryId;
  private Long allotAmt;
  private int registeredEmpNumber;
  private String registeredDatetime;

  public int getCbbkPaymentAllotId() {
    return cbbkPaymentAllotId;
  }

  public void setCbbkPaymentAllotId(int cbbkPaymentAllotId) {
    this.cbbkPaymentAllotId = cbbkPaymentAllotId;
  }

  public int getCbbkPaymentRequestId() {
    return cbbkPaymentRequestId;
  }

  public void setCbbkPaymentRequestId(int cbbkPaymentRequestId) {
    this.cbbkPaymentRequestId = cbbkPaymentRequestId;
  }

  public int getCbbkDepositHistoryId() {
    return cbbkDepositHistoryId;
  }

  public void setCbbkDepositHistoryId(int cbbkDepositHistoryId) {
    this.cbbkDepositHistoryId = cbbkDepositHistoryId;
  }

  public Long getAllotAmt() {
    return allotAmt;
  }

  public void setAllotAmt(Long allotAmt) {
    this.allotAmt = allotAmt;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

}
