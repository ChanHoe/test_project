package com.kids.schole.batch.execute.cashreceipt.result;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.service.PgCashReceiptService;

/**
 * 현금영수증 결과조회(socket 통신)
 * socket 통신한 결과로 txt 파일이 생성된다.
 *
 * @author 최인혜
 */
@Component
public class ResultCashReceiptTasklet implements Tasklet {


  @Autowired
  private PgCashReceiptService pgCashReceiptService;

  @Override
  @SuppressWarnings("unchecked")
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    PgCashReceiptBatchLog cashReceiptBatchLog = (PgCashReceiptBatchLog) chunkContext.getStepContext()
        .getStepExecution().getJobExecution().getExecutionContext().get("cashReceiptBatchLog");

    String preDate = (String) chunkContext.getStepContext().getStepExecution()
                 .getJobExecution().getExecutionContext().get("preDate");
    String nowDate = (String) chunkContext.getStepContext().getStepExecution()
        .getJobExecution().getExecutionContext().get("nowDate");

    pgCashReceiptService.resultBatch(cashReceiptBatchLog, preDate, nowDate);

    return RepeatStatus.FINISHED;

  }

}
