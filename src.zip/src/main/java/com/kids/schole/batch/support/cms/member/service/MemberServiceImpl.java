package com.kids.schole.batch.support.cms.member.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.cms.member.dao.MemberDao;
import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.domain.OrderAttachedFile;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;

@Service
public class MemberServiceImpl implements MemberService {

  @Autowired
  private MemberDao memberDao;

  @Override
  public List<OrderAttachedFile> getOrderAttachedFileNewWaitList() {
    return memberDao.selectOrderAttachedFileNewWaitList();
  }

  @Override
  public void modifyMemberProofStatus(OrderAttachedFile orderAttachedFile) {
    memberDao.updateMemberProofStatus(orderAttachedFile);
  }

  @Override
  public List<OrderAttachedFile> getOrderAttachedFileProcessingList() {
    return memberDao.selectOrderAttachedFileProcessingList();
  }

  @Override
  public List<OrderAttachedFile> getOrderAttachedFileCancelList() {
    return memberDao.selectOrderAttachedFileCancelList();
  }

  @Override
  public List<Member> getMemberWaitList(InstallmentPaymentRequest installmentPaymentRequest) {
    return memberDao.selectMemberWaitList(installmentPaymentRequest);
  }

  @Override
  public void modifyApplicationStatusProcessing(InstallmentPaymentRequest installmentPaymentRequest) {
    memberDao.updateApplicationStatusProcessing(installmentPaymentRequest);
  }

  @Override
  public void modifyApplicationStatusFail(InstallmentPaymentRequest installmentPaymentRequest) {
    memberDao.updateApplicationStatusFail(installmentPaymentRequest);
  }

  @Override
  public List<Member> getMemberProcessingList(InstallmentPaymentRequest installmentPaymentRequest) {
    return memberDao.selectMemberProcessingList(installmentPaymentRequest);
  }

  @Override
  public void modifyAllProcessingListDone(InstallmentPaymentRequest installmentPaymentRequest) {
    memberDao.updateAllProcessingListDone(installmentPaymentRequest);
  }

  /** 할부계좌 변경한 주문 목록 */
  @Override
  public List<Member> getModifyAccountInstallments(InstallmentPaymentRequest installmentPaymentRequest) {
    return memberDao.selectModifyAccountInstallments(installmentPaymentRequest);
  }

  /** 할부계좌 변경한 목록의 회원신청 종류와 상태를 변경해준다.  */
  @Override
  public void modifyApplicationStatusWaitAndModify(int installmentPaymentRequestId) {
    memberDao.updateApplicationStatusWaitAndModify(installmentPaymentRequestId);
  }

}
