package com.kids.schole.batch.support.customer.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.customer.domain.CsAllotMapping;

/**
 * ConsultationDaoImpl은 온라인상담을 위한 DAO 클래스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
@Repository
public class ConsultationDaoImpl implements ConsultationDao {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public int updateCsConsultationVDAllot(CsAllotMapping csAllotMapping) {
		
		return sqlSession.update("consultation.updateCsConsultationVDAllot", csAllotMapping);
	}

	@Override
	public List<CsAllotMapping> selectCsConsultationAllotNoneList() {

		return sqlSession.selectList("consultation.selectCsConsultationAllotNoneList");
	}

	@Override
	public List<CsAllotMapping> selectCsConsultationAllotWaitList() {

		return sqlSession.selectList("consultation.selectCsConsultationAllotWaitList");
	}
  
}
