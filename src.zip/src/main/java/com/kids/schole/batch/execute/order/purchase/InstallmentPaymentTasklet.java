package com.kids.schole.batch.execute.order.purchase;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.batch.support.order.service.OrderService;
import com.kids.schole.common.constant.OrderConst;
import com.kids.schole.common.constant.PaymentConst;
import com.kids.schole.common.util.BusinessDayUtil;

@Component
public class InstallmentPaymentTasklet implements Tasklet {

  @Autowired
  private OrderService orderService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<CardPaymentRequest> cardPaymentRequestList =
        (List<CardPaymentRequest>) chunkContext.getStepContext().getStepExecution()
            .getJobExecution().getExecutionContext().get("cardPaymentRequestList");

    for (CardPaymentRequest cardPaymentRequest : cardPaymentRequestList) {
      // 할부일 경우 할부요청 테이블의 요청상태를 성공으로 수정하고
      // 할부 테이블의 1회차 할부 상태를 성공으로 수정을 한다.
      if (cardPaymentRequest.getPayAction().equals(OrderConst.PAY_ACTION_TYPE_INSTALLMENT)) {

        InstallmentPaymentRequest installmentPaymentRequest = new InstallmentPaymentRequest();
        installmentPaymentRequest.setPaymentId(cardPaymentRequest.getPaymentId());
        installmentPaymentRequest.setInstallmentPaymentRequestStatus(
            OrderConst.INSTALLMENT_PAYMENT_REQUEST_STATUS_SUCCESS);
        installmentPaymentRequest.setApplicationDate(getMemberApplyDate());
        installmentPaymentRequest
            .setApplicationType(PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_TYPE_NEW);
        installmentPaymentRequest
            .setApplicationStatus(PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_WAIT);
        installmentPaymentRequest.setLastUpdatedEmpNumber(99999);
        orderService.modifyInstallmentPaymentRequestStatus(installmentPaymentRequest);

        InstallmentPayment installmentPayment = new InstallmentPayment();
        installmentPayment.setPaymentId(cardPaymentRequest.getPaymentId());
        installmentPayment
            .setInstallmentPaymentStatus(OrderConst.INSTALLMENT_PAYMENT_STATUS_SUCCESS);
        installmentPayment.setLastUpdatedEmpNumber(99999);

        orderService.modifyInstallmentPaymentStatus(installmentPayment);

      }

    }

    return RepeatStatus.FINISHED;

  }

  private String getMemberApplyDate() {

    LocalDate today = LocalDate.now();
    String lastDayOfMonth = LocalDate.now().withDayOfMonth(today.lengthOfMonth())
        .format(DateTimeFormatter.ofPattern("yyyyMMdd"));

    if (BusinessDayUtil.isHoliday(lastDayOfMonth)) {
      return BusinessDayUtil.getBusinessDayCalc(lastDayOfMonth, -1);
    } else {
      return lastDayOfMonth;
    }

  }

}
