package com.kids.schole.batch.execute.cms.member;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class MemberApplyConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private MemberModifyWaitForChangeAccountTasklet memberModifyWaitForChangeAccountTasklet;

  @Autowired
  private MemberAllCancelTasklet memberAllCancelTasklet;

  @Autowired
  private MemberApplyTasklet memberApplyTasklet;

  // 2번 실행하는 이유는 (신청시) 한건이라도 오류가 나면 전체가 신청되지 않는다.
  // 그래서 해당오류건만 오류를 처리하고 오류를 제외한 나머지를 다시 신청을 한다.

  // 11시 40분에 실행
  @Scheduled(cron = "0 40 11 * * ?")
  public String runMemberApply() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(memberApplyJob(), param);

    return execution.getStatus().toString();
  }

  // 11시 45분에 실행
  // 두번째로 실행시에는 수정건의 상태를 변경할 필요가 없기때문에 
  // MemberModifyWaitForChangeAccountTasklet가 빠짐
  @Scheduled(cron = "0 45 11 * * ?")
  public String runAfterMemberApply() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(memberApplyJob2nd(), param);

    return execution.getStatus().toString();
  }

  @Bean
  public Job memberApplyJob() {

    return jobBuilderFactory
        .get("memberApplyJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(memberModifyWaitForChangeAccountStep())
        .next(memberAllCancelStep())
        .next(memberApplyStep())
        .build();
  }

  @Bean
  public Job memberApplyJob2nd() {
    
    return jobBuilderFactory
        .get("memberApplyJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(memberAllCancelStep())
        .next(memberApplyStep())
        .build();
  }

  @Bean
  public Step memberModifyWaitForChangeAccountStep() {
    return stepBuilderFactory
       .get("memberModifyWaitForChangeAccountStep")
       .tasklet(memberModifyWaitForChangeAccountTasklet)
       .build();
  }

  @Bean
  public Step memberAllCancelStep() {
    return stepBuilderFactory
        .get("memberAllCancelStep")
        .tasklet(memberAllCancelTasklet)
        .build();
  }

  @Bean
  public Step memberApplyStep() {
    return stepBuilderFactory
       .get("memberApplyStep")
       .tasklet(memberApplyTasklet)
       .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}