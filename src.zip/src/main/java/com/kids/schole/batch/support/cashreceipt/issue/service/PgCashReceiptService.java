package com.kids.schole.batch.support.cashreceipt.issue.service;

import java.util.List;

import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceipt;
import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceiptRefund;
import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.domain.SingleCopyCashReceipt;

public interface PgCashReceiptService {

  // -----------------------------------------------------------------------------------
  // Cashreceipt

  /** 현금영수증 대상건 생성 */
  void createCashReceipt(CashReceipt cashReceipt);

  /** 현금영수증 대상 조회(배치를 위함) */
  List<String> getCashReceiptsForIssue(String targetDate);
  /** 현금영수증 대상ID 조회(배치를 위함) */
  List<Integer> getCashReceiptIdsForIssue(String targetDate);

  /** 현금영수증  대상건(여러개) 수정 */
  void modifyCashReceiptForBatchLogId(PgCashReceiptBatchLog pgCashReceiptBatchLog);
  /** 현금영수증  대상건(한건) 수정(결과 수정) */
  void modifyCashReceiptResultById(CashReceipt cashReceipt);

  /** 가상계좌 현금영수증  대상건 생성(여러건) */
  void createCashReceiptsForCbbk(String nowDate);
  /** 할부 대체결제 가상계좌 현금영수증  대상건 생성(여러건) */
  void createCashReceiptsForCbbkSubstitute(String nowDate);

  /** 즉시출금 현금영수증  대상건 생성(여러건) */
  void createCashReceiptsForCms(String nowDate);
  /** 할부 대체결제 즉시출금 현금영수증  대상건 생성(여러건) */
  void createCashReceiptsForCmsSubstitute(String nowDate);

  /** 할부 현금영수증  대상건 생성(여러건) */
  void createCashReceiptsForInstallment(String nowDate);

  /** 현금영수증 취소 대상(여러건, 소비자 포함) */
  List<CashReceiptRefund> getCashReceiptsForRefund(String nowDate);
  /** 현금영수증 취소 대상 주문ID로 조회(한건) */
  List<CashReceipt> getCashReceiptsByOrderId(int orderId);

  /** 소비자 처리한 주문의 가상계좌 현금영수증 대상 생성을 위해 주문ID로 조회 */
  List<CashReceipt> getCbbkCashReceiptsForConsumerByOrderId(int orderId);
  /** 소비자 처리한 주문의 즉시출금 현금영수증 대상 생성을 위해 주문ID로 조회 */
  List<CashReceipt> getBankCashReceiptsForConsumerByOrderId(int orderId);
  /** 소비자 처리한 주문의 할부금 현금영수증 대상 생성을 위해 주문ID로 조회 */
  List<CashReceipt> getInstallmentCashReceiptsForConsumerByOrderId(int orderId);

  // -----------------------------------------------------------------------------------
  // SingleCopyCashReceipt

  /** 낱권유상 현금영수증 대상 조회 */
  List<String> getSingleCopyCashReceiptsForIssue(String targetDate);
  /** 낱권유상 현금영수증 대상ID 조회 */
  List<Integer> getSingleCopyCashReceiptIdsForIssue(String targetDate);

  /** 낱권유상 현금영수증  대상건(여러개) 수정 */
  void modifySingleCopyCashReceiptsForBatch(PgCashReceiptBatchLog pgCashReceiptBatchLog);
  /** 낱권유상 현금영수증  대상건(한건) 수정 */
  void modifySingleCopyCashReceiptResultById(SingleCopyCashReceipt singleCopyCashReceipt);

  // -----------------------------------------------------------------------------------
  // PgCashReceiptBatchLog

  /** 현금 영수증 배치 생성 */
  void createPgCashReceiptBatch(PgCashReceiptBatchLog pgCashReceiptBatchLog);
  /** 현금 영수증 배치 수정 */
  void modifyPgCashReceiptBatch(PgCashReceiptBatchLog pgCashReceiptBatchLog);

  /** 현금 영수증 배치 발행 요청 */
  void issueBatch(PgCashReceiptBatchLog cashReceiptBatchLog);
  /** 현금 영수증 배치 발행 결과 요청 */
  void resultBatch(PgCashReceiptBatchLog cashReceiptBatchLog, String fromDate, String thruDate);

}
