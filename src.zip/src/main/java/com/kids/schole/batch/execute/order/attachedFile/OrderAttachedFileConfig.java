package com.kids.schole.batch.execute.order.attachedFile;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * OrderAttachedFileConfig는 주문 계약서 관련을 처리하는 클래스입니다.
 * 
 * @version 1.0 2017.07.25
 * @author Jeongwon Son
 */

@Configuration
@EnableBatchProcessing
public class OrderAttachedFileConfig {
  
  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private ProofStatusChangeFailToWaitTasklet proofStatusChangeFailToWaitTasklet;

  // 매시 10분에 실행
  @Scheduled(cron = "0 10 0/1 * * ?")
  public String runProofStatusChangeRolls() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(proofStatusChangeJob(), param);

    return execution.getStatus().toString();
  }
  
  @Bean
  public Job proofStatusChangeJob() {

    return jobBuilderFactory
        .get("proofStatusChangeRollsJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(proofStatusChangeStep())
        .build();
  }
  
  // cms 회원 증빙 상태가 일주일 이내에 실패가 있으면 대기로 변경한다.
   @Bean
   public Step proofStatusChangeStep() {
     
     return stepBuilderFactory
         .get("proofStatusChangeStep")
         .tasklet(proofStatusChangeFailToWaitTasklet)
         .build();
   }
   
   @Bean
   public JobExecutionListener listener() {
     return new JobCompletionNotificationListener();
   }  
 
  
}
