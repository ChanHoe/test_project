package com.kids.schole.batch.support.sales.service;

/**
 * SalesInfoService는 매출 집계 처리를 위한 인터페이스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
public interface SalesInfoService {

  int createDailySaleInfo(String firstDate);
  
  int createMonthlySaleInfo(String firstDate);
  
  int createMonthlyEMPSaleInfo(String firstDate);
  
  int createMonthlyORGSaleInfo(String firstDate);
}
