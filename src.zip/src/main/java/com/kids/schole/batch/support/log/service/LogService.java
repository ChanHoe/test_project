package com.kids.schole.batch.support.log.service;

/**
 * LogService는 배치로그 삭제를 위한 인터페이스입니다.
 * 
 * @version 1.0 2017.01.04
 * @author Jeongwon Son
 */
public interface LogService {
  
  void removeBatchLogWithinTwoWeeks();
  
}
