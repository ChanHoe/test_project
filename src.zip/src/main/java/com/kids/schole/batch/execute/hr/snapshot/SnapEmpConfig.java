package com.kids.schole.batch.execute.hr.snapshot;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * 임직원 정보 스냅샷 저장을 위한 클래스입니다.
 *
 * @version 1.0 2017.02.10
 * @author Jaeeon Bae
 */
@Configuration
@EnableBatchProcessing
public class SnapEmpConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private SnapEmpTasklet snapEmpTasklet;

  @Autowired
  private SnapOrganizationTasklet snapOrganizationTasklet;

  @Autowired
  private SnapOrganizationEmpTasklet snapOrganizationEmpTasklet;

  @Autowired
  private SnapPersonnelChangeTasklet snapPersonnelChangeTasklet;

  // 매월 마지막날 23시 50분 -  "0 30 21 *L * ?"
//  @Scheduled(cron="0 50 23 *L * ?")
//  public String runSnapShot() throws Exception {
//
//    JobParameters param = new JobParametersBuilder()
//        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
//
//    JobExecution execution = jobLauncher.run(snapshotJob(), param);
//
//    return execution.getStatus().toString();
//  }

  // 매월 1일 00시 03분 00초
  @Scheduled(cron="0 3 0 1 * ?")
  public String runSnapShot2() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(snapshotJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job snapshotJob() {

    return jobBuilderFactory
            .get("snapshotJob")
            .incrementer(new RunIdIncrementer())
            .listener(listener())
            .start(snapEmpStep())
            .next(snapOrganizationEmpStep())
            .next(snapOrganizationStep())
            .next(snapPersonnelChangeStep())
            .build();
  }

  // 임직원 정보를 스냅샷 저장한다.
  @Bean
  public Step snapEmpStep() {

    return stepBuilderFactory
            .get("snapEmpStep")
            .tasklet(snapEmpTasklet)
            .build();
  }

  // 조직-임직원 매핑 정보를 스냅샷 저장한다.
  @Bean
  public Step snapOrganizationEmpStep() {

    return stepBuilderFactory
            .get("snapOrganizationEmpStep")
            .tasklet(snapOrganizationEmpTasklet)
            .build();
  }

  //조직 정보를 스냅샷 저장한다.
   @Bean
   public Step snapOrganizationStep() {

     return stepBuilderFactory
             .get("snapOrganizationStep")
             .tasklet(snapOrganizationTasklet)
             .build();
   }

  // 임직원 인사이동 내역 정보를 스냅샷 저장한다.
  @Bean
  public Step snapPersonnelChangeStep() {

    return stepBuilderFactory
            .get("snapPersonnelChangeStep")
            .tasklet(snapPersonnelChangeTasklet)
            .build();
  }

  @Bean
  public JobExecutionListener listener() {

    return new JobCompletionNotificationListener();
  }

}
