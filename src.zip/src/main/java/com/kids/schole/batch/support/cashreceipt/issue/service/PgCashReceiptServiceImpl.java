package com.kids.schole.batch.support.cashreceipt.issue.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.galaxia.api.Command;
import com.galaxia.api.ConfigInfo;
import com.galaxia.api.MessageTag;
import com.galaxia.api.ServiceCode;
import com.galaxia.api.cashreceipt.ServiceBroker;
import com.galaxia.api.crypto.GalaxiaCipher;
import com.galaxia.api.crypto.Seed;
import com.galaxia.api.merchant.Message;
import com.galaxia.api.util.DateUtil;
import com.kids.schole.batch.support.cashreceipt.issue.dao.PgCashReceiptDao;
import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceipt;
import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceiptRefund;
import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.domain.SingleCopyCashReceipt;
import com.kids.schole.common.constant.PaymentConst;
import com.kids.schole.common.properties.CashReceiptProperties;
import com.kids.schole.common.util.DomainUtil;
import com.kids.schole.common.util.PaymentGateUtil;
import com.kids.schole.common.util.StringUtil;

import sun.misc.BASE64Decoder;

@Service
public class PgCashReceiptServiceImpl implements PgCashReceiptService {

  @Autowired
  private CashReceiptProperties cashReceiptProperties;

  @Autowired
  private PgCashReceiptDao pgCashReceiptDao;

  // -----------------------------------------------------------------------------------
  // Cashreceipt

  @Override
  public void createCashReceipt(CashReceipt cashReceipt) {
    //
    pgCashReceiptDao.insertCashReceipt(cashReceipt);
  }

  @Override
  public List<String> getCashReceiptsForIssue(String targetDate) {
    //
    return pgCashReceiptDao.selectCashReceiptsForIssue(targetDate);
  }

  @Override
  public List<Integer> getCashReceiptIdsForIssue(String targetDate) {
    //
    return pgCashReceiptDao.selectCashReceiptIdsForIssue(targetDate);
  }

  @Override
  public void modifyCashReceiptForBatchLogId(PgCashReceiptBatchLog pgCashReceiptBatchLog) {
    //
    pgCashReceiptDao.updateCashReceiptForBatchLogId(pgCashReceiptBatchLog);
  }

  @Override
  public void modifyCashReceiptResultById(CashReceipt cashReceipt) {
    //
    pgCashReceiptDao.updateCashReceiptResultById(cashReceipt);
  }

  @Override
  public void createCashReceiptsForCbbk(String nowDate) {
    //
    pgCashReceiptDao.insertCashReceiptsForCbbk(nowDate);
  }

  @Override
  public void createCashReceiptsForCbbkSubstitute(String nowDate) {
    //
    pgCashReceiptDao.insertCashReceiptsForCbbkSubstitute(nowDate);
  }

  @Override
  public void createCashReceiptsForCms(String nowDate) {
    //
    pgCashReceiptDao.insertCashReceiptsForCms(nowDate);
  }

  @Override
  public void createCashReceiptsForCmsSubstitute(String nowDate) {
    //
    pgCashReceiptDao.insertCashReceiptsForCmsSubstitute(nowDate);
  }

  @Override
  public void createCashReceiptsForInstallment(String nowDate) {
    //
    pgCashReceiptDao.insertCashReceiptsForInstallment(nowDate);
  }

  @Override
  public List<CashReceiptRefund> getCashReceiptsForRefund(String nowDate) {
    //
    return pgCashReceiptDao.selectCashReceiptsForRefund(nowDate);
  }

  @Override
  public List<CashReceipt> getCashReceiptsByOrderId(int orderId) {
    //
    return pgCashReceiptDao.selectCashReceiptsByOrderId(orderId);
  }

  @Override
  public List<CashReceipt> getCbbkCashReceiptsForConsumerByOrderId(int orderId) {
    //
    return pgCashReceiptDao.selectCbbkCashReceiptsForConsumerByOrderId(orderId);
  }

  @Override
  public List<CashReceipt> getBankCashReceiptsForConsumerByOrderId(int orderId) {
    //
    return pgCashReceiptDao.selectBankCashReceiptsForConsumerByOrderId(orderId);
  }

  @Override
  public List<CashReceipt> getInstallmentCashReceiptsForConsumerByOrderId(int orderId) {
    //
    return pgCashReceiptDao.selectInstallmentCashReceiptsForConsumerByOrderId(orderId);
  }


  // -----------------------------------------------------------------------------------
  // SingleCopyCashReceipt

  @Override
  public List<String> getSingleCopyCashReceiptsForIssue(String targetDate) {
    return pgCashReceiptDao.selectSingleCopyCashReceiptsForIssue(targetDate);
  }

  @Override
  public List<Integer> getSingleCopyCashReceiptIdsForIssue(String targetDate) {
    return pgCashReceiptDao.selectSingleCopyCashReceiptIdsForIssue(targetDate);
  }

  @Override
  public void modifySingleCopyCashReceiptsForBatch(PgCashReceiptBatchLog pgCashReceiptBatchLog) {
    pgCashReceiptDao.updateSingleCopyCashReceiptsForBatch(pgCashReceiptBatchLog);
  }
  @Override
  public void modifySingleCopyCashReceiptResultById(SingleCopyCashReceipt singleCopyCashReceipt) {
    pgCashReceiptDao.updateSingleCopyCashReceiptResultById(singleCopyCashReceipt);
  }

  // -----------------------------------------------------------------------------------
  // PgCashReceiptBatchLog

  @Override
  public void createPgCashReceiptBatch(PgCashReceiptBatchLog cashReceiptBatchLog) {
    //
    pgCashReceiptDao.insertCashReceiptBatchLog(cashReceiptBatchLog);
  }

  @Override
  public void modifyPgCashReceiptBatch(PgCashReceiptBatchLog cashReceiptBatchLog) {
    //
    pgCashReceiptDao.updateCashReceiptBatchLog(cashReceiptBatchLog);
  }

  /** 현금 영수증 배치 발행 요청 */
  @SuppressWarnings("restriction")
  @Override
  public void issueBatch(PgCashReceiptBatchLog cashReceiptBatchLog) {
    //
    String requestFileName = cashReceiptBatchLog.getFilePath();
    requestFileName += cashReceiptBatchLog.getFileName(); //배치 파일명

    // 암호화 Chiper 생성 기본 암호화 algorithm은
    // SEED/CBC/PKCS5Padding 사용.(DES/ACE 추가 지원)
    Message responseMsg = null;
    try {

      GalaxiaCipher cipher = new Seed(); // Seed 암호화 생성
      cipher.setKey(new BASE64Decoder().decodeBuffer(this.cashReceiptProperties.getEncryptKey())); // 키 BASE64 Decoding
      cipher.setIV(this.cashReceiptProperties.getEncryptIv().getBytes()); // 암호화 Initialize Vector

      Message requestMsg = new Message(this.cashReceiptProperties.getProtocolVersion(), // Version
              this.cashReceiptProperties.getMid(), // 가맹점 서비스 아이디
              ServiceCode.CASH_RECEIPT, // 서비스 코드(현금영수증)
              Command.CASHRECEIPT_BATCH_REQUEST, //현금영수증 배치 파일 요청
              cashReceiptBatchLog.getCashReceiptBatchLogId()+"", // 주문번호(요성seq)
              DateUtil.getTodayTime(), // 주문일시(요청일시)
              cipher); // 암호화 Cipher

      if (StringUtil.isNotBlank(requestFileName))
          requestMsg.put(MessageTag.FILE_NAME, requestFileName);

      DomainUtil.retriveDomain(requestMsg);
      ServiceBroker sb = new ServiceBroker(PaymentGateUtil.getGalaxiaConfigEnvFilePath(), // Config 파일
              ServiceCode.CASH_RECEIPT, // 서비스코드(현금 영수증)
              ConfigInfo.BATCH); // 배치서비스

      // 발급 요청
      responseMsg = sb.invoke(requestMsg, "euc-kr");
      DomainUtil.retriveDomain(responseMsg);

    } catch (Exception e) {
      //
      e.printStackTrace();
    }

    cashReceiptBatchLog.setResponseCode(responseMsg.get(MessageTag.RESPONSE_CODE));
    cashReceiptBatchLog.setResponseMessage(responseMsg.get(MessageTag.RESPONSE_MESSAGE));
    cashReceiptBatchLog.setDetailResponseCode(responseMsg.get(MessageTag.DETAIL_RESPONSE_CODE));
    cashReceiptBatchLog.setDetailResponseMessage(responseMsg.get(MessageTag.DETAIL_RESPONSE_MESSAGE));
    cashReceiptBatchLog.setLastUpdatedEmpNumber(99999);
    pgCashReceiptDao.updateCashReceiptBatchLog(cashReceiptBatchLog);

  }

  /** 현금 영수증 배치 발행 결과 요청 */
  @SuppressWarnings("restriction")
  @Override
  public void resultBatch(PgCashReceiptBatchLog cashReceiptBatchLog, String fromDate, String thruDate) {
    //
    // 암호화 Chiper 생성 기본 암호화 algorithm은
    // SEED/CBC/PKCS5Padding 사용.(DES/ACE 추가 지원)
    Message responseMsg = null;
    try {
      GalaxiaCipher cipher = new Seed(); // Seed 암호화 생성
      cipher.setKey(new BASE64Decoder().decodeBuffer(this.cashReceiptProperties.getEncryptKey())); // 키 BASE64 Decoding
      cipher.setIV(this.cashReceiptProperties.getEncryptIv().getBytes()); // 암호화 Initialize Vector

      Message requestMsg = new Message(this.cashReceiptProperties.getProtocolVersion(), // Version
              this.cashReceiptProperties.getMid(), // 가맹점 서비스 아이디
              ServiceCode.CASH_RECEIPT, // 서비스 코드(현금영수증)
              Command.CASHRECEIPT_RESULT_REQUEST, //현금영수증 결과 파일 요청
              cashReceiptBatchLog.getCashReceiptBatchLogId()+"", // 주문번호
              DateUtil.getTodayTime(), // 주문 일시
              cipher); // 암호화 Cipher

      // 조회정보 설정(Body)
      requestMsg.put(MessageTag.ITEM_KIND, PaymentConst.CASH_RECEIPT_BATCH_RESULT_TYPE_RECEIPT) ;

      if (StringUtil.isNotBlank(fromDate) && StringUtil.isNotBlank(thruDate)) {
        requestMsg.put(MessageTag.SEARCH_START_DATE, fromDate) ;
        requestMsg.put(MessageTag.SEARCH_END_DATE, thruDate) ;
      } else {
        String searchDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        requestMsg.put(MessageTag.SEARCH_START_DATE, searchDate) ;
        requestMsg.put(MessageTag.SEARCH_END_DATE, searchDate) ;
      }
      if (StringUtil.isNotBlank(cashReceiptBatchLog.getFilePath())) {
        requestMsg.put(MessageTag.FILE_PATH, cashReceiptBatchLog.getFilePath()) ;
      }
      DomainUtil.retriveDomain(requestMsg);

      ServiceBroker sb = new ServiceBroker(PaymentGateUtil.getGalaxiaConfigEnvFilePath(), // Config 파일
              ServiceCode.CASH_RECEIPT, // 서비스 코드(현금 영수증)
              ConfigInfo.BATCH); // 배치 서비스

      // 결과 요청
      responseMsg = sb.invoke(requestMsg, "euc-kr");
      DomainUtil.retriveDomain(responseMsg);

    } catch (Exception e) {
      // TODO: handle exception
    }

    cashReceiptBatchLog.setResponseCode(responseMsg.get(MessageTag.RESPONSE_CODE));
    cashReceiptBatchLog.setResponseMessage(responseMsg.get(MessageTag.RESPONSE_MESSAGE));
    cashReceiptBatchLog.setDetailResponseCode(responseMsg.get(MessageTag.DETAIL_RESPONSE_CODE));
    cashReceiptBatchLog.setDetailResponseMessage(responseMsg.get(MessageTag.DETAIL_RESPONSE_MESSAGE));
    cashReceiptBatchLog.setLastUpdatedEmpNumber(99999);
    pgCashReceiptDao.updateCashReceiptBatchLog(cashReceiptBatchLog);

  }

}
