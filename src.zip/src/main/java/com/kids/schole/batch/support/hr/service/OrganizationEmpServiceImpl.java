package com.kids.schole.batch.support.hr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kids.schole.batch.support.hr.dao.OrganizationEmpDao;
import com.kids.schole.batch.support.hr.domain.OrganizationEmp;
import com.kids.schole.batch.support.hr.domain.PersonnelChange;

@Service
public class OrganizationEmpServiceImpl implements OrganizationEmpService {

  @Autowired
  private PersonnelChangeService personnelChangeService;

  @Autowired
  private OrganizationEmpDao organizationEmpDao;

  @Override
  @Transactional
  public void modifyOrganizationIdByPersonnelChange() {

    List<PersonnelChange> personnelChangeList = personnelChangeService.getPersonnelChangeByType();

    for (PersonnelChange personnelChange : personnelChangeList) {

      OrganizationEmp organizationEmp = new OrganizationEmp();
      organizationEmp.setEmpNumber(personnelChange.getEmpNumber());
      organizationEmp.setOrganizationId(personnelChange.getAffiliationOrganizationId());

      organizationEmpDao.updateOrganizationId(organizationEmp);
    }

  }

}
