package com.kids.schole.batch.execute.cashreceipt.issue;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cashreceipt.issue.service.PgCashReceiptService;
import com.kids.schole.common.util.BusinessDayUtil;

/**
 * 현금영수증 대상을 생성
 *
 * @author 최인혜
 */
@Component
public class CashReceiptTargetTasklet implements Tasklet {

  @Autowired
  private PgCashReceiptService pgCashReceiptService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    // 현금영수증은 수금 다음날 새벽에 배치가 돌기 때문에
    String preDate = LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

    // 1. 가상계좌 계약금 결제건(일시불 포함)
    pgCashReceiptService.createCashReceiptsForCbbk(preDate);
    // 가상계좌 할부 대체결제건
    pgCashReceiptService.createCashReceiptsForCbbkSubstitute(preDate);

    // 2. 즉시출금 계약금 결제건(일시불 포함)
    pgCashReceiptService.createCashReceiptsForCms(preDate);
    // 즉시출금 할부금 대체결제 결제건
    pgCashReceiptService.createCashReceiptsForCmsSubstitute(preDate);

    // 3. 할부금은 결과가 2일 후에 나기 때문.(거기에 또 +1일이 되기 때문)
    String paymentDueDate = BusinessDayUtil.getBusinessDayCalc(nowDate, -3);
    pgCashReceiptService.createCashReceiptsForInstallment(paymentDueDate);

    return RepeatStatus.FINISHED;

  }

}
