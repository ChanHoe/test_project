package com.kids.schole.batch.execute.cbbk.autoAllotCombine;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequestCombine;
import com.kids.schole.batch.support.cbbk.service.CbbkService;

@Component
public class OrderStatusCbbkReadyCombineTasklet implements Tasklet {

  @Autowired
  private CbbkService cbbkService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    List<CbbkPaymentRequestCombine> cbbkPaymentRequestReadyCombineList =
        cbbkService.getCbbkPaymentRequestReadyCombineList();
    
    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("cbbkPaymentRequestReadyCombineList", cbbkPaymentRequestReadyCombineList);

    return RepeatStatus.FINISHED;
  }

}
