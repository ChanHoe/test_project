package com.kids.schole.batch.support.cashreceipt.issue.domain;

/**
 * 현금영수증 환불
 *
 * @author 최인혜
 *
 */
public class CashReceiptRefund {

  private int orderId;
  private String orderNumber;

  /** 해당 주문이 소비자 처리를 한 건인지 여부 */
  private boolean consumerOrder;
  /** 해당 주문이 소비자 처리를 해서 손료가 있는지 여부 */
  private boolean lossOccur;
  /** 해당 주문이 소비자 처리를 당월에 했는지 여부 */
  private boolean monthConsumer;

  /** 해당 주문의 부모주문ID */
  private int parentsOrderId;
  /** 해당 주문의 자식주문ID */
  private int childOrderId;

  /** 해당 주문이 취소된 주문인지 여부 */
  private boolean canceledOrder;

  /** 환불금액 */
  private long refundAmt;

  private CashReceipt cashReceipt;

  public int getOrderId() {
    return orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public String getOrderNumber() {
    return orderNumber;
  }

  public void setOrderNumber(String orderNumber) {
    this.orderNumber = orderNumber;
  }

  public boolean isConsumerOrder() {
    return consumerOrder;
  }

  public void setConsumerOrder(boolean consumerOrder) {
    this.consumerOrder = consumerOrder;
  }

  public boolean isLossOccur() {
    return lossOccur;
  }

  public void setLossOccur(boolean lossOccur) {
    this.lossOccur = lossOccur;
  }

  public boolean isMonthConsumer() {
    return monthConsumer;
  }

  public void setMonthConsumer(boolean monthConsumer) {
    this.monthConsumer = monthConsumer;
  }

  public CashReceipt getCashReceipt() {
    return cashReceipt;
  }

  public void setCashReceipt(CashReceipt cashReceipt) {
    this.cashReceipt = cashReceipt;
  }

  public boolean isCanceledOrder() {
    return canceledOrder;
  }

  public void setCanceledOrder(boolean canceledOrder) {
    this.canceledOrder = canceledOrder;
  }

  public long getRefundAmt() {
    return refundAmt;
  }

  public void setRefundAmt(long refundAmt) {
    this.refundAmt = refundAmt;
  }

  public int getChildOrderId() {
    return childOrderId;
  }

  public void setChildOrderId(int childOrderId) {
    this.childOrderId = childOrderId;
  }

  public int getParentsOrderId() {
    return parentsOrderId;
  }

  public void setParentsOrderId(int parentsOrderId) {
    this.parentsOrderId = parentsOrderId;
  }



}
