package com.kids.schole.batch.support.hr.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.hr.dao.SnapEmpDao;
import com.kids.schole.batch.support.hr.domain.SnapEmp;
import com.kids.schole.batch.support.hr.domain.SnapOrganizationEmp;
import com.kids.schole.batch.support.hr.domain.SnapPersonnelChange;
import com.kids.schole.batch.support.hr.domain.SnapOrganization;

@Service
public class SnapEmpServiceImple implements SnapEmpService {

  /** 로거를 위한 변수 입니다. */
  private final Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private SnapEmpDao snapEmpDao;
  
  /**
   * 스냅샷 - 임직원 정보를 저장한다.
   * 
   * @return void
   */
  @Override
  public void createSnapEmp() {
    // TODO Auto-generated method stub
    List<SnapEmp> empList = snapEmpDao.selectEmpList();
    
    SnapEmp snapEmp = new SnapEmp();
    
    // 현재 년도, 월
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
    Calendar calendar = Calendar.getInstance();

    String todayDate = sdf.format(calendar.getTime());
    String thisYear = todayDate.substring(0,4); // 이번 년도
    String thisMonth = todayDate.substring(4);  // 월

    logger.debug("년도,월 확인 {} {} " , thisYear, thisMonth);
    
    // 이번 년도, 월 있는 경우 삭제
    snapEmp.setSaleYear(thisYear);
    snapEmp.setSaleMonth(thisMonth);
    snapEmpDao.deleteSnapEmp(snapEmp);
    
    empList.forEach(emp->{
      emp.setSaleYear(thisYear);
      emp.setSaleMonth(thisMonth);
    });
    snapEmpDao.insertSnapEmp(empList);
    
  }
  
  /**
   * 스냅샷 - 조직, 사원 정보를 저장한다.
   * 
   * @return void
   */
  @Override
  public void createSnapOrganizationEmp() {
    // TODO Auto-generated method stub
    List<SnapOrganizationEmp> organizationEmpList = snapEmpDao.selectOrganizationEmpList();
    
    SnapOrganizationEmp snapOrganizationEmp = new SnapOrganizationEmp();
    
    // 현재 년도, 월
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
    Calendar calendar = Calendar.getInstance();

    String todayDate = sdf.format(calendar.getTime());
    String thisYear = todayDate.substring(0,4); // 이번 년도
    String thisMonth = todayDate.substring(4);  // 월

    // 이번 년도, 월 있는 경우 삭제
    snapOrganizationEmp.setSaleYear(thisYear);
    snapOrganizationEmp.setSaleMonth(thisMonth);
    snapEmpDao.deleteSnapOrganizationEmp(snapOrganizationEmp);
    
    organizationEmpList.forEach(organizatoinEmp ->{
      organizatoinEmp.setSaleYear(thisYear);
      organizatoinEmp.setSaleMonth(thisMonth);
    });
    snapEmpDao.insertSnapOrganizationEmp(organizationEmpList);
    
  }
  
  /**
   * 스냅샷 - 조직을 저장한다.
   * 
   * @return void
   */
  @Override
  public void createSnapOrganiztion() {
    // TODO Auto-generated method stub
    List<SnapOrganization> organizationList = snapEmpDao.selectOrganizationList();
    
    SnapOrganization snapOrganization = new SnapOrganization();

    // 현재 년도, 월
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
    Calendar calendar = Calendar.getInstance();

    String todayDate = sdf.format(calendar.getTime());
    String thisYear = todayDate.substring(0,4); // 이번 년도
    String thisMonth = todayDate.substring(4);  // 월

    // 이번 년도, 월 있는 경우 삭제
    snapOrganization.setSaleYear(thisYear);
    snapOrganization.setSaleMonth(thisMonth);
    snapEmpDao.deleteSnapOrganization(snapOrganization);
    
    organizationList.forEach(organization->{
      organization.setSaleYear(thisYear);
      organization.setSaleMonth(thisMonth);
    });
    snapEmpDao.insertSnapOrganization(organizationList);
    
  }
  
  /**
   * 스냅샷 - 발령이력을 저장한다.
   * 
   * @return void
   */
  @Override
  public void createSnapPersonnelChange() {
    // TODO Auto-generated method stub
    List<SnapPersonnelChange> personnelChangeList = snapEmpDao.selectPersonnelChangeList();
    
    SnapPersonnelChange snapPersonnelChange = new SnapPersonnelChange();

    // 현재 년도, 월
    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
    Calendar calendar = Calendar.getInstance();

    String todayDate = sdf.format(calendar.getTime());
    String thisYear = todayDate.substring(0,4); // 이번 년도
    String thisMonth = todayDate.substring(4);  // 월

    // 이번 년도, 월 있는 경우 삭제
    snapPersonnelChange.setSaleYear(thisYear);
    snapPersonnelChange.setSaleMonth(thisMonth);
    snapEmpDao.deleteSnapPersonnelChange(snapPersonnelChange);
    
    personnelChangeList.forEach(personnel->{
      personnel.setSaleYear(thisYear);
      personnel.setSaleMonth(thisMonth);
    });
    snapEmpDao.insertSnapPersonnelChange(personnelChangeList);
    
  }
  
}
