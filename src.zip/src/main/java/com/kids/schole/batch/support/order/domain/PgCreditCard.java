package com.kids.schole.batch.support.order.domain;

/**
 * PgCreditCard은 PG 신용카드 관련 전문통신을 위한 요청, 응답값의 VO 이다.
 * 
 * @version 1.0 2016.11.19
 * @author Jeongho Baek
 */
public class PgCreditCard {

  // 요청 Parameter
  private String version;
  private String serviceId;
  private String orderId;
  private String orderDate;
  private String userId;
  private String userName;
  private String itemCode;
  private String itemName;
  private String userEmail;
  private String userIp;
  private String dealAmount;
  private String pinNumber;
  private String expireDate;
  private String password;
  private String cvc2;
  private String socialNumber;
  private String quota;
  private String vat;
  private String serviceCharge;
  private String certType;
  private String dealType;
  private String usingType;
  private String currency;
  private String opcode;

  // 응답 Parameter
  private String serviceCode;
  private String resonpseCommand;
  private String transactionId;
  private String issueCompanyCode;
  private String issueCompanyName;
  private String buyCompanyCode;
  private String buyCompanyName;
  private String responseCode;
  private String responseMessage;
  private String detailResponseCode;
  private String detailResponseMessage;
  private String authNumber;
  private String authDate;
  private String authAmount;

  // 기타 Parameter
  private String payerRelation;

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getServiceId() {
    return serviceId;
  }

  public void setServiceId(String serviceId) {
    this.serviceId = serviceId;
  }

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public String getOrderDate() {
    return orderDate;
  }

  public void setOrderDate(String orderDate) {
    this.orderDate = orderDate;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getItemCode() {
    return itemCode;
  }

  public void setItemCode(String itemCode) {
    this.itemCode = itemCode;
  }

  public String getItemName() {
    return itemName;
  }

  public void setItemName(String itemName) {
    this.itemName = itemName;
  }

  public String getUserEmail() {
    return userEmail;
  }

  public void setUserEmail(String userEmail) {
    this.userEmail = userEmail;
  }

  public String getUserIp() {
    return userIp;
  }

  public void setUserIp(String userIp) {
    this.userIp = userIp;
  }

  public String getDealAmount() {
    return dealAmount;
  }

  public void setDealAmount(String dealAmount) {
    this.dealAmount = dealAmount;
  }

  public String getPinNumber() {
    return pinNumber;
  }

  public void setPinNumber(String pinNumber) {
    this.pinNumber = pinNumber;
  }

  public String getExpireDate() {
    return expireDate;
  }

  public void setExpireDate(String expireDate) {
    this.expireDate = expireDate;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String getCvc2() {
    return cvc2;
  }

  public void setCvc2(String cvc2) {
    this.cvc2 = cvc2;
  }

  public String getSocialNumber() {
    return socialNumber;
  }

  public void setSocialNumber(String socialNumber) {
    this.socialNumber = socialNumber;
  }

  public String getQuota() {
    return quota;
  }

  public void setQuota(String quota) {
    this.quota = quota;
  }

  public String getVat() {
    return vat;
  }

  public void setVat(String vat) {
    this.vat = vat;
  }

  public String getServiceCharge() {
    return serviceCharge;
  }

  public void setServiceCharge(String serviceCharge) {
    this.serviceCharge = serviceCharge;
  }

  public String getCertType() {
    return certType;
  }

  public void setCertType(String certType) {
    this.certType = certType;
  }

  public String getDealType() {
    return dealType;
  }

  public void setDealType(String dealType) {
    this.dealType = dealType;
  }

  public String getUsingType() {
    return usingType;
  }

  public void setUsingType(String usingType) {
    this.usingType = usingType;
  }

  public String getCurrency() {
    return currency;
  }

  public void setCurrency(String currency) {
    this.currency = currency;
  }

  public String getOpcode() {
    return opcode;
  }

  public void setOpcode(String opcode) {
    this.opcode = opcode;
  }

  public String getServiceCode() {
    return serviceCode;
  }

  public void setServiceCode(String serviceCode) {
    this.serviceCode = serviceCode;
  }

  public String getResonpseCommand() {
    return resonpseCommand;
  }

  public void setResonpseCommand(String resonpseCommand) {
    this.resonpseCommand = resonpseCommand;
  }

  public String getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(String transactionId) {
    this.transactionId = transactionId;
  }

  public String getIssueCompanyCode() {
    return issueCompanyCode;
  }

  public void setIssueCompanyCode(String issueCompanyCode) {
    this.issueCompanyCode = issueCompanyCode;
  }

  public String getIssueCompanyName() {
    return issueCompanyName;
  }

  public void setIssueCompanyName(String issueCompanyName) {
    this.issueCompanyName = issueCompanyName;
  }

  public String getBuyCompanyCode() {
    return buyCompanyCode;
  }

  public void setBuyCompanyCode(String buyCompanyCode) {
    this.buyCompanyCode = buyCompanyCode;
  }

  public String getBuyCompanyName() {
    return buyCompanyName;
  }

  public void setBuyCompanyName(String buyCompanyName) {
    this.buyCompanyName = buyCompanyName;
  }

  public String getResponseCode() {
    return responseCode;
  }

  public void setResponseCode(String responseCode) {
    this.responseCode = responseCode;
  }

  public String getResponseMessage() {
    return responseMessage;
  }

  public void setResponseMessage(String responseMessage) {
    this.responseMessage = responseMessage;
  }

  public String getDetailResponseCode() {
    return detailResponseCode;
  }

  public void setDetailResponseCode(String detailResponseCode) {
    this.detailResponseCode = detailResponseCode;
  }

  public String getDetailResponseMessage() {
    return detailResponseMessage;
  }

  public void setDetailResponseMessage(String detailResponseMessage) {
    this.detailResponseMessage = detailResponseMessage;
  }

  public String getAuthNumber() {
    return authNumber;
  }

  public void setAuthNumber(String authNumber) {
    this.authNumber = authNumber;
  }

  public String getAuthDate() {
    return authDate;
  }

  public void setAuthDate(String authDate) {
    this.authDate = authDate;
  }

  public String getAuthAmount() {
    return authAmount;
  }

  public void setAuthAmount(String authAmount) {
    this.authAmount = authAmount;
  }

  public String getPayerRelation() {
    return payerRelation;
  }

  public void setPayerRelation(String payerRelation) {
    this.payerRelation = payerRelation;
  }

}
