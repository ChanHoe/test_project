package com.kids.schole.batch.support.albam.domain;

public class UserUpdateResult {
  
  private Integer storeId; // 상점 고유 ID
  private Integer userId;  // 알밤 고유 ID(휴대폰/이메일)
  private String staffName; // 직원 이름
  private String convertStartTime;
  private String convertEndTime;
  private String customerName;
  private String customerValue; // empKey

  public Integer getStoreId() {
    return storeId;
  }
  public void setStoreId(Integer storeId) {
    this.storeId = storeId;
  }
  public Integer getUserId() {
    return userId;
  }
  public void setUserId(Integer userId) {
    this.userId = userId;
  }
  public String getStaffName() {
    return staffName;
  }
  public void setStaffName(String staffName) {
    this.staffName = staffName;
  }
  public String getConvertStartTime() {
    return convertStartTime;
  }
  public void setConvertStartTime(String convertStartTime) {
    this.convertStartTime = convertStartTime;
  }
  public String getConvertEndTime() {
    return convertEndTime;
  }
  public void setConvertEndTime(String convertEndTime) {
    this.convertEndTime = convertEndTime;
  }
  public String getCustomerName() {
    return customerName;
  }
  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }
  public String getCustomerValue() {
    return customerValue;
  }
  public void setCustomerValue(String customerValue) {
    this.customerValue = customerValue;
  }
  
}
