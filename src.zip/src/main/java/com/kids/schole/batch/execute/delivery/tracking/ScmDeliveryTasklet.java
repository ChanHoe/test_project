package com.kids.schole.batch.execute.delivery.tracking;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberAllStepData;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResponseStatus;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResult;
import com.kids.schole.batch.support.delivery.service.DeliveryService;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.service.OrderService;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.OrderConst;
import com.kids.schole.common.constant.WarehouseConst;
import com.kids.schole.common.properties.WarehouseProperties;
import com.kids.schole.common.util.DomainUtil;

@Component
public class ScmDeliveryTasklet implements Tasklet {

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private OrderService orderService;

  @Autowired
  private DeliveryService deliveryService;

  @Autowired
  private WarehouseProperties warehouseProperties;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 현재 배송 중인 주문 리스트를 가져온다.
    List<DeliveryRequest> deliveryRequestList = deliveryService.getDeliveryStatusScmDeliveryList();

    for (DeliveryRequest deliveryRequest : deliveryRequestList) {

      URI uri = UriComponentsBuilder.fromUriString(warehouseProperties.getTrackingUrl())
          .path(WarehouseConst.INVOICE_CJ + deliveryRequest.getInvoiceNumber()).build().encode()
          .toUri();

      RestTemplate restTemplate = new RestTemplate();
      String responseJson = restTemplate.getForObject(uri, String.class);

      Gson gson = new GsonBuilder()
          .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus =
          gson.fromJson(responseJson, TrackingNumberTraceResponseStatus.class);

      deliveryRequest.setTrackingNumberTraceResponseStatus(trackingNumberTraceResponseStatus);

    }

    for (DeliveryRequest deliveryRequest : deliveryRequestList) {

      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus =
          deliveryRequest.getTrackingNumberTraceResponseStatus();

      TrackingNumberTraceResult trackingNumberTraceResult =
          deliveryRequest.getTrackingNumberTraceResponseStatus().getTrackingNumberTraceResult();

      // 결과값이 정상이면
      if (trackingNumberTraceResponseStatus.getResultCode().equals("0000")) {
        DeliveryRequest tempDeliveryRequest = new DeliveryRequest();
        tempDeliveryRequest.setDeliveryRequestId(deliveryRequest.getDeliveryRequestId());
        tempDeliveryRequest.setLastUpdatedEmpNumber(99999);

        if (trackingNumberTraceResult.getLastStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
          tempDeliveryRequest
              .setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_SHIPPED);
          deliveryService.modifyDeliveryRequestStatus(tempDeliveryRequest);
        } else {

          // 마지막 배송상태가 배송완료가 아닌경우 모든 배달과정을 찾아서 배달완료인지를 체크를 한다.
          List<TrackingNumberAllStepData> trackingNumberAllStepDataList =
              trackingNumberTraceResult.getTrackingNumberAllStepDataList();

          boolean isShipped = false;

          for (TrackingNumberAllStepData trackingNumberAllStepData : trackingNumberAllStepDataList) {
            if (trackingNumberAllStepData.getStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
              isShipped = true;
              break;
            }
          }

          // 배달과정에 배달완료가 있으면 배달완료로 처리를 한다.
          if (isShipped) {
            tempDeliveryRequest
                .setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_SHIPPED);
            deliveryService.modifyDeliveryRequestStatus(tempDeliveryRequest);

          }

        }

      }

    }


    for (DeliveryRequest deliveryRequest : deliveryRequestList) {

      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus =
          deliveryRequest.getTrackingNumberTraceResponseStatus();

      TrackingNumberTraceResult trackingNumberTraceResult =
          deliveryRequest.getTrackingNumberTraceResponseStatus().getTrackingNumberTraceResult();

      // 결과값이 정상이면
      if (trackingNumberTraceResponseStatus.getResultCode().equals("0000")) {
        Order order = new Order();
        order.setOrderId(deliveryRequest.getOrderId());
        order.setDeliveryDoneDate(
            trackingNumberTraceResponseStatus.getTrackingNumberTraceResult().getLastStepTime());
        order.setSalesDoneDate(
            trackingNumberTraceResponseStatus.getTrackingNumberTraceResult().getLastStepTime());
        order.setLastUpdatedEmpNumber(99999);

        if (trackingNumberTraceResult.getLastStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
          order.setOrderStatus(OrderConst.ORDER_STATUS_DONE);
          // 모든 물류가 배송완료가 되었으면 주문 완료가 된다.
          if (deliveryService.getDeliveryStatusNotScmShippedCount(deliveryRequest.getOrderId()) == 0) {
            orderService.modifyOrderStatusDone(order);
          }

        } else {

          // 마지막 배송상태가 배송완료가 아닌경우 모든 배달과정을 찾아서 배달완료인지를 체크를 한다.
          List<TrackingNumberAllStepData> trackingNumberAllStepDataList =
              trackingNumberTraceResult.getTrackingNumberAllStepDataList();

          boolean isShipped = false;
          for (TrackingNumberAllStepData trackingNumberAllStepData : trackingNumberAllStepDataList) {

            if (trackingNumberAllStepData.getStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
              isShipped = true;
              order.setDeliveryDoneDate(trackingNumberAllStepData.getStepTime());
              order.setSalesDoneDate(trackingNumberAllStepData.getStepTime());
              order.setOrderStatus(OrderConst.ORDER_STATUS_DONE);
              break;
            }
          }

          // 배송과정중에 배달완료가 있으면 주문완료로 처리를 한다.
          if (isShipped) {
            if (deliveryService.getDeliveryStatusNotScmShippedCount(deliveryRequest.getOrderId()) == 0) {
              orderService.modifyOrderStatusDone(order);
            }
          }

        }
      }

    }


//    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
//        .put("deliveryRequestList", deliveryRequestList);

    return RepeatStatus.FINISHED;

  }

}
