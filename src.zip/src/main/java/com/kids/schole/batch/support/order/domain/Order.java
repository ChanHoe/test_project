package com.kids.schole.batch.support.order.domain;

public class Order {

  private int orderId;
  private int customerId;
  private String orderNumber;
  private String payAction;
  private String payActionName;
  private long orderTotalAmt;
  private long payDoneAmt;
  private long paymentAmt;
  private long pointAmt;
  private long discountAmt;
  private long cancelAmt;
  private long payTaxableAmt;
  private long payVatAmt;
  private long payNonTaxableAmt;
  private int parentsOrderId;
  private String receiverName;
  private String receiverPhoneNumber;
  private String receiverMobileNumber;
  private String receiverRelation;
  private String deliveryPostcode;
  private String deliveryAddress;
  private String deliveryAddressDetail;
  private String deliveryRequestDate;
  private String deliveryDoneDate;
  private String deliveryMessage;
  private String salesDoneDate;
  private String orderStatus;
  private String orderStatusName;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  private int deliveryRequestId;
  private int productId;
  private String warehouseContentsKey;
  private String warehouseCompleteKey;
  private int paymentId;

  public int getOrderId() {
    return orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public int getCustomerId() {
    return customerId;
  }

  public void setCustomerId(int customerId) {
    this.customerId = customerId;
  }

  public String getOrderNumber() {
    return orderNumber;
  }

  public void setOrderNumber(String orderNumber) {
    this.orderNumber = orderNumber;
  }

  public String getPayAction() {
    return payAction;
  }

  public void setPayAction(String payAction) {
    this.payAction = payAction;
  }

  public String getPayActionName() {
    return payActionName;
  }

  public void setPayActionName(String payActionName) {
    this.payActionName = payActionName;
  }

  public long getOrderTotalAmt() {
    return orderTotalAmt;
  }

  public void setOrderTotalAmt(long orderTotalAmt) {
    this.orderTotalAmt = orderTotalAmt;
  }

  public long getPayDoneAmt() {
    return payDoneAmt;
  }

  public void setPayDoneAmt(long payDoneAmt) {
    this.payDoneAmt = payDoneAmt;
  }

  public long getPaymentAmt() {
    return paymentAmt;
  }

  public void setPaymentAmt(long paymentAmt) {
    this.paymentAmt = paymentAmt;
  }

  public long getPointAmt() {
    return pointAmt;
  }

  public void setPointAmt(long pointAmt) {
    this.pointAmt = pointAmt;
  }

  public long getDiscountAmt() {
    return discountAmt;
  }

  public void setDiscountAmt(long discountAmt) {
    this.discountAmt = discountAmt;
  }

  public long getCancelAmt() {
    return cancelAmt;
  }

  public void setCancelAmt(long cancelAmt) {
    this.cancelAmt = cancelAmt;
  }

  public long getPayTaxableAmt() {
    return payTaxableAmt;
  }

  public void setPayTaxableAmt(long payTaxableAmt) {
    this.payTaxableAmt = payTaxableAmt;
  }

  public long getPayVatAmt() {
    return payVatAmt;
  }

  public void setPayVatAmt(long payVatAmt) {
    this.payVatAmt = payVatAmt;
  }

  public long getPayNonTaxableAmt() {
    return payNonTaxableAmt;
  }

  public void setPayNonTaxableAmt(long payNonTaxableAmt) {
    this.payNonTaxableAmt = payNonTaxableAmt;
  }

  public int getParentsOrderId() {
    return parentsOrderId;
  }

  public void setParentsOrderId(int parentsOrderId) {
    this.parentsOrderId = parentsOrderId;
  }

  public String getReceiverName() {
    return receiverName;
  }

  public void setReceiverName(String receiverName) {
    this.receiverName = receiverName;
  }

  public String getReceiverPhoneNumber() {
    return receiverPhoneNumber;
  }

  public void setReceiverPhoneNumber(String receiverPhoneNumber) {
    this.receiverPhoneNumber = receiverPhoneNumber;
  }

  public String getReceiverMobileNumber() {
    return receiverMobileNumber;
  }

  public void setReceiverMobileNumber(String receiverMobileNumber) {
    this.receiverMobileNumber = receiverMobileNumber;
  }

  public String getReceiverRelation() {
    return receiverRelation;
  }

  public void setReceiverRelation(String receiverRelation) {
    this.receiverRelation = receiverRelation;
  }

  public String getDeliveryPostcode() {
    return deliveryPostcode;
  }

  public void setDeliveryPostcode(String deliveryPostcode) {
    this.deliveryPostcode = deliveryPostcode;
  }

  public String getDeliveryAddress() {
    return deliveryAddress;
  }

  public void setDeliveryAddress(String deliveryAddress) {
    this.deliveryAddress = deliveryAddress;
  }

  public String getDeliveryAddressDetail() {
    return deliveryAddressDetail;
  }

  public void setDeliveryAddressDetail(String deliveryAddressDetail) {
    this.deliveryAddressDetail = deliveryAddressDetail;
  }

  public String getDeliveryRequestDate() {
    return deliveryRequestDate;
  }

  public void setDeliveryRequestDate(String deliveryRequestDate) {
    this.deliveryRequestDate = deliveryRequestDate;
  }

  public String getDeliveryDoneDate() {
    return deliveryDoneDate;
  }

  public void setDeliveryDoneDate(String deliveryDoneDate) {
    this.deliveryDoneDate = deliveryDoneDate;
  }

  public String getDeliveryMessage() {
    return deliveryMessage;
  }

  public void setDeliveryMessage(String deliveryMessage) {
    this.deliveryMessage = deliveryMessage;
  }

  public String getSalesDoneDate() {
    return salesDoneDate;
  }

  public void setSalesDoneDate(String salesDoneDate) {
    this.salesDoneDate = salesDoneDate;
  }

  public String getOrderStatus() {
    return orderStatus;
  }

  public void setOrderStatus(String orderStatus) {
    this.orderStatus = orderStatus;
  }

  public String getOrderStatusName() {
    return orderStatusName;
  }

  public void setOrderStatusName(String orderStatusName) {
    this.orderStatusName = orderStatusName;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public int getDeliveryRequestId() {
    return deliveryRequestId;
  }

  public void setDeliveryRequestId(int deliveryRequestId) {
    this.deliveryRequestId = deliveryRequestId;
  }

  public int getProductId() {
    return productId;
  }

  public void setProductId(int productId) {
    this.productId = productId;
  }

  public String getWarehouseContentsKey() {
    return warehouseContentsKey;
  }

  public void setWarehouseContentsKey(String warehouseContentsKey) {
    this.warehouseContentsKey = warehouseContentsKey;
  }

  public int getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(int paymentId) {
    this.paymentId = paymentId;
  }

  public String getWarehouseCompleteKey() {
    return warehouseCompleteKey;
  }

  public void setWarehouseCompleteKey(String warehouseCompleteKey) {
    this.warehouseCompleteKey = warehouseCompleteKey;
  }

}