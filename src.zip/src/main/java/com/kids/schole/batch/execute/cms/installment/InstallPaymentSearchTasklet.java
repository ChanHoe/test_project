package com.kids.schole.batch.execute.cms.installment;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.execute.cms.member.BatchCmsCommonTelegram;
import com.kids.schole.batch.support.cms.installment.service.InstallmentService;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.common.cms.BaseAction;
import com.kids.schole.common.cms.XcJavaSocket;
import com.kids.schole.common.cms.util.UtilMethod;
import com.kids.schole.common.properties.PgCmsProperties;
import com.kids.schole.common.util.BusinessDayUtil;

@Component
public class InstallPaymentSearchTasklet implements Tasklet {

  @Autowired
  private BatchCmsCommonTelegram memberCommonTelegram;

  @Autowired
  private PgCmsProperties pgCmsProperties;

  @Autowired
  private InstallmentService installmentService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

//    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    String nowDate = "20180123";
    nowDate = BusinessDayUtil.getBusinessDayCalc(nowDate, -1);

    BaseAction conn = new XcJavaSocket();
    conn.connect(pgCmsProperties.getDomain(), pgCmsProperties.getBatchPaymentApplyPort());

    // 1. 업무 개시 시작전문 송신
    conn.sendData(memberCommonTelegram.getBatchCmsStartTelegram("PAY", "S", nowDate));

    String tgr = null;
    tgr = new String(conn.recvData(), "euc-kr");
    System.out.println("수신: " + tgr);

    int totalCount = 0;

    // 업무 개시 승인이 나면 처리를 한다.
    if (tgr.charAt(243) == 'Y') {
      System.out.println("업무개시");

      while (true) {
        tgr = new String(conn.recvData(), "euc-kr");

        if (tgr.substring(0, 1).equals("D")) {
          System.out.println("검색결과 : " + tgr);
        } else if (tgr.substring(0, 1).equals("H")) {
          totalCount = Integer.parseInt(tgr.substring(9, 15).trim());
          continue;
        } else if (tgr.substring(0, 1).charAt(0) == 'T') {
          break;
        }

      }

    }

    return RepeatStatus.FINISHED;

  }

}
