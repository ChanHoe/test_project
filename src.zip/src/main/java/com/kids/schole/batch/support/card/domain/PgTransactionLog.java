package com.kids.schole.batch.support.card.domain;

/**
 * PgTransactionLog는 pg 통신 로그 클래스입니다.
 * 
 * @version 1.0 2016.11.25
 * @author Jeongwon Son
 */
public class PgTransactionLog {

  private int pgTransactioinLogId;
  private int cardPaymentRequestId;
  private String pgTransactionId;
  private String pgTransactionType;
  private String responseCode;
  private String responseMessage;
  private String detailResponseCode;
  private String detailResponseMessage;
  private int registeredEmpNumber;
  private String registeredDatetime;

  public int getPgTransactioinLogId() {
    return pgTransactioinLogId;
  }

  public void setPgTransactioinLogId(int pgTransactioinLogId) {
    this.pgTransactioinLogId = pgTransactioinLogId;
  }

  public int getCardPaymentRequestId() {
    return cardPaymentRequestId;
  }

  public void setCardPaymentRequestId(int cardPaymentRequestId) {
    this.cardPaymentRequestId = cardPaymentRequestId;
  }

  public String getPgTransactionId() {
    return pgTransactionId;
  }

  public void setPgTransactionId(String pgTransactionId) {
    this.pgTransactionId = pgTransactionId;
  }

  public String getPgTransactionType() {
    return pgTransactionType;
  }

  public void setPgTransactionType(String pgTransactionType) {
    this.pgTransactionType = pgTransactionType;
  }

  public String getResponseCode() {
    return responseCode;
  }

  public void setResponseCode(String responseCode) {
    this.responseCode = responseCode;
  }

  public String getResponseMessage() {
    return responseMessage;
  }

  public void setResponseMessage(String responseMessage) {
    this.responseMessage = responseMessage;
  }

  public String getDetailResponseCode() {
    return detailResponseCode;
  }

  public void setDetailResponseCode(String detailResponseCode) {
    this.detailResponseCode = detailResponseCode;
  }

  public String getDetailResponseMessage() {
    return detailResponseMessage;
  }

  public void setDetailResponseMessage(String detailResponseMessage) {
    this.detailResponseMessage = detailResponseMessage;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

}
