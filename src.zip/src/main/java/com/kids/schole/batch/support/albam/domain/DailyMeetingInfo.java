package com.kids.schole.batch.support.albam.domain;

public class DailyMeetingInfo {
  
  private String cdEmpKey;
  private String meetingDate;
  private String saleYear;
  private String saleMonth;
  private int rollId;
  private int userId;
  private String staffName;
  private String startTime;
  private String endTime;
  private String registeredDatetime;
  
  public String getCdEmpKey() {
    return cdEmpKey;
  }
  public void setCdEmpKey(String cdEmpKey) {
    this.cdEmpKey = cdEmpKey;
  }
  public String getMeetingDate() {
    return meetingDate;
  }
  public void setMeetingDate(String meetingDate) {
    this.meetingDate = meetingDate;
  }
  public String getSaleYear() {
    return saleYear;
  }
  public void setSaleYear(String saleYear) {
    this.saleYear = saleYear;
  }
  public String getSaleMonth() {
    return saleMonth;
  }
  public void setSaleMonth(String saleMonth) {
    this.saleMonth = saleMonth;
  }
  public int getRollId() {
    return rollId;
  }
  public void setRollId(int rollId) {
    this.rollId = rollId;
  }
  public int getUserId() {
    return userId;
  }
  public void setUserId(int userId) {
    this.userId = userId;
  }
  public String getStaffName() {
    return staffName;
  }
  public void setStaffName(String staffName) {
    this.staffName = staffName;
  }
  public String getStartTime() {
    return startTime;
  }
  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }
  public String getEndTime() {
    return endTime;
  }
  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  
}
