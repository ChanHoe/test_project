package com.kids.schole.batch.support.hr.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.hr.dao.PersonnelChangeDao;
import com.kids.schole.batch.support.hr.domain.PersonnelChange;

@Service
public class PersonnelChangeServiceImpl implements PersonnelChangeService {

  @Autowired
  private PersonnelChangeDao personnelChangeDao;

  @Override
  public List<PersonnelChange> getPersonnelChangeOfMonthly() {

    return personnelChangeDao.selectPersonnelChangeOfMonthly();
  }

  @Override
  public List<PersonnelChange> getPersonnelChangeByType() {

    PersonnelChange personnelChange = new PersonnelChange();
    personnelChange.setWorkBeginDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    personnelChange.setPersonnelChangeType("pct-move");

    return personnelChangeDao.selectPersonnelChangeByType(personnelChange);
  }
}
