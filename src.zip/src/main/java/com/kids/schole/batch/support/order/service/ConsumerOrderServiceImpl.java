package com.kids.schole.batch.support.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.dao.ConsumerOrderDao;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

@Service
public class ConsumerOrderServiceImpl implements ConsumerOrderService {
  
  @Autowired
  private ConsumerOrderDao consumerOrderDao;
  
  @Override
  public List<CardPaymentRequest> getConsumerOrderApprovalList() {
    return consumerOrderDao.selectConsumerOrderApprovalList();
  }

  @Override
  public void modifyConsumerOrderPayDoneAmt(Order order) {
    consumerOrderDao.updateConsumerOrderPayDoneAmt(order);
  }

  @Override
  public void modifyConsumerOrderStatusDone(Order order) {
    consumerOrderDao.updateConsumerOrderStatusDone(order);
  }

  @Override
  public CardPaymentRequest getConsumerCardPaymentRequestPurchase(int cardPaymentRequestId) {
    return consumerOrderDao.selectConsumerCardPaymentRequestPurchase(cardPaymentRequestId);
  }

  @Override
  public List<CardPaymentRequest> getSingleCopyOrderApprovalList() {
    return consumerOrderDao.selectSingleCopyOrderApprovalList();
  }

  @Override
  public CardPaymentRequest getSingleCopyCardPaymentRequestPurchase(int cardPaymentRequestId) {
    return consumerOrderDao.selectSingleCopyCardPaymentRequestPurchase(cardPaymentRequestId);
  }

  @Override
  public void modifySingleCopyPaymentAmt(SingleCopyOrder singleCopyOrder) {
    consumerOrderDao.updateSingleCopyPaymentAmt(singleCopyOrder);
  }

  @Override
  public void modifySingleCopyOrderStatus(SingleCopyOrder singleCopyOrder) {
    consumerOrderDao.updateSingleCopyOrderStatus(singleCopyOrder);
  }
  
  @Override
  public void modifySingleCopyOrderStatusDone(SingleCopyOrder singleCopyOrder) {
    consumerOrderDao.updateSingleCopyOrderStatusDone(singleCopyOrder);
  }

}
