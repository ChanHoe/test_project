package com.kids.schole.batch.execute.consumer.delivery.tracking;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberAllStepData;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResponseStatus;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResult;
import com.kids.schole.batch.support.delivery.service.ConsumerDeliveryService;
import com.kids.schole.common.constant.DeliveryConst;

@Component
public class ConsumerDeliveryRequestResultTasklet implements Tasklet {

  @Autowired
  private ConsumerDeliveryService consumerDeliveryService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<DeliveryRequest> deliveryRequestList =
        (List<DeliveryRequest>) chunkContext.getStepContext().getStepExecution().getJobExecution()
            .getExecutionContext().get("deliveryRequestList");

    for (DeliveryRequest deliveryRequest : deliveryRequestList) {

      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus =
          deliveryRequest.getTrackingNumberTraceResponseStatus();

      TrackingNumberTraceResult trackingNumberTraceResult =
          deliveryRequest.getTrackingNumberTraceResponseStatus().getTrackingNumberTraceResult();

      // 결과값이 정상이면
      if (trackingNumberTraceResponseStatus.getResultCode().equals("0000")) {
        DeliveryRequest tempDeliveryRequest = new DeliveryRequest();
        tempDeliveryRequest.setDeliveryRequestId(deliveryRequest.getDeliveryRequestId());
        tempDeliveryRequest.setLastUpdatedEmpNumber(99999);
        if (trackingNumberTraceResult.getLastStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
          tempDeliveryRequest.setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_SHIPPED);
          consumerDeliveryService.modifyConsumerDeliveryRequestStatus(tempDeliveryRequest);
        } else if (trackingNumberTraceResult.getLastStepText().equals(DeliveryConst.CJ_DELIVERY_REJECT)) {
          
          // 미배달인경우 모든 배달과정을 찾아서 배달완료인지를 체크를 한다.
          List<TrackingNumberAllStepData> trackingNumberAllStepDataList =
              trackingNumberTraceResult.getTrackingNumberAllStepDataList();
          
          boolean isShipped = false;

          for (TrackingNumberAllStepData trackingNumberAllStepData : trackingNumberAllStepDataList) {
            if (trackingNumberAllStepData.getStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
              isShipped = true;
              break;
            }
          }
          
          // 배달완료가 있고 미배달 사유가 아래와 같으면 배달완료로 처리를 한다.
          if (isShipped == true && (trackingNumberTraceResult.getLastStepNote().equals("지연도착")
              || trackingNumberTraceResult.getLastStepNote().equals("도서/외곽지역")
              || trackingNumberTraceResult.getLastStepNote().equals("토요휴무"))
              || trackingNumberTraceResult.getLastStepNote().equals("휴무일")
              || trackingNumberTraceResult.getLastStepNote().equals("지정일배달")
              || trackingNumberTraceResult.getLastStepNote().equals("분류오류")
              || trackingNumberTraceResult.getLastStepNote().equals("고객부재")) {

            tempDeliveryRequest.setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_SHIPPED);
            
            consumerDeliveryService.modifyConsumerDeliveryRequestStatus(tempDeliveryRequest);
          }
        }
        
      }
      
    }

    return RepeatStatus.FINISHED;

  }

}
