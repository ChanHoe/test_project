package com.kids.schole.batch.support.cms.installment.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.cms.installment.dao.InstallmentDao;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.common.constant.OrderConst;
import com.kids.schole.common.util.BusinessDayUtil;

@Service
public class InstallmentServiceImpl implements InstallmentService {

  @Autowired
  private InstallmentDao installmentDao;

  @Override
  public List<InstallmentPayment> getInstallmentPaymentStatusWaitList(
      InstallmentPayment installmentPayment) {
    return installmentDao.selectInstallmentPaymentStatusWaitList(installmentPayment);
  }

  @Override
  public void modifyInstallmentPaymentStatusProcessing(String nowDate) {
    installmentDao.updateInstallmentPaymentStatusProcessing(nowDate);
  }

  @Override
  public void modifyInstallmentPaymentStatusFail(InstallmentPayment installmentPayment) {

    LocalDate today = LocalDate.now();

    // 달의 첫번째 날
    LocalDate firstDayOfMonth = LocalDate.now().withDayOfMonth(1);

    // 첫번째 출금일
    LocalDate firstWithdrawDay = LocalDate.now().withDayOfMonth(10);
    // 두번째 출금일
    LocalDate secondWithdrawDay = LocalDate.now().withDayOfMonth(20);
    // 세번째 출금일
    LocalDate thirdWithdrawDay = LocalDate.now().withDayOfMonth(25);

    // 항상 인출일(영업일 -1일) 전에 배치가 실행된다.
    if (today.isAfter(firstDayOfMonth) && today.isBefore(firstWithdrawDay)) {
      // 20일설정
      String nextWithdrawDay = secondWithdrawDay.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
      installmentPayment
          .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, -1));
    } else if (today.isAfter(firstWithdrawDay) && today.isBefore(secondWithdrawDay)) {
      // 25일설정
      String nextWithdrawDay = thirdWithdrawDay.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
      installmentPayment
          .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, -1));
    } else if (today.isAfter(secondWithdrawDay) && today.isBefore(thirdWithdrawDay)) {

      // 1. 먼저 그달 마지막 날에 출금할 수 있는지 체크를 한다.
      // 마지막 출금신청일 기준으로 영업일 +5 일이 되어야 출금을 한번더 신청할 수 있다.
      String checkWithdrawDay = today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
      checkWithdrawDay = BusinessDayUtil.getBusinessDayCalc(checkWithdrawDay, 5);

      LocalDate isAvailableDay = LocalDate.parse(checkWithdrawDay);

      // 다음달의 첫번째 1일을 구한다.
      LocalDate firstDayOfNextMonth = LocalDate.now().plusMonths(1).withDayOfMonth(1);

      // 다음달의 첫번째 1일 이전이면 한번더 출금할 수가 있다.
      if (isAvailableDay.isBefore(firstDayOfNextMonth)) {
        System.out.println("한번더 할 수 있음.");
        // 오늘신청일 기준으로 영업일+3 일을 마지막 신청일로 정한다.
        String nextWithdrawDay = today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        installmentPayment
            .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, 3));
      } else {
        System.out.println("연체");
        // 연체가 되는 경우 다음달 10일로 다시 세팅을 한다.
        String nextWithdrawDay = LocalDate.now().plusMonths(1).withDayOfMonth(10)
            .format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        installmentPayment
            .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, -1));

        // 할부요청 테이블의 할부요청상태를 연체로 수정을 한다.
        InstallmentPaymentRequest installmentPaymentRequest = new InstallmentPaymentRequest();
        installmentPaymentRequest
            .setInstallmentPaymentRequestId(installmentPayment.getInstallmentPaymentRequestId());
        installmentPaymentRequest.setInstallmentPaymentRequestStatus(
            OrderConst.INSTALLMENT_PAYMENT_REQUEST_STATUS_OVERDUE);
        installmentPaymentRequest.setLastUpdatedEmpNumber(99999);

        installmentDao.updateInstallmentPaymentRequestStatus(installmentPaymentRequest);

      }

    } else if (today.isAfter(thirdWithdrawDay)) {
      
      String nextWithdrawDay = LocalDate.now().plusMonths(1).withDayOfMonth(10)
          .format(DateTimeFormatter.ofPattern("yyyyMMdd"));
      installmentPayment
          .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, -1));

      // 할부요청 테이블의 할부요청상태를 연체로 수정을 한다.
      InstallmentPaymentRequest installmentPaymentRequest = new InstallmentPaymentRequest();
      installmentPaymentRequest
          .setInstallmentPaymentRequestId(installmentPayment.getInstallmentPaymentRequestId());
      installmentPaymentRequest.setInstallmentPaymentRequestStatus(
          OrderConst.INSTALLMENT_PAYMENT_REQUEST_STATUS_OVERDUE);
      installmentPaymentRequest.setLastUpdatedEmpNumber(99999);

      installmentDao.updateInstallmentPaymentRequestStatus(installmentPaymentRequest);
      
    }

    installmentDao.updateInstallmentPaymentStatusFail(installmentPayment);

  }

  @Override
  public List<InstallmentPayment> getInstallmentPaymentProcessingList(
      InstallmentPayment installmentPayment) {
    return installmentDao.selectInstallmentPaymentProcessingList(installmentPayment);
  }

  @Override
  public void modifyAllProcessingListDone(InstallmentPayment installmentPayment) {
    installmentDao.updateAllProcessingListDone(installmentPayment);
  }

  @Override
  public void modifyInstallmentPaymentDoneStatusFail(InstallmentPayment installmentPayment) {

    LocalDate today = LocalDate.now();

    // 첫번째 출금일
    LocalDate firstWithdrawDay = LocalDate.now().withDayOfMonth(10);
    // 두번째 출금일
    LocalDate secondWithdrawDay = LocalDate.now().withDayOfMonth(20);
    // 세번째 출금일
    LocalDate thirdWithdrawDay = LocalDate.now().withDayOfMonth(25);

    // 항상 인출일(영업일 1일) 후에 배치가 실행된다.
    if (today.isAfter(firstWithdrawDay) && today.isBefore(secondWithdrawDay)) {
      // 20일설정
      String nextWithdrawDay = secondWithdrawDay.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
      installmentPayment
          .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, -1));
    } else if (today.isAfter(secondWithdrawDay) && today.isBefore(thirdWithdrawDay)) {
      // 25일설정
      String nextWithdrawDay = thirdWithdrawDay.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
      installmentPayment
          .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, -1));
    } else if (today.isAfter(thirdWithdrawDay)) {

      // 1. 먼저 그달 마지막 날에 출금할 수 있는지 체크를 한다.
      // 마지막 출금결과일 기준으로 영업일 +3 일이 되어야 출금을 한번더 신청할 수 있다.
      String checkWithdrawDay = today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
      checkWithdrawDay = BusinessDayUtil.getBusinessDayCalc(checkWithdrawDay, 3);

      LocalDate isAvailableDay = LocalDate.parse(checkWithdrawDay);

      // 다음달의 첫번째 1일을 구한다.
      LocalDate firstDayOfNextMonth = LocalDate.now().plusMonths(1).withDayOfMonth(1);

      // 다음달의 첫번째 1일 이전이면 한번더 출금할 수가 있다.
      if (isAvailableDay.isBefore(firstDayOfNextMonth)) {
        System.out.println("한번더 할 수 있음.");
        // 오늘결과일 기준으로 영업일+1 일을 마지막 신청일로 정한다.
        String nextWithdrawDay = today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        installmentPayment
            .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, 1));
      } else {
        System.out.println("연체");
        // 연체가 되는 경우 다음달 10일로 다시 세팅을 한다.
        String nextWithdrawDay = LocalDate.now().plusMonths(1).withDayOfMonth(10)
            .format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        installmentPayment
            .setNextPaymentDueDate(BusinessDayUtil.getBusinessDayCalc(nextWithdrawDay, -1));

        // 할부요청 테이블의 할부요청상태를 연체로 수정을 한다.
        InstallmentPaymentRequest installmentPaymentRequest = new InstallmentPaymentRequest();
        installmentPaymentRequest
            .setInstallmentPaymentRequestId(installmentPayment.getInstallmentPaymentRequestId());
        installmentPaymentRequest.setInstallmentPaymentRequestStatus(
            OrderConst.INSTALLMENT_PAYMENT_REQUEST_STATUS_OVERDUE);
        installmentPaymentRequest.setLastUpdatedEmpNumber(99999);

        installmentDao.updateInstallmentPaymentRequestStatus(installmentPaymentRequest);

      }

    }

    installmentDao.updateInstallmentPaymentStatusFail(installmentPayment);

  }

  @Override
  public void modifyOrderPayDoneAmt(String paymentDueDate) {
    installmentDao.updateOrderPayDoneAmt(paymentDueDate);
  }
  
  @Override
  public void modifyConsumerOrderPayDoneAmt(String paymentDueDate) {
    installmentDao.updateConsumerOrderPayDoneAmt(paymentDueDate);
  }

  @Override
  public void modifyInstallmentPaymentRequestCheckStatus() {
    installmentDao.updateInstallmentPaymentRequestCheckStatus();
    
  }

}
