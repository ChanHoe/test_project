package com.kids.schole.batch.support.delivery.domain;

public class WarehouseResult {

  private String customerRecordId;

  public String getCustomerRecordId() {
    return customerRecordId;
  }

  public void setCustomerRecordId(String customerRecordId) {
    this.customerRecordId = customerRecordId;
  }

}
