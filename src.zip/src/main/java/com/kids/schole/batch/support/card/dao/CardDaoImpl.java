package com.kids.schole.batch.support.card.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.card.domain.PgTransactionLog;

@Repository
public class CardDaoImpl implements CardDao {

  @Autowired
  private SqlSession sqlSession;

  @Override
  public PgTransactionLog selectLastPgTransactionLog(int cardPaymentRequestId) {
    return sqlSession.selectOne("card.selectLastPgTransactionLog", cardPaymentRequestId);
  }
  
  @Override
  public void insertPgTransactionLog(PgTransactionLog pgTransactionLog) {
    sqlSession.insert("card.insertPgTransactionLog", pgTransactionLog);
  }
 
  @Override
  public void updateCardPaymentRequestStatus(CardPaymentRequest cardPaymentRequest) {
    sqlSession.update("card.updateCardPaymentRequestStatus", cardPaymentRequest);
  }
}
