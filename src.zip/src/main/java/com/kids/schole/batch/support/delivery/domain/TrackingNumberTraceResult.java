package com.kids.schole.batch.support.delivery.domain;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class TrackingNumberTraceResult {

  private String invoiceNumber;
  private String senderName;
  private String customerName;
  private String contentsName;
  private String contentsCount;
  private String lastStatusCode;
  private String lastStepText;
  private String lastStepTime;
  private String lastStepDetail;
  private String lastStepCenter;
  private String lastStepNote;
  
  @SerializedName("all_step_data")
  private List<TrackingNumberAllStepData> trackingNumberAllStepDataList;

  public String getInvoiceNumber() {
    return invoiceNumber;
  }

  public void setInvoiceNumber(String invoiceNumber) {
    this.invoiceNumber = invoiceNumber;
  }

  public String getSenderName() {
    return senderName;
  }

  public void setSenderName(String senderName) {
    this.senderName = senderName;
  }

  public String getCustomerName() {
    return customerName;
  }

  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }

  public String getContentsName() {
    return contentsName;
  }

  public void setContentsName(String contentsName) {
    this.contentsName = contentsName;
  }

  public String getContentsCount() {
    return contentsCount;
  }

  public void setContentsCount(String contentsCount) {
    this.contentsCount = contentsCount;
  }

  public String getLastStatusCode() {
    return lastStatusCode;
  }

  public void setLastStatusCode(String lastStatusCode) {
    this.lastStatusCode = lastStatusCode;
  }

  public String getLastStepText() {
    return lastStepText;
  }

  public void setLastStepText(String lastStepText) {
    this.lastStepText = lastStepText;
  }

  public String getLastStepTime() {
    return lastStepTime;
  }

  public void setLastStepTime(String lastStepTime) {
    this.lastStepTime = lastStepTime;
  }

  public String getLastStepDetail() {
    return lastStepDetail;
  }

  public void setLastStepDetail(String lastStepDetail) {
    this.lastStepDetail = lastStepDetail;
  }

  public String getLastStepCenter() {
    return lastStepCenter;
  }

  public void setLastStepCenter(String lastStepCenter) {
    this.lastStepCenter = lastStepCenter;
  }

  public String getLastStepNote() {
    return lastStepNote;
  }

  public void setLastStepNote(String lastStepNote) {
    this.lastStepNote = lastStepNote;
  }

  public List<TrackingNumberAllStepData> getTrackingNumberAllStepDataList() {
    return trackingNumberAllStepDataList;
  }

  public void setTrackingNumberAllStepDataList(
      List<TrackingNumberAllStepData> trackingNumberAllStepDataList) {
    this.trackingNumberAllStepDataList = trackingNumberAllStepDataList;
  }

}
