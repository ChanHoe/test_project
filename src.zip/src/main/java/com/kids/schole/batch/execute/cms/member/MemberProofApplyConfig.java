package com.kids.schole.batch.execute.cms.member;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class MemberProofApplyConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private MemberProofApplyTasklet memberProofApplyTasklet;

  // 매 시간마다 실행한다.
  @Scheduled(cron = "0 0 0/1 * * ?")
  public String runMemberProofApply() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(memberProofApplyJob(), param);

    return execution.getStatus().toString();
  }
  
  @Bean
  public Job memberProofApplyJob() {

    return jobBuilderFactory
        .get("memberProofApplyJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(memberProofApplyStep())
        .build();
  }
  
  // 할부요청대상 회원 조회
  @Bean
  public Step memberProofApplyStep() {
    return stepBuilderFactory
       .get("memberProofApplyStep")
       .tasklet(memberProofApplyTasklet)
       .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
  
}