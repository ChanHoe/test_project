package com.kids.schole.batch.execute.consumer.delivery.tracking;

import java.net.URI;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberAllStepData;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResponseStatus;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResult;
import com.kids.schole.batch.support.delivery.service.ConsumerDeliveryService;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;
import com.kids.schole.batch.support.order.service.ConsumerOrderService;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.OrderConst;
import com.kids.schole.common.constant.WarehouseConst;
import com.kids.schole.common.properties.WarehouseProperties;

@Component
public class SingleCopyScmDeliveryTasklet implements Tasklet {

  @Autowired
  private ConsumerDeliveryService consumerDeliveryService;

  @Autowired
  private WarehouseProperties warehouseProperties;
  
  @Autowired
  private ConsumerOrderService consumerOrderService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 현재 낱권 배송 중인 리스트를 가져온다.
    List<SingleCopyDelivery> singleCopyDeliveryList = consumerDeliveryService.getSingleCopyDeliveryStatusScmDeliveryList();
    
    for(SingleCopyDelivery singleCopyDelivery : singleCopyDeliveryList) {
      URI uri = UriComponentsBuilder.fromUriString(warehouseProperties.getTrackingUrl())
          .path(WarehouseConst.INVOICE_CJ + singleCopyDelivery.getInvoiceNumber()).build().encode()
          .toUri();
      
      RestTemplate restTemplate = new RestTemplate();
      String responseJson = restTemplate.getForObject(uri, String.class);
      
      Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
      
      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus = 
          gson.fromJson(responseJson, TrackingNumberTraceResponseStatus.class);
      
      singleCopyDelivery.setTrackingNumberTraceResponseStatus(trackingNumberTraceResponseStatus);
    }
    
    for(SingleCopyDelivery singleCopyDelivery : singleCopyDeliveryList) {
      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus =
          singleCopyDelivery.getTrackingNumberTraceResponseStatus();

      TrackingNumberTraceResult trackingNumberTraceResult =
          singleCopyDelivery.getTrackingNumberTraceResponseStatus().getTrackingNumberTraceResult();

      // 결과값이 정상이면
      if (trackingNumberTraceResponseStatus.getResultCode().equals("0000")) {
        SingleCopyDelivery tempSingleCopyDelivery = new SingleCopyDelivery();
        tempSingleCopyDelivery.setSingleCopyDeliveryId(singleCopyDelivery.getSingleCopyDeliveryId());
        
        if (trackingNumberTraceResult.getLastStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
          tempSingleCopyDelivery.setSingleCopyDeliveryStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_SHIPPED);
          
          consumerDeliveryService.modifySingleCopyDeliveryStatus(tempSingleCopyDelivery);

        } else {

          // 마지막 배송상태가 배송완료가 아닌경우 모든 배달과정을 찾아서 배달완료인지를 체크를 한다.
          List<TrackingNumberAllStepData> trackingNumberAllStepDataList =
              trackingNumberTraceResult.getTrackingNumberAllStepDataList();
          
          boolean isShipped = false;

          for (TrackingNumberAllStepData trackingNumberAllStepData : trackingNumberAllStepDataList) {
            if (trackingNumberAllStepData.getStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
              isShipped = true;
              break;
            }
          }

          // 배달과정에 배달완료가 있으면 배송상태를 배달완료로
          if (isShipped) {

            tempSingleCopyDelivery.setSingleCopyDeliveryStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_SHIPPED);

            consumerDeliveryService.modifySingleCopyDeliveryStatus(tempSingleCopyDelivery);
          }
        }
        
      }
    }
    
    for(SingleCopyDelivery singleCopyDelivery : singleCopyDeliveryList) {
      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus =
          singleCopyDelivery.getTrackingNumberTraceResponseStatus();

      TrackingNumberTraceResult trackingNumberTraceResult =
          singleCopyDelivery.getTrackingNumberTraceResponseStatus().getTrackingNumberTraceResult();

      // 결과값이 정상이면
      if (trackingNumberTraceResponseStatus.getResultCode().equals("0000")) {
        SingleCopyOrder singleCopyOrder = new SingleCopyOrder();
        singleCopyOrder.setSingleCopyOrderId(singleCopyDelivery.getSingleCopyOrderId());
        singleCopyOrder.setDeliveryDoneDate(trackingNumberTraceResponseStatus.getTrackingNumberTraceResult().getLastStepTime());
        singleCopyOrder.setSalesDoneDate(trackingNumberTraceResponseStatus.getTrackingNumberTraceResult().getLastStepTime());
        
        if (trackingNumberTraceResult.getLastStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
          singleCopyOrder.setSingleCopyOrderStatus(OrderConst.ORDER_STATUS_DONE);
          
          // 모든 물류가 배송완료가 되었으면 주문 배송완료일 변경.
          if (consumerDeliveryService.getSingleCopyDeliveryStatusNotScmShippedCount(singleCopyDelivery.getSingleCopyOrderId()) == 0) {
            consumerOrderService.modifySingleCopyOrderStatusDone(singleCopyOrder);
          }

        } else {

          // 마지막 배송상태가 배송완료가 아닌경우 모든 배달과정을 찾아서 배달완료인지를 체크를 한다.
          List<TrackingNumberAllStepData> trackingNumberAllStepDataList =
              trackingNumberTraceResult.getTrackingNumberAllStepDataList();

          boolean isShipped = false;

          for (TrackingNumberAllStepData trackingNumberAllStepData : trackingNumberAllStepDataList) {
            if (trackingNumberAllStepData.getStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
              isShipped = true;
              singleCopyOrder.setDeliveryDoneDate(trackingNumberAllStepData.getStepTime());
              singleCopyOrder.setSalesDoneDate(trackingNumberAllStepData.getStepTime());
              singleCopyOrder.setSingleCopyOrderStatus(OrderConst.ORDER_STATUS_DONE);
              break;
            }
          }

          // 배달과정에 배달완료가 있으면 상태를 완료로.
          if (isShipped) {
            if (consumerDeliveryService.getSingleCopyDeliveryStatusNotScmShippedCount(singleCopyDelivery.getSingleCopyOrderId()) == 0) {
              consumerOrderService.modifySingleCopyOrderStatusDone(singleCopyOrder);
            }

          }
          
        }
      }
    }

    return RepeatStatus.FINISHED;
  }
}
