package com.kids.schole.batch.support.cashreceipt.issue.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceipt;
import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceiptRefund;
import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.domain.SingleCopyCashReceipt;

@Repository
public class PgCashReceiptDaoImpl implements PgCashReceiptDao {

  @Autowired
  private SqlSession sqlSession;

  // -----------------------------------------------------------------------------------
  // Cashreceipt

  @Override
  public void insertCashReceipt(CashReceipt cashReceipt) {
    //
    sqlSession.insert("cashReceipt.insertCashReceipt", cashReceipt);
  }


  @Override
  public List<String> selectCashReceiptsForIssue(String targetDate) {
    //
    return sqlSession.selectList("cashReceipt.selectCashReceiptsForIssue", targetDate);
  }

  @Override
  public List<Integer> selectCashReceiptIdsForIssue(String targetDate) {
    //
    return sqlSession.selectList("cashReceipt.selectCashReceiptIdsForIssue", targetDate);
  }

  @Override
  public void updateCashReceiptForBatchLogId(PgCashReceiptBatchLog pgCashReceiptBatchLog) {
    //
    sqlSession.update("cashReceipt.updateCashReceiptForBatchLogId", pgCashReceiptBatchLog);
  }

  @Override
  public void updateCashReceiptResultById(CashReceipt cashReceipt) {
    //
    sqlSession.update("cashReceipt.updateCashReceiptResultById", cashReceipt);
  }

  @Override
  public void insertCashReceiptsForCbbk(String nowDate) {
    //
    sqlSession.insert("cashReceipt.insertCashReceiptsForCbbk", nowDate);
  }

  @Override
  public void insertCashReceiptsForCbbkSubstitute(String nowDate) {
    //
    sqlSession.insert("cashReceipt.insertCashReceiptsForCbbkSubstitute", nowDate);
  }

  @Override
  public void insertCashReceiptsForCms(String nowDate) {
    //
    sqlSession.insert("cashReceipt.insertCashReceiptsForCms", nowDate);
  }

  @Override
  public void insertCashReceiptsForCmsSubstitute(String nowDate) {
    //
    sqlSession.insert("cashReceipt.insertCashReceiptsForCmsSubstitute", nowDate);
  }

  @Override
  public void insertCashReceiptsForInstallment(String nowDate) {
    //
    sqlSession.insert("cashReceipt.insertCashReceiptsForInstallment", nowDate);
  }

  @Override
  public List<CashReceiptRefund> selectCashReceiptsForRefund(String nowDate) {
    //
    return sqlSession.selectList("cashReceipt.selectCashReceiptsForRefund", nowDate);
  }

  @Override
  public List<CashReceipt> selectCashReceiptsByOrderId(int orderId) {
    //
    return sqlSession.selectList("cashReceipt.selectCashReceiptsByOrderId", orderId);
  }

  @Override
  public List<CashReceipt> selectCbbkCashReceiptsForConsumerByOrderId(int orderId) {
    //
    return sqlSession.selectList("cashReceipt.selectCbbkCashReceiptsForConsumerByOrderId", orderId);
  }

  @Override
  public List<CashReceipt> selectBankCashReceiptsForConsumerByOrderId(int orderId) {
    //
    return sqlSession.selectList("cashReceipt.selectBankCashReceiptsForConsumerByOrderId", orderId);
  }

  @Override
  public List<CashReceipt> selectInstallmentCashReceiptsForConsumerByOrderId(int orderId) {
    //
    return sqlSession.selectList("cashReceipt.selectInstallmentCashReceiptsForConsumerByOrderId", orderId);
  }


  //-----------------------------------------------------------------------------------
  // SingleCopyCashReceipt

  @Override
  public List<String> selectSingleCopyCashReceiptsForIssue(String targetDate) {
    //
    return sqlSession.selectList("cashReceipt.selectSingleCopyCashReceiptsForIssue", targetDate);
  }

  @Override
  public List<Integer> selectSingleCopyCashReceiptIdsForIssue(String targetDate) {
    //
    return sqlSession.selectList("cashReceipt.selectSingleCopyCashReceiptIdsForIssue", targetDate);
  }

  @Override
  public void updateSingleCopyCashReceiptsForBatch(PgCashReceiptBatchLog pgCashReceiptBatchLog) {
    //
    sqlSession.update("cashReceipt.updateSingleCopyCashReceiptsForBatch", pgCashReceiptBatchLog);
  }

  @Override
  public void updateSingleCopyCashReceiptResultById(SingleCopyCashReceipt singleCopyCashReceipt) {
    //
    sqlSession.update("cashReceipt.updateSingleCopyCashReceiptResultById", singleCopyCashReceipt);
  }

  // -----------------------------------------------------------------------------------
  // PgCashReceiptBatchLog

  @Override
  public void insertCashReceiptBatchLog(PgCashReceiptBatchLog pgCashReceiptBatchLog) {
    //
    sqlSession.insert("cashReceipt.insertCashReceiptBatchLog", pgCashReceiptBatchLog);
  }

  @Override
  public void updateCashReceiptBatchLog(PgCashReceiptBatchLog pgCashReceiptBatchLog) {
    //
    sqlSession.update("cashReceipt.updateCashReceiptBatchLog", pgCashReceiptBatchLog);
  }

}
