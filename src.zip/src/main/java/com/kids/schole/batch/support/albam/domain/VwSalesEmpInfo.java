package com.kids.schole.batch.support.albam.domain;

public class VwSalesEmpInfo {
  
  private int cdEmpNumber;
  private String cdEmpName;
  private String cdPositionCode;
  private int vdEmpNumber;
  private String vdEmpName;
  private String vdPositionCode;
  private String branchName;
  private int branchOrganizationId;
  private String loungeName;
  private int loungeOrganizationId;
  
  // 추가로 필요한 정보
  private String emailMobileNumberConcat;
  private String cdEmpKey;
  private String emailAddress;
  private String mobileNumber;
  private String workBeginDate;
  
  private String saleYear;
  private String saleMonth;
  
  // 해당 사원
  private String empKey;

  public String getEmailMobileNumberConcat() {
    return emailMobileNumberConcat;
  }
  public void setEmailMobileNumberConcat(String emailMobileNumberConcat) {
    this.emailMobileNumberConcat = emailMobileNumberConcat;
  }
  public String getCdEmpKey() {
    return cdEmpKey;
  }
  public void setCdEmpKey(String cdEmpKey) {
    this.cdEmpKey = cdEmpKey;
  }
  public String getEmailAddress() {
    return emailAddress;
  }
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }
  public String getMobileNumber() {
    return mobileNumber;
  }
  public void setMobileNumber(String mobileNumber) {
    this.mobileNumber = mobileNumber;
  }
  public int getCdEmpNumber() {
    return cdEmpNumber;
  }
  public void setCdEmpNumber(int cdEmpNumber) {
    this.cdEmpNumber = cdEmpNumber;
  }
  public String getCdEmpName() {
    return cdEmpName;
  }
  public void setCdEmpName(String cdEmpName) {
    this.cdEmpName = cdEmpName;
  }
  public String getCdPositionCode() {
    return cdPositionCode;
  }
  public void setCdPositionCode(String cdPositionCode) {
    this.cdPositionCode = cdPositionCode;
  }
  public int getVdEmpNumber() {
    return vdEmpNumber;
  }
  public void setVdEmpNumber(int vdEmpNumber) {
    this.vdEmpNumber = vdEmpNumber;
  }
  public String getVdEmpName() {
    return vdEmpName;
  }
  public void setVdEmpName(String vdEmpName) {
    this.vdEmpName = vdEmpName;
  }
  public String getVdPositionCode() {
    return vdPositionCode;
  }
  public void setVdPositionCode(String vdPositionCode) {
    this.vdPositionCode = vdPositionCode;
  }
  public String getBranchName() {
    return branchName;
  }
  public void setBranchName(String branchName) {
    this.branchName = branchName;
  }
  public int getBranchOrganizationId() {
    return branchOrganizationId;
  }
  public void setBranchOrganizationId(int branchOrganizationId) {
    this.branchOrganizationId = branchOrganizationId;
  }
  public String getLoungeName() {
    return loungeName;
  }
  public void setLoungeName(String loungeName) {
    this.loungeName = loungeName;
  }
  public int getLoungeOrganizationId() {
    return loungeOrganizationId;
  }
  public void setLoungeOrganizationId(int loungeOrganizationId) {
    this.loungeOrganizationId = loungeOrganizationId;
  }
  public String getWorkBeginDate() {
    return workBeginDate;
  }
  public void setWorkBeginDate(String workBeginDate) {
    this.workBeginDate = workBeginDate;
  }
  public String getSaleYear() {
    return saleYear;
  }
  public void setSaleYear(String saleYear) {
    this.saleYear = saleYear;
  }
  public String getSaleMonth() {
    return saleMonth;
  }
  public void setSaleMonth(String saleMonth) {
    this.saleMonth = saleMonth;
  }
  public String getEmpKey() {
    return empKey;
  }
  public void setEmpKey(String empKey) {
    this.empKey = empKey;
  }
  

}
