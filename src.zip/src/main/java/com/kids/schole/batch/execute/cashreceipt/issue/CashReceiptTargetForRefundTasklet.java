package com.kids.schole.batch.execute.cashreceipt.issue;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceipt;
import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceiptRefund;
import com.kids.schole.batch.support.cashreceipt.issue.service.PgCashReceiptService;
import com.kids.schole.common.util.BusinessDayUtil;

/**
 * 현금영수증 대상을 생성(환불건 처리)
 *
 * @author 최인혜
 */
@Component
public class CashReceiptTargetForRefundTasklet implements Tasklet {

  @Autowired
  private PgCashReceiptService pgCashReceiptService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 현금영수증은 수금 다음날 새벽에 배치가 돌기 때문에
    String preDate = LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

    // 기존것 orderId 가지고 현금영수증 발급내역 모두 조회하고 새로운 금액으로 다시 신청
    List<CashReceiptRefund> cashReceiptRefunds = pgCashReceiptService.getCashReceiptsForRefund(preDate);
    if (cashReceiptRefunds.isEmpty()) {
      return RepeatStatus.FINISHED;
    }

    for (CashReceiptRefund cashReceiptRefund : cashReceiptRefunds) {
      // 환불금액
      long refundAmt = cashReceiptRefund.getRefundAmt();

      // 소비자 주문
      if (cashReceiptRefund.isConsumerOrder()) {
        // 당월 소비자
        if (cashReceiptRefund.isMonthConsumer()) {
          List<CashReceipt> cashReceipts = pgCashReceiptService.getCashReceiptsByOrderId(cashReceiptRefund.getOrderId());
          if (cashReceiptRefund.isCanceledOrder()) {
            // 취소된 주문은 모든 현금영수증을 취소
            this.cancelCashReceipts(cashReceipts);
          } else {
            // 기존 현금영수증을 취소후 차액만큼 현금영수증을 재발행
            this.reIssueCashReceiptForGeneralOrder(refundAmt, cashReceipts);
          }
        }
        else {
          // 차월 소비자
          // - 부모주문에 엮인 현금영수증 발급내역은 모두 취소한다.
          int parentsOrderId = cashReceiptRefund.getParentsOrderId();
          if (parentsOrderId == 0) { //부모 주문ID가 0이면 자신이 부모임.
            parentsOrderId = cashReceiptRefund.getOrderId();
          }
          List<CashReceipt> parentCashReceipts = pgCashReceiptService.getCashReceiptsByOrderId(parentsOrderId); //부모
          this.cancelCashReceipts(parentCashReceipts);

          // - 새로 등록된 자식 주문의 ID로 현금영수증을 발급한다.
          List<CashReceipt> cbbkCashReceipts = pgCashReceiptService.getCbbkCashReceiptsForConsumerByOrderId(cashReceiptRefund.getOrderId());
          List<CashReceipt> bankCashReceipts = pgCashReceiptService.getBankCashReceiptsForConsumerByOrderId(cashReceiptRefund.getOrderId());
          List<CashReceipt> installmentCashReceipts = pgCashReceiptService.getInstallmentCashReceiptsForConsumerByOrderId(parentsOrderId); //할부는 부모 아이디로 찾을 수 있음
          List<CashReceipt> totalCashReceipts = new ArrayList<CashReceipt>(cbbkCashReceipts);
          totalCashReceipts.addAll(bankCashReceipts);
          totalCashReceipts.addAll(installmentCashReceipts);
          // 소비자 처리한 주문의 현금영수증을 재발행(최종 취소가 아닌 경우만 재발행)
          if (!cashReceiptRefund.isCanceledOrder()) {
            this.reIssueCashReceiptForConsumerOrder(refundAmt, installmentCashReceipts);
          }
        }

      }
      else {
        // 1. 기존에 현금영수증 승인완료된 내역을 모두 조회(현금영수증 취소된 건은 가져오지 않음)
        List<CashReceipt> cashReceipts = pgCashReceiptService.getCashReceiptsByOrderId(cashReceiptRefund.getOrderId());

        if (cashReceiptRefund.isCanceledOrder()) {
          //
          this.cancelCashReceipts(cashReceipts);
        } else {
          // 기존 현금영수증을 취소후 차액만큼 현금영수증을 재발행
          this.reIssueCashReceiptForGeneralOrder(refundAmt, cashReceipts);
        }
      }
    }

    return RepeatStatus.FINISHED;
  }


  /**
   * 일반 주문의 현금영수증 재발행
   */
  private void reIssueCashReceiptForGeneralOrder(long refundAmt, List<CashReceipt> cashReceipts) {
    if (cashReceipts.isEmpty()) {
      return ;
    }
    for (CashReceipt cashReceipt : cashReceipts) {

      // 기존것 취소로 등록
      CashReceipt cancelCashReceipt = CashReceipt.copyCashReceiptForCancel(cashReceipt);
      pgCashReceiptService.createCashReceipt(cancelCashReceipt);

      refundAmt -= cashReceipt.getDealAmt();
      if (refundAmt >= 0) {
        // nothing
      } else if (refundAmt < 0) {
        long reApprovalAmt = refundAmt * -1;
        CashReceipt reApprovalCashReceipt = CashReceipt.copyCashReceiptForReIssue(cancelCashReceipt, reApprovalAmt);
        pgCashReceiptService.createCashReceipt(reApprovalCashReceipt);
        break;
      }
    }
  }

  /**
   * 현금영수증 취소
   */
  private void cancelCashReceipts(List<CashReceipt> cashReceipts) {
    if (cashReceipts.isEmpty()) {
      return ;
    }
    for (CashReceipt cashReceipt : cashReceipts) {
      // 기존것 취소로 등록
      CashReceipt cancelCashReceipt = CashReceipt.copyCashReceiptForCancel(cashReceipt);
      pgCashReceiptService.createCashReceipt(cancelCashReceipt);

    }
  }

  /**
   * 소비자 처리한 주문의 현금영수증 재발행
   */
  private void reIssueCashReceiptForConsumerOrder(long refundAmt, List<CashReceipt> cashReceipts) {
    if (cashReceipts.isEmpty()) {
      return ;
    }
    for (CashReceipt cashReceipt : cashReceipts) {

      if (refundAmt == 0) {
        CashReceipt reApprovalCashReceipt = CashReceipt.copyCashReceiptForReIssue(cashReceipt, cashReceipt.getDealAmt());
        pgCashReceiptService.createCashReceipt(reApprovalCashReceipt);

      } else {

        if (refundAmt - cashReceipt.getDealAmt() >= 0) {
          refundAmt -= cashReceipt.getDealAmt();
        } else if (refundAmt - cashReceipt.getDealAmt() < 0) {
          long reApprovalAmt = cashReceipt.getDealAmt() - refundAmt;
          CashReceipt reApprovalCashReceipt = CashReceipt.copyCashReceiptForReIssue(cashReceipt, reApprovalAmt);
          pgCashReceiptService.createCashReceipt(reApprovalCashReceipt);
          refundAmt = 0;
        }
      }
    }
  }

}
