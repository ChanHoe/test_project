package com.kids.schole.batch.support.customer.dao;

import java.util.List;

import com.kids.schole.batch.support.customer.domain.CsAllotMapping;

/**
 * ConsultationDao는 온라인상담을 위한 DAO 인터페이스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
public interface ConsultationDao {

	int updateCsConsultationVDAllot(CsAllotMapping csAllotMapping);
  
	List<CsAllotMapping> selectCsConsultationAllotNoneList();
	
	List<CsAllotMapping> selectCsConsultationAllotWaitList();

}
