package com.kids.schole.batch.support.cbbk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.cbbk.dao.CbbkDao;
import com.kids.schole.batch.support.cbbk.domain.CbbkCombine;
import com.kids.schole.batch.support.cbbk.domain.CbbkDepositHistory;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentAllot;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequest;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequestCombine;
import com.kids.schole.batch.support.order.domain.Order;

@Service
public class CbbkServiceImpl implements CbbkService {

  @Autowired
  private CbbkDao cbbkDao;

  @Override
  public void createCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory) {
    cbbkDao.insertCbbkDepositHistory(cbbkDepositHistory);
  }

  @Override
  public void removeCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory) {
    cbbkDao.deleteCbbkDepositHistory(cbbkDepositHistory);
  }

  @Override
  public List<CbbkPaymentRequest> getCbbkPaymentRequestReadyList() {
    return cbbkDao.selectCbbkPaymentRequestReadyList();
  }

  @Override
  public CbbkDepositHistory getCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory) {
    return cbbkDao.selectCbbkDepositHistory(cbbkDepositHistory);
  }

  @Override
  public void modifyCbbkPaymentRequestStatusDone(CbbkPaymentRequest cbbkPaymentRequest) {
    cbbkDao.updateCbbkPaymentRequestStatusDone(cbbkPaymentRequest);
  }

  @Override
  public void createCbbkPaymentAllot(CbbkPaymentAllot cbbkPaymentAllot) {
    cbbkDao.insertCbbkPaymentAllot(cbbkPaymentAllot);
  }

  @Override
  public void modifyCbbkDepositHistoryAllotStatus(CbbkDepositHistory cbbkDepositHistory) {
    cbbkDao.updateCbbkDepositHistoryAllotStatus(cbbkDepositHistory);
  }

  @Override
  public void modifyOrderStatusPayDoneAmt(Order order) {
    cbbkDao.updateOrderStatusPayDoneAmt(order);
  }

  @Override
  public List<CbbkPaymentRequestCombine> getCbbkPaymentRequestReadyCombineList() {
    return cbbkDao.selectCbbkPaymentRequestReadyCombineList();
  }

  @Override
  public void modifyCbbkCombineIsAllotComplete(CbbkCombine cbbkCombine) {
    cbbkDao.updateCbbkCombineIsAllotComplete(cbbkCombine);
  }

  @Override
  public CbbkPaymentRequest getCbbkPaymentRequest(CbbkPaymentRequest cbbkPaymentRequest) {
    return cbbkDao.selectCbbkPaymentRequest(cbbkPaymentRequest);
  }

  @Override
  public List<CbbkPaymentRequest> getConsumerCbbkPaymentRequestReadyList() {
    return cbbkDao.selectConsumerCbbkPaymentRequestReadyList();
  }

}
