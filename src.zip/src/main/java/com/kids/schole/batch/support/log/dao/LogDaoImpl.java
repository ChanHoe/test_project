package com.kids.schole.batch.support.log.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class LogDaoImpl implements LogDao{

  @Autowired
  private SqlSession sqlSession;

  @Override
  public void deleteBatchStepExecutionContext() {
    sqlSession.delete("log.deleteBatchStepExecutionContext");
  }

  @Override
  public void deleteBatchStepExecution() {
    sqlSession.delete("log.deleteBatchStepExecution");
  }

  @Override
  public void deleteBatchJobExecutionContext() {
    sqlSession.delete("log.deleteBatchJobExecutionContext");
  }

  @Override
  public void deleteBatchJobExecutionParams() {
    sqlSession.delete("log.deleteBatchJobExecutionParams");
  }

  @Override
  public void deleteBatchJobExecution() {
    sqlSession.delete("log.deleteBatchJobExecution");
  }

  @Override
  public void deleteBatchJobInstance() {
    sqlSession.delete("log.deleteBatchJobInstance");
  }
  
}
