package com.kids.schole.batch.support.settlebank.service;

import java.util.List;

import com.kids.schole.batch.support.settlebank.domain.Vacs;

public interface SettleBankService {

  List<Vacs> getVacsAhstLogList();

  void modifyVacsAhstLogTerminate(Vacs vacs);

}
