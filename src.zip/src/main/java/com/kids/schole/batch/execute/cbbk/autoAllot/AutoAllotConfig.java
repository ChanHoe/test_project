package com.kids.schole.batch.execute.cbbk.autoAllot;

/**
 * AutoAllotConfig는 주문금액과 가상계좌 입금금액이 일치하면 자동배분을 해주는 클래스입니다. 
 * 
 * @version 1.0 2016.12.17
 * @author Jeongho Baek
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class AutoAllotConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private OrderStatusCbbkReadyTasklet orderStatusCbbkReadyTasklet;
  
  @Autowired
  private CbbkPaymentRequestDoneTasklet cbbkPaymentRequestDoneTasklet;
  
  @Autowired
  private OrderStatusCbbkAcceptTasklet orderStatusCbbkAcceptTasklet;
  
  @Autowired
  private CbbkDeliveryWaitTasklet cbbkDeliveryWaitTasklet;
  
  @Autowired
  private CbbkInstallmentPaymentTasklet cbbkInstallmentPaymentTasklet;
  
  // 5분마다
  //@Scheduled(fixedRate = 300000)
  @Scheduled(cron="0 */5 * * * *")
  public String runAutoAllot() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(AutoAllotJob(), param);
    
    return execution.getStatus().toString();

  }

  @Bean
  public Job AutoAllotJob() {

    return jobBuilderFactory
        .get("autoAllotJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(orderStatusCbbkReadyStep())
        .next(cbbkPaymentRequestDoneStep())
        .next(orderStatusCbbkAcceptStep())
        .next(cbbkDeliveryWaitStep())
        .next(cbbkInstallmentPaymentTaskletStep())
        .build();
  }
  
  // 주문상태가 가상계좌 입금대기 조회
  @Bean
  public Step orderStatusCbbkReadyStep() {

    return stepBuilderFactory
        .get("orderStatusCbbkReadyStep")
        .tasklet(orderStatusCbbkReadyTasklet)
        .build();
  }
  
  // 자동분배
  @Bean
  public Step cbbkPaymentRequestDoneStep() {
    
    return stepBuilderFactory
        .get("cbbkPaymentRequestDoneStep")
        .tasklet(cbbkPaymentRequestDoneTasklet)
        .build();
  }
  
  // 주문 및 결제작업정보 수정
  @Bean
  public Step orderStatusCbbkAcceptStep() {
    
    return stepBuilderFactory
        .get("orderStatusCbbkAcceptStep")
        .tasklet(orderStatusCbbkAcceptTasklet)
        .build();
  }
  
  // 배송 요청 상태를 대기로 변경
  @Bean
  public Step cbbkDeliveryWaitStep() {
    return stepBuilderFactory
        .get("cbbkDeliveryWaitStep")
        .tasklet(cbbkDeliveryWaitTasklet)
        .build();
  }
  
  // 할부 일 경우 완료 시킴
  @Bean
  public Step cbbkInstallmentPaymentTaskletStep() {
    return stepBuilderFactory
        .get("cbbkInstallmentPaymentTaskletStep")
        .tasklet(cbbkInstallmentPaymentTasklet)
        .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}