package com.kids.schole.batch.support.settlebank.dao;

import java.util.List;

import com.kids.schole.batch.support.settlebank.domain.Vacs;

public interface SettleBankDao {

  List<Vacs> selectVacsAhstLogList();

  void updateVacsAhstLogTerminate(Vacs vacs);

}
