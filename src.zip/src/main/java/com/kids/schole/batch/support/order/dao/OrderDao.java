package com.kids.schole.batch.support.order.dao;

import java.util.List;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.OrderPayment;

public interface OrderDao {

  List<CardPaymentRequest> selectOrderApprovalList();

  void updateOrderPaymentPayStatus(OrderPayment orderPayment);

  void updateOrderPayDoneAmt(Order order);

  void updateOrderStatus(Order order);

  void updateOrderStatusDone(Order order);

  void updateInstallmentPaymentRequestStatus(InstallmentPaymentRequest installmentPaymentRequest);

  void updateInstallmentPaymentStatus(InstallmentPayment installmentPayment);

  Order selectOrder(int orderId);
  
  // 주문 계약서 첨부파일 CMS 회원 증빙 실패 -> 대기 (기간은 일주일)
  void updateOrderAttachedFileProofStatusFailToWait();

}
