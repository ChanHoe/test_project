package com.kids.schole.batch.support.delivery.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.delivery.domain.ChannelSales;
import com.kids.schole.batch.support.delivery.domain.ChannelSalesDeliveryRequest;

@Repository
public class ChannelSalesDeliveryDaoImpl implements ChannelSalesDeliveryDao {

  @Autowired
  private SqlSession sqlSession;

  @Override
  public List<ChannelSales> selectDeliveryStatusWaitList(String businessDay) {
    //
    return sqlSession.selectList("channelDelivery.selectDeliveryStatusWaitList", businessDay);
  }

  @Override
  public void updateChannelSalesDeliveryRequestStatusScmAccept(ChannelSalesDeliveryRequest deliveryRequest) {
    //
    sqlSession.update("channelDelivery.updateChannelSalesDeliveryRequestStatusScmAccept", deliveryRequest);
  }

}
