package com.kids.schole.batch.support.etc.domain;

public class SpecialHoliday {

  private int specialHolidayId;
  private String holiday;
  private String description;
  private int registeredEmpNumber;
  private String registeredDatetime;

  public int getSpecialHolidayId() {
    return specialHolidayId;
  }

  public void setSpecialHolidayId(int specialHolidayId) {
    this.specialHolidayId = specialHolidayId;
  }

  public String getHoliday() {
    return holiday;
  }

  public void setHoliday(String holiday) {
    this.holiday = holiday;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

}