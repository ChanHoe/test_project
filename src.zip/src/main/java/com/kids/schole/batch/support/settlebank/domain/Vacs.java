package com.kids.schole.batch.support.settlebank.domain;

public class Vacs {

  // id값
  private int vacsAhstLogId;
  // 사용여부
  private int isUsed;
  // 기관코드
  private String orgCd;
  // 은행코드
  private String bankCd;
  // 계좌번호
  private String acctNo;
  // 예금주명
  private String cmfNm;
  // 계좌상태
  private String acctSt;
  // 등록일자
  private String regIl;
  // 할당일자
  private String openIl;
  // 해지 일자
  private String closeIl;
  // 최초거래일자
  private String fstIl;
  // 최종거래일자
  private String lstIl;
  // 총 거래금액
  private long trAmt;
  // 거래금액조건
  private String tramtCond;
  // 수납회차조건
  private String trmcCond;
  // 입금가능시작일
  private String trbeginIl;
  // 입금가능만료일
  private String trendIl;
  // 입금가능시작시간
  private String trbeginSi;
  // 입금가능만료시간
  private String trendSi;
  // 기간내 수납횟수
  private int seqNo;
  // CMS 코드
  private String cmsCd;

  // 거래일자
  private String trIl;
  // 거래시간
  private String trSi;
  // 거래종류코드
  private String trCd;
  // 가상계좌번호
  private String iacctNo;
  // 입금의뢰인
  private String iacctNm;
  // 미타점금액
  private long mitaAmt;
  // 거래고유번호
  private String trNo;
  // 처리상태
  private String inpSt;
  // 응답시간
  private String inpSi;
  // 취소처리시간
  private String caninpSi;
  // 입금은행코드
  private String iorgCd;
  // 매체구분
  private String mediaGb;

  // 정상입금건수
  private int norinpCnt;
  // 정상입금금액
  private long norinpAmt;
  // 취소입금건수
  private int caninpCnt;
  // 취소입금금액
  private long caninpAmt;
  // 정상송금건수
  private int noroutCnt;
  // 정상송금금액
  private long noroutAmt;
  // 취소송금건수
  private int canoutCnt;
  // 취소송금금액
  private long canoutAmt;
  // 정상성명조회건수
  private int norqueCnt;
  // UMS 사용총 건수
  private int umsCnt;
  // 성명인증조회건수
  private int authCnt;
  // 실명인증조회건수
  private int nameCnt;

  // 오류코드
  private String errCd;

  public int getVacsAhstLogId() {
    return vacsAhstLogId;
  }

  public void setVacsAhstLogId(int vacsAhstLogId) {
    this.vacsAhstLogId = vacsAhstLogId;
  }

  public int getIsUsed() {
    return isUsed;
  }

  public void setIsUsed(int isUsed) {
    this.isUsed = isUsed;
  }

  public String getOrgCd() {
    return orgCd;
  }

  public void setOrgCd(String orgCd) {
    this.orgCd = orgCd;
  }

  public String getBankCd() {
    return bankCd;
  }

  public void setBankCd(String bankCd) {
    this.bankCd = bankCd;
  }

  public String getAcctNo() {
    return acctNo;
  }

  public void setAcctNo(String acctNo) {
    this.acctNo = acctNo;
  }

  public String getCmfNm() {
    return cmfNm;
  }

  public void setCmfNm(String cmfNm) {
    this.cmfNm = cmfNm;
  }

  public String getAcctSt() {
    return acctSt;
  }

  public void setAcctSt(String acctSt) {
    this.acctSt = acctSt;
  }

  public String getRegIl() {
    return regIl;
  }

  public void setRegIl(String regIl) {
    this.regIl = regIl;
  }

  public String getOpenIl() {
    return openIl;
  }

  public void setOpenIl(String openIl) {
    this.openIl = openIl;
  }

  public String getCloseIl() {
    return closeIl;
  }

  public void setCloseIl(String closeIl) {
    this.closeIl = closeIl;
  }

  public String getFstIl() {
    return fstIl;
  }

  public void setFstIl(String fstIl) {
    this.fstIl = fstIl;
  }

  public String getLstIl() {
    return lstIl;
  }

  public void setLstIl(String lstIl) {
    this.lstIl = lstIl;
  }

  public long getTrAmt() {
    return trAmt;
  }

  public void setTrAmt(long trAmt) {
    this.trAmt = trAmt;
  }

  public String getTramtCond() {
    return tramtCond;
  }

  public void setTramtCond(String tramtCond) {
    this.tramtCond = tramtCond;
  }

  public String getTrmcCond() {
    return trmcCond;
  }

  public void setTrmcCond(String trmcCond) {
    this.trmcCond = trmcCond;
  }

  public String getTrbeginIl() {
    return trbeginIl;
  }

  public void setTrbeginIl(String trbeginIl) {
    this.trbeginIl = trbeginIl;
  }

  public String getTrendIl() {
    return trendIl;
  }

  public void setTrendIl(String trendIl) {
    this.trendIl = trendIl;
  }

  public String getTrbeginSi() {
    return trbeginSi;
  }

  public void setTrbeginSi(String trbeginSi) {
    this.trbeginSi = trbeginSi;
  }

  public String getTrendSi() {
    return trendSi;
  }

  public void setTrendSi(String trendSi) {
    this.trendSi = trendSi;
  }

  public int getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(int seqNo) {
    this.seqNo = seqNo;
  }

  public String getCmsCd() {
    return cmsCd;
  }

  public void setCmsCd(String cmsCd) {
    this.cmsCd = cmsCd;
  }

  public String getTrIl() {
    return trIl;
  }

  public void setTrIl(String trIl) {
    this.trIl = trIl;
  }

  public String getTrSi() {
    return trSi;
  }

  public void setTrSi(String trSi) {
    this.trSi = trSi;
  }

  public String getTrCd() {
    return trCd;
  }

  public void setTrCd(String trCd) {
    this.trCd = trCd;
  }

  public String getIacctNo() {
    return iacctNo;
  }

  public void setIacctNo(String iacctNo) {
    this.iacctNo = iacctNo;
  }

  public String getIacctNm() {
    return iacctNm;
  }

  public void setIacctNm(String iacctNm) {
    this.iacctNm = iacctNm;
  }

  public long getMitaAmt() {
    return mitaAmt;
  }

  public void setMitaAmt(long mitaAmt) {
    this.mitaAmt = mitaAmt;
  }

  public String getTrNo() {
    return trNo;
  }

  public void setTrNo(String trNo) {
    this.trNo = trNo;
  }

  public String getInpSt() {
    return inpSt;
  }

  public void setInpSt(String inpSt) {
    this.inpSt = inpSt;
  }

  public String getInpSi() {
    return inpSi;
  }

  public void setInpSi(String inpSi) {
    this.inpSi = inpSi;
  }

  public String getCaninpSi() {
    return caninpSi;
  }

  public void setCaninpSi(String caninpSi) {
    this.caninpSi = caninpSi;
  }

  public String getIorgCd() {
    return iorgCd;
  }

  public void setIorgCd(String iorgCd) {
    this.iorgCd = iorgCd;
  }

  public String getMediaGb() {
    return mediaGb;
  }

  public void setMediaGb(String mediaGb) {
    this.mediaGb = mediaGb;
  }

  public int getNorinpCnt() {
    return norinpCnt;
  }

  public void setNorinpCnt(int norinpCnt) {
    this.norinpCnt = norinpCnt;
  }

  public long getNorinpAmt() {
    return norinpAmt;
  }

  public void setNorinpAmt(long norinpAmt) {
    this.norinpAmt = norinpAmt;
  }

  public int getCaninpCnt() {
    return caninpCnt;
  }

  public void setCaninpCnt(int caninpCnt) {
    this.caninpCnt = caninpCnt;
  }

  public long getCaninpAmt() {
    return caninpAmt;
  }

  public void setCaninpAmt(long caninpAmt) {
    this.caninpAmt = caninpAmt;
  }

  public int getNoroutCnt() {
    return noroutCnt;
  }

  public void setNoroutCnt(int noroutCnt) {
    this.noroutCnt = noroutCnt;
  }

  public long getNoroutAmt() {
    return noroutAmt;
  }

  public void setNoroutAmt(long noroutAmt) {
    this.noroutAmt = noroutAmt;
  }

  public int getCanoutCnt() {
    return canoutCnt;
  }

  public void setCanoutCnt(int canoutCnt) {
    this.canoutCnt = canoutCnt;
  }

  public long getCanoutAmt() {
    return canoutAmt;
  }

  public void setCanoutAmt(long canoutAmt) {
    this.canoutAmt = canoutAmt;
  }

  public int getNorqueCnt() {
    return norqueCnt;
  }

  public void setNorqueCnt(int norqueCnt) {
    this.norqueCnt = norqueCnt;
  }

  public int getUmsCnt() {
    return umsCnt;
  }

  public void setUmsCnt(int umsCnt) {
    this.umsCnt = umsCnt;
  }

  public int getAuthCnt() {
    return authCnt;
  }

  public void setAuthCnt(int authCnt) {
    this.authCnt = authCnt;
  }

  public int getNameCnt() {
    return nameCnt;
  }

  public void setNameCnt(int nameCnt) {
    this.nameCnt = nameCnt;
  }

  public String getErrCd() {
    return errCd;
  }

  public void setErrCd(String errCd) {
    this.errCd = errCd;
  }

}
