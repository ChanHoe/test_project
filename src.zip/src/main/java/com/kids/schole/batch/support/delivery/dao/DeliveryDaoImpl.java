package com.kids.schole.batch.support.delivery.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.order.domain.Order;

@Repository
public class DeliveryDaoImpl implements DeliveryDao {
  
  @Autowired
  private SqlSession sqlSession;

  @Override
  public void updateDeliveryRequestStatusWait(DeliveryRequest deliveryRequest) {
    sqlSession.update("delivery.updateDeliveryRequestStatusWait", deliveryRequest);
  }

  @Override
  public List<Order> selectDeliveryStatusWaitList(String businessDay) {
    return sqlSession.selectList("delivery.selectDeliveryStatusWaitList", businessDay);
  }

  @Override
  public void updateDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest) {
    sqlSession.update("delivery.updateDeliveryRequestStatusScmAccept", deliveryRequest);
  }

  @Override
  public List<DeliveryRequest> selectDeliveryStatusScmDeliveryList() {
    return sqlSession.selectList("delivery.selectDeliveryStatusScmDeliveryList");
  }

  @Override
  public void updateDeliveryRequestStatus(DeliveryRequest deliveryRequest) {
    sqlSession.update("delivery.updateDeliveryRequestStatus", deliveryRequest);
  }

  @Override
  public int selectDeliveryStatusNotScmShippedCount(int orderId) {
    return sqlSession.selectOne("delivery.selectDeliveryStatusNotScmShippedCount", orderId);
  }
  
  @Override
  public List<Order> selectDeliveryStatusWaitListForCard(String businessDay) {
    return sqlSession.selectList("delivery.selectDeliveryStatusWaitListForCard", businessDay);
  }

}