package com.kids.schole.batch.support.cms.member.domain;

public class OrderAttachedFile {

  private int attachedFileId;
  private int orderId;
  private String attachedType;
  private int attachedFileSize;
  private String attachedFilePath;
  private String attachedFileName;
  private String hashFileName;
  private int installmentPaymentRequestId;
  private String applyDate;
  private String proofType;
  private String proofStatus;
  private String failedProofReason;
  private String registeredDatetime;
  
  public int getAttachedFileId() {
    return attachedFileId;
  }

  public void setAttachedFileId(int attachedFileId) {
    this.attachedFileId = attachedFileId;
  }

  public int getOrderId() {
    return orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public String getAttachedType() {
    return attachedType;
  }

  public void setAttachedType(String attachedType) {
    this.attachedType = attachedType;
  }

  public int getAttachedFileSize() {
    return attachedFileSize;
  }

  public void setAttachedFileSize(int attachedFileSize) {
    this.attachedFileSize = attachedFileSize;
  }

  public String getAttachedFilePath() {
    return attachedFilePath;
  }

  public void setAttachedFilePath(String attachedFilePath) {
    this.attachedFilePath = attachedFilePath;
  }

  public String getAttachedFileName() {
    return attachedFileName;
  }

  public void setAttachedFileName(String attachedFileName) {
    this.attachedFileName = attachedFileName;
  }

  public String getHashFileName() {
    return hashFileName;
  }

  public void setHashFileName(String hashFileName) {
    this.hashFileName = hashFileName;
  }

  public int getInstallmentPaymentRequestId() {
    return installmentPaymentRequestId;
  }

  public void setInstallmentPaymentRequestId(int installmentPaymentRequestId) {
    this.installmentPaymentRequestId = installmentPaymentRequestId;
  }

  public String getApplyDate() {
    return applyDate;
  }

  public void setApplyDate(String applyDate) {
    this.applyDate = applyDate;
  }

  public String getProofType() {
    return proofType;
  }

  public void setProofType(String proofType) {
    this.proofType = proofType;
  }

  public String getProofStatus() {
    return proofStatus;
  }

  public void setProofStatus(String proofStatus) {
    this.proofStatus = proofStatus;
  }

  public String getFailedProofReason() {
    return failedProofReason;
  }

  public void setFailedProofReason(String failedProofReason) {
    this.failedProofReason = failedProofReason;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

}