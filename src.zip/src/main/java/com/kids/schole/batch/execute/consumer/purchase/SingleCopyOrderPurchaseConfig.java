package com.kids.schole.batch.execute.consumer.purchase;

/**
 * SingleCopyOrderPurchaseConfig는 낱권 유상 주문시 신용카드로 기승인한 주문을 PG와 연동하여 매입처리를 한 후  
 * 그 결과를 처리하는 클래스입니다.
 * 
 * @version 1.0 2017.10.12
 * @author chheo
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;
import com.kids.schole.batch.execute.order.purchase.CardPaymentRequestPurchaseRequestTasklet;

@Configuration
@EnableBatchProcessing
public class SingleCopyOrderPurchaseConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private PgSingleCopyPurchaseRequestTasklet pgSingleCopyPurchaseRequestTasklet; 
  
  @Autowired
  private CardPaymentRequestPurchaseRequestTasklet cardPaymentRequestPurchaseRequestTasklet;
  
  @Autowired
  private SingleCopyOrderPurchaseRequestTasklet singleCopyOrderPurchaseRequestTsaklet;
  
  @Autowired
  private SingleCopyDeliveryWaitTasklet singleCopyDeliveryWaitTasklet;


  // 저녁 7시에 실행
  @Scheduled(cron = "0 0 19 * * ?")
  public String runSingleCopyOrderPurchase() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(singleCopyOrderPurchaseJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job singleCopyOrderPurchaseJob() {
    
    return jobBuilderFactory
        .get("singleCopyOrderPurchaseJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(pgSingleCopyPurchaseRequestStep())
        .next(singleCopyCardPaymentRequestPurchaseStep())
        .next(singleCopyOrderPurchaseStep())
        .next(singleCopyDeliveryWaitStep())
        .build();
    
  }
  
  //PG 전문통신 및 전문기록로그 기록
  @Bean
  public Step pgSingleCopyPurchaseRequestStep() {
    return stepBuilderFactory
        .get("pgSingleCopyPurchaseRequestStep")
        .tasklet(pgSingleCopyPurchaseRequestTasklet)
        .build();
  }
  
  //카드결제요청 테이블 수정
  @Bean
  public Step singleCopyCardPaymentRequestPurchaseStep() {
    return stepBuilderFactory
        .get("singleCopyCardPaymentRequestPurchaseStep")
        .tasklet(cardPaymentRequestPurchaseRequestTasklet)
        .build();
  }
  
  //낱권주문 테이블 수정
  @Bean
  public Step singleCopyOrderPurchaseStep() {
    return stepBuilderFactory
        .get("singleCopyOrderPurchaseStep")
        .tasklet(singleCopyOrderPurchaseRequestTsaklet)
        .build();
  }
  
  //낱권배송 요청 상태를 대기로 변경
  @Bean
  public Step singleCopyDeliveryWaitStep() {
    return stepBuilderFactory
        .get("singleCopyDeliveryWaitStep")
        .tasklet(singleCopyDeliveryWaitTasklet)
        .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}
