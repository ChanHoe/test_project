package com.kids.schole.batch.support.cbbk.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.cbbk.domain.CbbkCombine;
import com.kids.schole.batch.support.cbbk.domain.CbbkDepositHistory;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentAllot;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequest;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequestCombine;
import com.kids.schole.batch.support.order.domain.Order;

@Repository
public class CbbkDaoImpl implements CbbkDao {
  
  @Autowired
  private SqlSession sqlSession;

  @Override
  public void insertCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory) {
    sqlSession.insert("cbbk.insertCbbkDepositHistory", cbbkDepositHistory);
  }

  @Override
  public void deleteCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory) {
    sqlSession.insert("cbbk.deleteCbbkDepositHistory", cbbkDepositHistory);
  }

  @Override
  public List<CbbkPaymentRequest> selectCbbkPaymentRequestReadyList() {
    return sqlSession.selectList("cbbk.selectCbbkPaymentRequestReadyList");
  }

  @Override
  public CbbkDepositHistory selectCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory) {
    return sqlSession.selectOne("cbbk.selectCbbkDepositHistory", cbbkDepositHistory);
  }

  @Override
  public void updateCbbkPaymentRequestStatusDone(CbbkPaymentRequest cbbkPaymentRequest) {
    sqlSession.update("cbbk.updateCbbkPaymentRequestStatusDone", cbbkPaymentRequest);
  }

  @Override
  public void insertCbbkPaymentAllot(CbbkPaymentAllot cbbkPaymentAllot) {
    sqlSession.insert("cbbk.insertCbbkPaymentAllot", cbbkPaymentAllot);
    
  }

  @Override
  public void updateCbbkDepositHistoryAllotStatus(CbbkDepositHistory cbbkDepositHistory) {
    sqlSession.update("cbbk.updateCbbkDepositHistoryAllotStatus", cbbkDepositHistory);
  }

  @Override
  public void updateOrderStatusPayDoneAmt(Order order) {
    sqlSession.update("cbbk.updateOrderStatusPayDoneAmt", order);
  }

  @Override
  public List<CbbkPaymentRequestCombine> selectCbbkPaymentRequestReadyCombineList() {
    return sqlSession.selectList("cbbk.selectCbbkPaymentRequestReadyCombineList");
  }

  @Override
  public void updateCbbkCombineIsAllotComplete(CbbkCombine cbbkCombine) {
    sqlSession.update("cbbk.updateCbbkCombineIsAllotComplete", cbbkCombine);
  }

  @Override
  public CbbkPaymentRequest selectCbbkPaymentRequest(CbbkPaymentRequest cbbkPaymentRequest) {
    return sqlSession.selectOne("cbbk.selectCbbkPaymentRequest",  cbbkPaymentRequest);
  }

  @Override
  public List<CbbkPaymentRequest> selectConsumerCbbkPaymentRequestReadyList() {
    return sqlSession.selectList("cbbk.selectConsumerCbbkPaymentRequestReadyList");
  }

}
