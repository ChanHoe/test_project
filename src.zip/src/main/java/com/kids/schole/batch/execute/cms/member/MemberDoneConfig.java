package com.kids.schole.batch.execute.cms.member;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class MemberDoneConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private MemberDoneTasklet memberDoneTasklet;

  // 11시 30분에 실행
  @Scheduled(cron = "0 30 11 * * ?")
  public String runMemberDone() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(memberDoneJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job memberDoneJob() {

    return jobBuilderFactory
        .get("memberDoneJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(memberDoneStep())
        .build();
  }

  // 할부요청대상 회원 조회
  @Bean
  public Step memberDoneStep() {
    return stepBuilderFactory
       .get("memberDoneStep")
       .tasklet(memberDoneTasklet)
       .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}