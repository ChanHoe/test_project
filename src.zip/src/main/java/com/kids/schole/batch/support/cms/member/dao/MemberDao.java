package com.kids.schole.batch.support.cms.member.dao;

import java.util.List;

import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.domain.OrderAttachedFile;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;

public interface MemberDao {

  List<OrderAttachedFile> selectOrderAttachedFileNewWaitList();

  void updateMemberProofStatus(OrderAttachedFile orderAttachedFile);

  List<OrderAttachedFile> selectOrderAttachedFileProcessingList();

  List<OrderAttachedFile> selectOrderAttachedFileCancelList();



  List<Member> selectMemberWaitList(InstallmentPaymentRequest installmentPaymentRequest);

  void updateApplicationStatusProcessing(InstallmentPaymentRequest installmentPaymentRequest);

  void updateApplicationStatusFail(InstallmentPaymentRequest installmentPaymentRequest);

  List<Member> selectMemberProcessingList(InstallmentPaymentRequest installmentPaymentRequest);

  void updateAllProcessingListDone(InstallmentPaymentRequest installmentPaymentRequest);


  /** 할부계좌 변경한 목록 */
  List<Member> selectModifyAccountInstallments(InstallmentPaymentRequest installmentPaymentRequest);
  /** 할부계좌 변경한 목록의 회원신청 종류와 상태를 변경해준다.  */
  void updateApplicationStatusWaitAndModify(int installmentPaymentRequestId);
}
