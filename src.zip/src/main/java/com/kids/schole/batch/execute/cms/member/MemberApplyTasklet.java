package com.kids.schole.batch.execute.cms.member;

import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.service.MemberService;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.common.cms.BaseAction;
import com.kids.schole.common.cms.XcJavaSocket;
import com.kids.schole.common.cms.util.UtilMethod;
import com.kids.schole.common.constant.PaymentConst;
import com.kids.schole.common.properties.PgCmsProperties;
import com.kids.schole.common.security.AES256Util;

@Component
public class MemberApplyTasklet implements Tasklet {

  @Autowired
  private BatchCmsCommonTelegram memberCommonTelegram;

  @Autowired
  private PgCmsProperties pgCmsProperties;

  @Autowired
  private MemberService memberService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 회원신청할 데이터가 있을때만 전문을 실행한다.
    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    InstallmentPaymentRequest installmentPaymentRequest = new InstallmentPaymentRequest();
    installmentPaymentRequest.setApplicationDate(nowDate);

    List<Member> memberList = memberService.getMemberWaitList(installmentPaymentRequest);

    if (memberList.size() > 0) {

      BaseAction conn = new XcJavaSocket();
      conn.connect(pgCmsProperties.getDomain(), pgCmsProperties.getBatchMemberApplyPort());

      // 1. 업무 개시 시작전문 송신
      conn.sendData(memberCommonTelegram.getBatchCmsStartTelegram("MEM", "A", nowDate));

      System.out.println(
          "회원신청 시작전문 송신 : " + memberCommonTelegram.getBatchCmsStartTelegram("MEM", "A", nowDate));

      byte[] b = null;
      b = conn.recvData();

      String startResult = new String(b, "euc-kr");

      System.out.println("회원신청 시작전문 수신 : " + startResult);

      // 업무 개시 승인이 나면 처리를 한다.
      if (startResult.charAt(243) == 'Y') {

        // 2. 신청 데이터 (Header, Data, Tail) 전문으로 3번을 송신을 한다.
        // 2.1 회원신청 Header 전문을 발송한다.
        conn.sendData(memberCommonTelegram.getMemberApplyHeaderTelegram(memberList.size()));
        System.out.println("회원신청 Header 송신 : "
            + memberCommonTelegram.getMemberApplyHeaderTelegram(memberList.size()));

        // 2.2 회원신청 Data 전문을 발송한다.
        for (Member member : memberList) {
          String memberApplyDataTelegram = getMemberApplyDataTelegram(member);
          byte[] euckrStringBuffer = memberApplyDataTelegram.getBytes(Charset.forName("euc-kr"));
          String decodedFromEucKr = new String(euckrStringBuffer, "euc-kr");
          System.out.println("회원신청 Data 송신 : " + decodedFromEucKr);
          conn.sendData(decodedFromEucKr);
        }

        // 2.3 회원신청 Tail 전문을 발송한다.
        conn.sendData(getMemberApplyTailTelegram());

        System.out.println("회원신청 Tail 송신 : " + getMemberApplyTailTelegram());

        // 3. 신청 데이터에 대한 결과 처리를 한다.
        int dataCnt = memberList.size();

        if (dataCnt == 1) {

          String tgl = new String(conn.recvData(), "euc-kr");
          System.out.println("회원신청 Header 수신 : " + tgl);
          b = conn.recvData();
          String resultTelegram = new String(b, "euc-kr");

          // 성공
          if (resultTelegram.substring(0, 1).equals("T")) {
            System.out.println("회원신청 Tail 수신 : " + resultTelegram);
            modifyApplicationStatusProcessing(installmentPaymentRequest, resultTelegram);
          }
          
          // 실패
          if (resultTelegram.substring(0, 1).equals("D")) {
            System.out.println("회원신청 Data 오류 수신 : " + resultTelegram);
            b = conn.recvData();
            tgl = new String(b, "euc-kr");
            System.out.println("회원신청 Tail 수신 : " + tgl);

            modifyApplicationStatusFail(installmentPaymentRequest, resultTelegram);
          }

        } else {

          while (dataCnt > 0) {
            dataCnt--;
            String tgl = new String(conn.recvData(), "euc-kr");

            if (tgl.substring(0, 1).equals("T")) {
              System.out.println("회원신청 Tail 수신 : " + tgl);
              modifyApplicationStatusProcessing(installmentPaymentRequest, tgl);
              break;
            } else {
              if (tgl.substring(0, 1).equals("D")) {
                System.out.println("회원신청 Data 오류 수신 : " + tgl);
                modifyApplicationStatusFail(installmentPaymentRequest, tgl);
                dataCnt++;
              } else {
                System.out.println("회원신청 Header 수신 : " + tgl);
              }
            }
          }

        }

        // 4. 종료전문 수신.
        b = conn.recvData();
        String resultTgl = new String(b, "euc-kr");
        conn.close();
        System.out.println("회원신청 종료전문 수신 : " + resultTgl);

      } else {
        // 업무 개시 승인이 나지 않았을때.
        System.out.println("error");
        conn.close();
      }

    } else {
      System.out.println("신청할 데이터가 없음.");
    }

    return RepeatStatus.FINISHED;

  }

  private void modifyApplicationStatusProcessing(
      InstallmentPaymentRequest installmentPaymentRequest, String tailTelegram) {

    int applyCount = Integer.parseInt(tailTelegram.substring(11, 17).trim());
    int applySuccessCount = Integer.parseInt(tailTelegram.substring(17, 23).trim());
    String resultFlag = UtilMethod.subString(tailTelegram, 243, 1);
    String resultCode = UtilMethod.subString(tailTelegram, 244, 4);

    // 모든 건이 정상일때 신청한건은 진행중으로 변경된다.
    if (applyCount == applySuccessCount && resultFlag.equals("Y") && resultCode.equals("T000")) {
      installmentPaymentRequest.setApplicationStatus(
          PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_PROCESSING);
      installmentPaymentRequest.setApplicationResponseMessage("");
      memberService.modifyApplicationStatusProcessing(installmentPaymentRequest);
    }

  }

  private void modifyApplicationStatusFail(InstallmentPaymentRequest installmentPaymentRequest,
      String tailTelegram) {

    String tempCustomerId = tailTelegram.substring(12, 32).trim();
    String resultMessage = UtilMethod.subString(tailTelegram, 187, 30).trim();

    int installmentPaymentRequestId = Integer.parseInt(tempCustomerId);

    installmentPaymentRequest.setInstallmentPaymentRequestId(installmentPaymentRequestId);
    installmentPaymentRequest
        .setApplicationStatus(PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_FAIL);
    installmentPaymentRequest.setApplicationResponseMessage(resultMessage);

    memberService.modifyApplicationStatusFail(installmentPaymentRequest);

  }

  private String getMemberApplyDataTelegram(Member member) {

    StringBuffer sb = new StringBuffer();

    sb.append("D");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));

    if (member.getApplicationType()
        .equals(PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_TYPE_NEW)) {
      sb.append("N");
    } else if (member.getApplicationType()
        .equals(PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_TYPE_MODIFY)) {
      sb.append("U");
    } else if (member.getApplicationType()
        .equals(PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_TYPE_DELETE)) {
      sb.append("D");
    }

    sb.append(StringUtils.rightPad(member.getInstallmentPaymentRequestId() + "", 20, " "));
    sb.append(UtilMethod.subString(member.getPayerName(), 0, 20));
    sb.append(StringUtils.rightPad("", 2, " "));
    sb.append(StringUtils.rightPad("", 10, " "));
    sb.append(StringUtils.rightPad("", 8, " "));
    sb.append(member.getPayCode().substring(2));
    sb.append(StringUtils.rightPad(AES256Util.decrypt(member.getPayInfo()), 15, " "));
    sb.append(UtilMethod.subString(member.getPayerName(), 0, 20));
    sb.append(
        StringUtils.rightPad(member.getPayerBirthDate().replaceAll("-", "").substring(2), 13, " "));
    sb.append(StringUtils.rightPad("", 1, " "));
    sb.append(StringUtils.rightPad("", 15, " "));
    sb.append(StringUtils.rightPad("", 36, " "));
    sb.append(StringUtils.rightPad("", 8, " "));
    sb.append(StringUtils.rightPad("", 1, " "));
    sb.append(StringUtils.rightPad("", 4, " "));
    sb.append(StringUtils.rightPad("", 30, " "));
    sb.append(StringUtils.rightPad("", 1, " "));
    sb.append(StringUtils.rightPad("", 60, " "));
    sb.append(StringUtils.rightPad("", 20, " "));
    sb.append("\r\n");

    return sb.toString();

  }

  private String getMemberApplyTailTelegram() {

    StringBuffer sb = new StringBuffer();

    sb.append("T");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append(StringUtils.rightPad("", 287, " "));
    sb.append("\r\n");

    return sb.toString();

  }

}
