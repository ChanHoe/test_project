package com.kids.schole.batch.support.cbbk.service;

import java.util.List;

import com.kids.schole.batch.support.cbbk.domain.CbbkCombine;
import com.kids.schole.batch.support.cbbk.domain.CbbkDepositHistory;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentAllot;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequest;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequestCombine;
import com.kids.schole.batch.support.order.domain.Order;

public interface CbbkService {

  void createCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory);

  void removeCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory);

  List<CbbkPaymentRequest> getCbbkPaymentRequestReadyList();

  CbbkDepositHistory getCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory);

  void modifyCbbkPaymentRequestStatusDone(CbbkPaymentRequest cbbkPaymentRequest);

  void createCbbkPaymentAllot(CbbkPaymentAllot cbbkPaymentAllot);

  void modifyCbbkDepositHistoryAllotStatus(CbbkDepositHistory tempCbbkDepositHistory);

  void modifyOrderStatusPayDoneAmt(Order order);

  List<CbbkPaymentRequestCombine> getCbbkPaymentRequestReadyCombineList();

  void modifyCbbkCombineIsAllotComplete(CbbkCombine cbbkCombine);

  CbbkPaymentRequest getCbbkPaymentRequest(CbbkPaymentRequest cbbkPaymentRequest);
  
  List<CbbkPaymentRequest> getConsumerCbbkPaymentRequestReadyList();

}
