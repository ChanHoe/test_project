package com.kids.schole.batch.execute.sample;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.batch.MyBatisBatchItemWriter;
import org.mybatis.spring.batch.MyBatisPagingItemReader;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;
import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.card.domain.PgTransactionLog;

@Configuration
@EnableBatchProcessing
public class OrderPurchaseConfigTemp {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private SqlSessionFactory sqlSessionFactory;

  //@Scheduled(cron = "1 * * * *  ?")
  public String runOrderPurcahse() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(orderPurchaseJobTemp(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job orderPurchaseJobTemp() {

    return jobBuilderFactory
        .get("orderPurchaseJobTemp")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .flow(orderPurchaseStepTemp())
        .end()
        .build();
  }

  // PG 전문통신 및 전문기록로그 기록
  @Bean
  public Step orderPurchaseStepTemp() {

    return stepBuilderFactory
        .get("orderPurchaseStepTemp")
        .<CardPaymentRequest, PgTransactionLog>chunk(100)
        .reader(OrderApprovalReader())
        .processor(orderApprovalProcessor())
        .writer(orderApprovalProcessorWriter()).build();
  }

  @Bean
  public ItemReader<CardPaymentRequest> OrderApprovalReader() {

    MyBatisPagingItemReader<CardPaymentRequest> reader =
        new MyBatisPagingItemReader<CardPaymentRequest>();
    reader.setSqlSessionFactory(sqlSessionFactory);
    reader.setQueryId("order.selectOrderApprovalList");
    return reader;
  }

  @Bean
  public OrderPurchaseProcessor orderApprovalProcessor() {
    return new OrderPurchaseProcessor();
  }

  @Bean
  public ItemWriter<PgTransactionLog> orderApprovalProcessorWriter() {
    
    MyBatisBatchItemWriter<PgTransactionLog> writer =
        new MyBatisBatchItemWriter<PgTransactionLog>();
    writer.setSqlSessionFactory(sqlSessionFactory);
    writer.setStatementId("card.insertPgTransactionLog");
    
    return writer;

  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}
