package com.kids.schole.batch.support.hr.domain;

/**
 * SnapOrganization 테이블과 매핑하기 위한 도메인 클래스입니다.
 *
 * @version 1.0 2017. 02. 02
 * @author Jeongwon Son
 */
public class SnapOrganization {

  private int organizationId;
  private int parentOrganizationId;
  private String organizationName;
  private int isActivated;
  private String phoneNumber;
  private String organizationDescription;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;
  
  // 판매년도, 판매월
  private String saleYear;
  private String saleMonth;
  
  public int getOrganizationId() {
    return organizationId;
  }
  public void setOrganizationId(int organizationId) {
    this.organizationId = organizationId;
  }
  public int getParentOrganizationId() {
    return parentOrganizationId;
  }
  public void setParentOrganizationId(int parentOrganizationId) {
    this.parentOrganizationId = parentOrganizationId;
  }
  public String getOrganizationName() {
    return organizationName;
  }
  public void setOrganizationName(String organizationName) {
    this.organizationName = organizationName;
  }
  public int getIsActivated() {
    return isActivated;
  }
  public void setIsActivated(int isActivated) {
    this.isActivated = isActivated;
  }
  public String getPhoneNumber() {
    return phoneNumber;
  }
  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }
  public String getOrganizationDescription() {
    return organizationDescription;
  }
  public void setOrganizationDescription(String organizationDescription) {
    this.organizationDescription = organizationDescription;
  }
  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public String getSaleYear() {
    return saleYear;
  }
  public void setSaleYear(String saleYear) {
    this.saleYear = saleYear;
  }
  public String getSaleMonth() {
    return saleMonth;
  }
  public void setSaleMonth(String saleMonth) {
    this.saleMonth = saleMonth;
  }
  
}
