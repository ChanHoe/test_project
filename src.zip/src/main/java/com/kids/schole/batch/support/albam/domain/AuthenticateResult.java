package com.kids.schole.batch.support.albam.domain;

public class AuthenticateResult {
  
  private String accessToken;
  private Integer expiredAt;
  public String getAccessToken() {
    return accessToken;
  }
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }
  public Integer getExpiredAt() {
    return expiredAt;
  }
  public void setExpiredAt(Integer expiredAt) {
    this.expiredAt = expiredAt;
  }
  
}
