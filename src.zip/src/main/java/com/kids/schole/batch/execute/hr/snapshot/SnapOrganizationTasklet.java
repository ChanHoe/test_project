package com.kids.schole.batch.execute.hr.snapshot;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.hr.service.SnapEmpService;

@Component
public class SnapOrganizationTasklet implements Tasklet {

  @Autowired
  private SnapEmpService snapEmpService;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {
    // TODO Auto-generated method stub
    
    snapEmpService.createSnapOrganiztion();
    
    return RepeatStatus.FINISHED;
  }

}
