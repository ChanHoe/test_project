package com.kids.schole.batch.support.order.domain;

/**
 * InstallmentPayment는 할부 도메인 클래스입니다.
 *
 * @version 1.0 2016.11.14
 * @author Jeongwon Son
 */
public class InstallmentPayment {

  private int installmentPaymentId;
  private int installmentPaymentRequestId;
  private int installmentAuthenticationId;
  private int paymentId;
  private int isSubstitutePayment;
  private String pgTransactionId;
  private int installmentPaymentOrder;
  private String installmentPaymentStatus;
  private String paymentDueDate;
  private long installmentPaymentAmt;
  private long installmentPaymentInterestAmt;
  private long installmentPaymentTaxableAmt;
  private long installmentPaymentVatAmt;
  private long installmentPaymentNonTaxableAmt;
  private String firstFailedPaymentDate;
  private String failedPaymentReason;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  private String payerName;
  private String mobileNumber;
  private String payDay;
  private String nextPaymentDueDate;

  public int getInstallmentPaymentId() {
    return installmentPaymentId;
  }

  public void setInstallmentPaymentId(int installmentPaymentId) {
    this.installmentPaymentId = installmentPaymentId;
  }

  public int getInstallmentPaymentRequestId() {
    return installmentPaymentRequestId;
  }

  public void setInstallmentPaymentRequestId(int installmentPaymentRequestId) {
    this.installmentPaymentRequestId = installmentPaymentRequestId;
  }

  public int getInstallmentAuthenticationId() {
    return installmentAuthenticationId;
  }

  public void setInstallmentAuthenticationId(int installmentAuthenticationId) {
    this.installmentAuthenticationId = installmentAuthenticationId;
  }

  public int getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(int paymentId) {
    this.paymentId = paymentId;
  }

  public int getIsSubstitutePayment() {
    return isSubstitutePayment;
  }

  public void setIsSubstitutePayment(int isSubstitutePayment) {
    this.isSubstitutePayment = isSubstitutePayment;
  }

  public String getPgTransactionId() {
    return pgTransactionId;
  }

  public void setPgTransactionId(String pgTransactionId) {
    this.pgTransactionId = pgTransactionId;
  }

  public int getInstallmentPaymentOrder() {
    return installmentPaymentOrder;
  }

  public void setInstallmentPaymentOrder(int installmentPaymentOrder) {
    this.installmentPaymentOrder = installmentPaymentOrder;
  }

  public String getInstallmentPaymentStatus() {
    return installmentPaymentStatus;
  }

  public void setInstallmentPaymentStatus(String installmentPaymentStatus) {
    this.installmentPaymentStatus = installmentPaymentStatus;
  }

  public String getPaymentDueDate() {
    return paymentDueDate;
  }

  public void setPaymentDueDate(String paymentDueDate) {
    this.paymentDueDate = paymentDueDate;
  }

  public long getInstallmentPaymentAmt() {
    return installmentPaymentAmt;
  }

  public void setInstallmentPaymentAmt(long installmentPaymentAmt) {
    this.installmentPaymentAmt = installmentPaymentAmt;
  }

  public long getInstallmentPaymentInterestAmt() {
    return installmentPaymentInterestAmt;
  }

  public void setInstallmentPaymentInterestAmt(long installmentPaymentInterestAmt) {
    this.installmentPaymentInterestAmt = installmentPaymentInterestAmt;
  }

  public long getInstallmentPaymentTaxableAmt() {
    return installmentPaymentTaxableAmt;
  }

  public void setInstallmentPaymentTaxableAmt(long installmentPaymentTaxableAmt) {
    this.installmentPaymentTaxableAmt = installmentPaymentTaxableAmt;
  }

  public long getInstallmentPaymentVatAmt() {
    return installmentPaymentVatAmt;
  }

  public void setInstallmentPaymentVatAmt(long installmentPaymentVatAmt) {
    this.installmentPaymentVatAmt = installmentPaymentVatAmt;
  }

  public long getInstallmentPaymentNonTaxableAmt() {
    return installmentPaymentNonTaxableAmt;
  }

  public void setInstallmentPaymentNonTaxableAmt(long installmentPaymentNonTaxableAmt) {
    this.installmentPaymentNonTaxableAmt = installmentPaymentNonTaxableAmt;
  }

  public String getFirstFailedPaymentDate() {
    return firstFailedPaymentDate;
  }

  public void setFirstFailedPaymentDate(String firstFailedPaymentDate) {
    this.firstFailedPaymentDate = firstFailedPaymentDate;
  }

  public String getFailedPaymentReason() {
    return failedPaymentReason;
  }

  public void setFailedPaymentReason(String failedPaymentReason) {
    this.failedPaymentReason = failedPaymentReason;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public String getPayerName() {
    return payerName;
  }

  public void setPayerName(String payerName) {
    this.payerName = payerName;
  }

  public String getMobileNumber() {
    return mobileNumber;
  }

  public void setMobileNumber(String mobileNumber) {
    this.mobileNumber = mobileNumber;
  }

  public String getPayDay() {
    return payDay;
  }

  public void setPayDay(String payDay) {
    this.payDay = payDay;
  }

  public String getNextPaymentDueDate() {
    return nextPaymentDueDate;
  }

  public void setNextPaymentDueDate(String nextPaymentDueDate) {
    this.nextPaymentDueDate = nextPaymentDueDate;
  }

}
