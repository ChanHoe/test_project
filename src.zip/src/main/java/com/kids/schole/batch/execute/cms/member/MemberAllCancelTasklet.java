package com.kids.schole.batch.execute.cms.member;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.service.MemberService;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.common.cms.BaseAction;
import com.kids.schole.common.cms.XcJavaSocket;
import com.kids.schole.common.properties.PgCmsProperties;

@Component
public class MemberAllCancelTasklet implements Tasklet {

  @Autowired
  private BatchCmsCommonTelegram memberCommonTelegram;

  @Autowired
  private PgCmsProperties pgCmsProperties;

  @Autowired
  private MemberService memberService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 회원신청할 데이터가 있을때만 전문을 실행한다.
    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    InstallmentPaymentRequest installmentPaymentRequest = new InstallmentPaymentRequest();
    installmentPaymentRequest.setApplicationDate(nowDate);

    List<Member> memberList = memberService.getMemberWaitList(installmentPaymentRequest);

    if (memberList.size() > 0) {

      BaseAction conn = new XcJavaSocket();
      conn.connect(pgCmsProperties.getDomain(), pgCmsProperties.getBatchMemberApplyPort());

      System.out.println("====================" + nowDate + " 회원신청 초기화 시작====================");
      // 1. 업무 개시 시작전문 송신
      conn.sendData(memberCommonTelegram.getBatchCmsStartTelegram("MEM", "A", nowDate));

      System.out.println(
          "회원신청 시작전문 송신 : " + memberCommonTelegram.getBatchCmsStartTelegram("MEM", "A", nowDate));

      byte[] b = null;
      b = conn.recvData();

      String startResult = new String(b, "euc-kr");

      System.out.println("회원신청 시작전문 수신 : " + startResult);

      // 업무 개시 승인이 나면 처리를 한다.
      if (startResult.charAt(243) == 'Y') {

        // 2. 신청 데이터 (Header, Data, Tail) 전문으로 3번을 송신을 한다.
        // 2.1 회원신청 Header 전문을 발송한다.
        conn.sendData(memberCommonTelegram.getMemberApplyHeaderTelegram(0));
        System.out
            .println("회원신청 Header 송신 : " + memberCommonTelegram.getMemberApplyHeaderTelegram(0));

        // 2.3 회원신청 Tail 전문을 발송한다.
        conn.sendData(getMemberApplyTailTelegram());

        System.out.println("회원신청 Tail 송신 : " + getMemberApplyTailTelegram());

        String headerTgl = new String(conn.recvData(), "euc-kr");
        System.out.println("회원신청 Header 수신 : " + headerTgl);
        b = conn.recvData();
        String tailTgl = new String(b, "euc-kr");
        System.out.println("회원신청 Tail 수신 : " + tailTgl);

        // 4. 종료전문 수신.
        b = conn.recvData();
        String resultTgl = new String(b, "euc-kr");
        conn.close();
        System.out.println("회원신청 종료전문 수신 : " + resultTgl);

      } else {
        // 업무 개시 승인이 나지 않았을때.
        System.out.println("error");
        conn.close();
      }

      System.out.println("====================" + nowDate + " 회원신청 초기화   끝====================");
    }

    return RepeatStatus.FINISHED;

  }

  private String getMemberApplyTailTelegram() {

    StringBuffer sb = new StringBuffer();

    sb.append("T");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append(StringUtils.rightPad("", 287, " "));
    sb.append("\r\n");

    return sb.toString();

  }

}
