package com.kids.schole.batch.support.hr.domain;

/**
 * EMP 테이블과 매핑하기 위한 도메인 클래스입니다.
 *
 * @version 1.0 2016. 10. 21.
 * @author Eunsung Ju
 */
public class Emp {

  private static final long serialVersionUID = 6483534648307395568L;

  private int empNumber;
  private String empPassword;
  private int profileImageId;
  private String empKey;
  private String empName;
  private String empStatus;
  private String empRrn;
  private String mainJobTitle;
  private String empPostcode;
  private String empAddress;
  private String empAddressDetail;
  private String phoneNumber;
  private String mobileNumber;
  private String emailAddress;
  private String finalEducation;
  private int isMarried;
  private String marriedDate;
  private String positionCode;
  private String joinedDate;
  private int recruiter;
  private String recruitChannel;
  private String requiredDocuments;
  private String workBeginDate;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;
  private String lastLoginDatetime;

  /*
   * 구비서류 종류
   *
   *    SALE :: 판매위임계약서
   *    RRM  :: 주민등록등본 또는 가족관계증명서
   *    BANK :: 통장사본
   */
  private boolean reqSale;
  private boolean reqRrm;
  private boolean reqBank;

  // 공통코드 이름
  private String mainJobTitleName;
  private String empStatusName;
  private String finalEducationName;
  private String positionCodeName;
  private String recruitChannelName;
  private String personnelChangeTypeName;

  // 조인 컬럼
  private int organizationId;
  private String organizationName;
  private int parentOrganizationId;
  private String parentOrganizationName;
  private String recruiterName;
  private String imageName;
  private String hashFileName;

  // 전화번호 각 자리
  private String prefixPhoneNumber;
  private String prefixMobileNumber;

  private String infixPhoneNumber;
  private String infixMobileNumber;

  private String suffixPhoneNumber;
  private String suffixMobileNumber;

  // 필요 컬럼
  private String personnelChangeType;

  public int getEmpNumber() {
    return empNumber;
  }

  public void setEmpNumber(int empNumber) {
    this.empNumber = empNumber;
  }

  public String getEmpPassword() {
    return empPassword;
  }

  public void setEmpPassword(String empPassword) {
    this.empPassword = empPassword;
  }

  public int getProfileImageId() {
    return profileImageId;
  }

  public void setProfileImageId(int profileImageId) {
    this.profileImageId = profileImageId;
  }

  public String getEmpKey() {
    return empKey;
  }

  public void setEmpKey(String empKey) {
    this.empKey = empKey;
  }

  public String getEmpName() {
    return empName;
  }

  public void setEmpName(String empName) {
    this.empName = empName;
  }

  public String getEmpStatus() {
    return empStatus;
  }

  public void setEmpStatus(String empStatus) {
    this.empStatus = empStatus;
  }

  public String getEmpRrn() {
    return empRrn;
  }

  public void setEmpRrn(String empRrn) {
    this.empRrn = empRrn;
  }

  public String getMainJobTitle() {
    return mainJobTitle;
  }

  public void setMainJobTitle(String mainJobTitle) {
    this.mainJobTitle = mainJobTitle;
  }

  public String getMainJobTitleName() {
    return mainJobTitleName;
  }

  public void setMainJobTitleName(String mainJobTitleName) {
    this.mainJobTitleName = mainJobTitleName;
  }

  public String getEmpStatusName() {
    return empStatusName;
  }

  public void setEmpStatusName(String empStatusName) {
    this.empStatusName = empStatusName;
  }

  public String getEmpPostcode() {
    return empPostcode;
  }

  public void setEmpPostcode(String empPostcode) {
    this.empPostcode = empPostcode;
  }

  public String getEmpAddress() {
    return empAddress;
  }

  public void setEmpAddress(String empAddress) {
    this.empAddress = empAddress;
  }

  public String getEmpAddressDetail() {
    return empAddressDetail;
  }

  public void setEmpAddressDetail(String empAddressDetail) {
    this.empAddressDetail = empAddressDetail;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {

    this.phoneNumber = phoneNumber;

    if (phoneNumber == null) {
      return;
    }

    String [] arrPhoneNumber = phoneNumber.split("-");

    if (arrPhoneNumber.length == 2) {
      this.infixPhoneNumber = arrPhoneNumber[0];
      this.suffixPhoneNumber = arrPhoneNumber[1];
    } else if(arrPhoneNumber.length == 3) {
      this.prefixPhoneNumber = arrPhoneNumber[0];
      this.infixPhoneNumber = arrPhoneNumber[1];
      this.suffixPhoneNumber = arrPhoneNumber[2];
    }

  }

  public String getMobileNumber() {
    return mobileNumber;
  }

  public void setMobileNumber(String mobileNumber) {

    if(mobileNumber != null) {
      String [] arrMobileNumber = mobileNumber.split("-");

      if(arrMobileNumber.length == 3) {
        this.prefixMobileNumber = arrMobileNumber[0];
        this.infixMobileNumber = arrMobileNumber[1];
        this.suffixMobileNumber = arrMobileNumber[2];
      }
    }

    this.mobileNumber = mobileNumber;
  }

  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  public String getFinalEducation() {
    return finalEducation;
  }

  public void setFinalEducation(String finalEducation) {
    this.finalEducation = finalEducation;
  }

  public int getIsMarried() {
    return isMarried;
  }

  public void setIsMarried(int isMarried) {
    this.isMarried = isMarried;
  }

  public String getMarriedDate() {
    return marriedDate;
  }

  public void setMarriedDate(String marriedDate) {
    this.marriedDate = marriedDate;
  }

  public String getPositionCode() {
    return positionCode;
  }

  public void setPositionCode(String positionCode) {
    this.positionCode = positionCode;
  }

  public String getFinalEducationName() {
    return finalEducationName;
  }

  public void setFinalEducationName(String finalEducationName) {
    this.finalEducationName = finalEducationName;
  }

  public String getPersonnelChangeTypeName() {
    return personnelChangeTypeName;
  }

  public void setPersonnelChangeTypeName(String personnelChangeTypeName) {
    this.personnelChangeTypeName = personnelChangeTypeName;
  }

  public String getPersonnelChangeType() {
    return personnelChangeType;
  }

  public void setPersonnelChangeType(String personnelChangeType) {
    this.personnelChangeType = personnelChangeType;
  }

  public String getPositionCodeName() {
    return positionCodeName;
  }

  public void setPositionCodeName(String positionCodeName) {
    this.positionCodeName = positionCodeName;
  }

  public String getRecruitChannelName() {
    return recruitChannelName;
  }

  public void setRecruitChannelName(String recruitChannelName) {
    this.recruitChannelName = recruitChannelName;
  }

  public String getJoinedDate() {
    return joinedDate;
  }

  public void setJoinedDate(String joinedDate) {
    this.joinedDate = joinedDate;
  }

  public int getRecruiter() {
    return recruiter;
  }

  public void setRecruiter(int recruiter) {
    this.recruiter = recruiter;
  }

  public String getRecruitChannel() {
    return recruitChannel;
  }

  public void setRecruitChannel(String recruitChannel) {
    this.recruitChannel = recruitChannel;
  }

  public String getRequiredDocuments() {
    return requiredDocuments;
  }

  public void setRequiredDocuments(String requiredDocuments) {
    this.requiredDocuments = requiredDocuments;
  }

  public String getWorkBeginDate() {
    return workBeginDate;
  }

  public void setWorkBeginDate(String workBeginDate) {
    this.workBeginDate = workBeginDate;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public String getLastLoginDatetime() {
    return lastLoginDatetime;
  }

  public void setLastLoginDatetime(String lastLoginDatetime) {
    this.lastLoginDatetime = lastLoginDatetime;
  }

  public int getOrganizationId() {
    return organizationId;
  }

  public void setOrganizationId(int organizationId) {
    this.organizationId = organizationId;
  }

  public String getOrganizationName() {
    return organizationName;
  }

  public void setOrganizationName(String organizationName) {
    this.organizationName = organizationName;
  }

  public int getParentOrganizationId() {
    return parentOrganizationId;
  }

  public void setParentOrganizationId(int parentOrganizationId) {
    this.parentOrganizationId = parentOrganizationId;
  }

  public String getParentOrganizationName() {
    return parentOrganizationName;
  }

  public void setParentOrganizationName(String parentOrganizationName) {
    this.parentOrganizationName = parentOrganizationName;
  }

  public String getRecruiterName() {
    return recruiterName;
  }

  public void setRecruiterName(String recruiterName) {
    this.recruiterName = recruiterName;
  }

  public String getImageName() {
    return imageName;
  }

  public void setImageName(String imageName) {
    this.imageName = imageName;
  }

  public String getHashFileName() {
    return hashFileName;
  }

  public void setHashFileName(String hashFileName) {
    this.hashFileName = hashFileName;
  }

  public String getPrefixPhoneNumber() {
    return prefixPhoneNumber;
  }

  public void setPrefixPhoneNumber(String prefixPhoneNumber) {
    this.prefixPhoneNumber = prefixPhoneNumber;
  }

  public String getPrefixMobileNumber() {
    return prefixMobileNumber;
  }

  public void setPrefixMobileNumber(String prefixMobileNumber) {
    this.prefixMobileNumber = prefixMobileNumber;
  }

  public String getInfixPhoneNumber() {
    return infixPhoneNumber;
  }

  public void setInfixPhoneNumber(String infixPhoneNumber) {
    this.infixPhoneNumber = infixPhoneNumber;
  }

  public String getInfixMobileNumber() {
    return infixMobileNumber;
  }

  public void setInfixMobileNumber(String infixMobileNumber) {
    this.infixMobileNumber = infixMobileNumber;
  }

  public String getSuffixPhoneNumber() {
    return suffixPhoneNumber;
  }

  public void setSuffixPhoneNumber(String suffixPhoneNumber) {
    this.suffixPhoneNumber = suffixPhoneNumber;
  }

  public String getSuffixMobileNumber() {
    return suffixMobileNumber;
  }

  public void setSuffixMobileNumber(String suffixMobileNumber) {
    this.suffixMobileNumber = suffixMobileNumber;
  }

  public boolean isReqSale() {
    return reqSale;
  }

  public boolean isReqRrm() {
    return reqRrm;
  }

  public boolean isReqBank() {
    return reqBank;
  }
}