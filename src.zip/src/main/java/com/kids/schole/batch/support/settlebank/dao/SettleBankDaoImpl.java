package com.kids.schole.batch.support.settlebank.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.settlebank.domain.Vacs;

@Repository
public class SettleBankDaoImpl implements SettleBankDao {

  @Autowired
  private SqlSession sqlSession;
  
  @Override
  public List<Vacs> selectVacsAhstLogList() {
    return sqlSession.selectList("settleBank.selectVacsAhstLogList");
  }

  @Override
  public void updateVacsAhstLogTerminate(Vacs vacs) {
    sqlSession.update("settleBank.updateVacsAhstLogTerminate", vacs);
  }

}
