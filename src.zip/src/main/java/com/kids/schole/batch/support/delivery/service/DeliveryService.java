package com.kids.schole.batch.support.delivery.service;

import java.util.List;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.order.domain.Order;

public interface DeliveryService {

  void modifyDeliveryRequestStatusWait(DeliveryRequest deliveryRequest);

  List<Order> getDeliveryStatusWaitList(String businessDay);

  void modifyDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest);

  List<DeliveryRequest> getDeliveryStatusScmDeliveryList();

  void modifyDeliveryRequestStatus(DeliveryRequest tempDeliveryRequest);

  int getDeliveryStatusNotScmShippedCount(int orderId);

  List<Order> getDeliveryStatusWaitListForCard(String businessDay);

}
