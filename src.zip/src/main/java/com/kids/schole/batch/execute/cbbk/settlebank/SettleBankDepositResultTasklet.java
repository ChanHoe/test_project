package com.kids.schole.batch.execute.cbbk.settlebank;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.settlebank.domain.Vacs;
import com.kids.schole.batch.support.settlebank.service.SettleBankService;

@Component
public class SettleBankDepositResultTasklet implements Tasklet {

  @Autowired
  private SettleBankService settleBankService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<Vacs> vacsList = (List<Vacs>) chunkContext.getStepContext().getStepExecution()
        .getJobExecution().getExecutionContext().get("vacsList");

    for (Vacs vacs : vacsList) {
      settleBankService.modifyVacsAhstLogTerminate(vacs);
    }

    return RepeatStatus.FINISHED;

  }

}
