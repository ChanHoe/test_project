package com.kids.schole.batch.support.albam.domain;

import com.google.gson.annotations.SerializedName;

public class AuthenticateResponse {
  
  private Integer returnCode;
  private String returnMessage;
  @SerializedName("response")
  private AuthenticateResult authenticateResult;
  
  public Integer getReturnCode() {
    return returnCode;
  }
  public void setReturnCode(Integer returnCode) {
    this.returnCode = returnCode;
  }
  public String getReturnMessage() {
    return returnMessage;
  }
  public void setReturnMessage(String returnMessage) {
    this.returnMessage = returnMessage;
  }
  public AuthenticateResult getAuthenticateResult() {
    return authenticateResult;
  }
  public void setAuthenticateResult(AuthenticateResult authenticateResult) {
    this.authenticateResult = authenticateResult;
  }
}
