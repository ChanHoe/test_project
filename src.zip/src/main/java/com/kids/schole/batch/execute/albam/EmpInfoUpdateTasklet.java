package com.kids.schole.batch.execute.albam;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.albam.domain.CustomResponse;
import com.kids.schole.batch.support.albam.domain.VwSalesEmpInfo;
import com.kids.schole.batch.support.albam.service.AlbamService;
import com.kids.schole.common.constant.AlbamConst;
import com.kids.schole.common.properties.AlbamProperties;
import com.kids.schole.common.util.DateUtil;

@Component
public class EmpInfoUpdateTasklet implements Tasklet {
  
  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private AlbamService albamService;
  
  @Autowired
  private AlbamProperties albamProperties;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
    
    Map<String, Object> param = chunkContext.getStepContext().getJobParameters();
    
    String inputYear = (String)param.get("inputYear");
    String inputMonth = (String)param.get("inputMonth");
    String empKey = (String)param.get("empKey");
    
    // 해당 연도와 월을 구함
    Date date = DateUtil.getSysDate();
    
    VwSalesEmpInfo vwSalesEmpInfo = new VwSalesEmpInfo();
    vwSalesEmpInfo.setSaleYear(StringUtils.isBlank(inputYear) ? DateUtil.getSysDateFormat(date, "yyyy") : inputYear);
    vwSalesEmpInfo.setSaleMonth(StringUtils.isBlank(inputMonth) ? DateUtil.getSysDateFormat(date, "MM") : inputMonth);
    vwSalesEmpInfo.setEmpKey(StringUtils.isBlank(empKey) ? null : empKey);  // 특정 교사 알밤 기록 가져오고 싶을때 사용
    
    
    logger.debug("======= 해당 년, 월, 교사번호 확인 {} {} {}"
        , vwSalesEmpInfo.getSaleYear(), vwSalesEmpInfo.getSaleMonth(), vwSalesEmpInfo.getEmpKey());
    
    // 재직 중인 CD 목록을 가져온다.
    List<VwSalesEmpInfo> vwSalesEmpInfoList = albamService.getVwSalesEmpInfoList(vwSalesEmpInfo);
    
    for (VwSalesEmpInfo empInfo : vwSalesEmpInfoList) {
      
      MultiValueMap<String, String> customInfoMap = new LinkedMultiValueMap<String, String>();
      customInfoMap.add("access_token", albamProperties.getAccessToken());
      customInfoMap.add("user", empInfo.getEmailMobileNumberConcat());
      customInfoMap.add("name", empInfo.getCdEmpName());
      customInfoMap.add("value", empInfo.getCdEmpKey());
      
      String url = albamProperties.getUrl() + AlbamConst.ALBAM_CUSTOM_URL;
  
      // Http Header 세팅
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
      
      HttpEntity<MultiValueMap<String, String>> customInfoMapEntity =
          new HttpEntity<MultiValueMap<String, String>>(customInfoMap, headers);
      
//      logger.debug("name, user확인 {}{}",empInfo.getCdEmpName(), empInfo.getEmailMobileNumberConcat());
      
      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<String> responseEntity =
          restTemplate.postForEntity(url, customInfoMapEntity, String.class);
      
      // return_code가 200일 경우에만
      if(responseEntity.getStatusCode().equals(200)){
        
        Gson gson = new GsonBuilder()
            .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
        
        CustomResponse customResponseStatus =
            gson.fromJson(responseEntity.getBody(), CustomResponse.class);
      }
      
   }  
    return RepeatStatus.FINISHED;
  }

}
