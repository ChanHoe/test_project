package com.kids.schole.batch.execute.cbbk.autoAllot;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cbbk.domain.CbbkDepositHistory;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentAllot;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequest;
import com.kids.schole.batch.support.cbbk.service.CbbkService;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.common.constant.PaymentConst;

@Component
public class CbbkPaymentRequestDoneTasklet implements Tasklet {

  @Autowired
  private CbbkService cbbkService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<CbbkPaymentRequest> cbbkPaymentRequestReadyList =
        (List<CbbkPaymentRequest>) chunkContext.getStepContext().getStepExecution()
            .getJobExecution().getExecutionContext().get("cbbkPaymentRequestReadyList");

    List<Order> orderList = new ArrayList<Order>();

    for (CbbkPaymentRequest cbbkPaymentRequest : cbbkPaymentRequestReadyList) {

      // 통합요청이 아닐때
      if (cbbkPaymentRequest.getIsCombine().equals("N")) {

        CbbkDepositHistory cbbkDepositHistory = new CbbkDepositHistory();
        cbbkDepositHistory.setDepositAmt(cbbkPaymentRequest.getPaymentAmt());
        cbbkDepositHistory.setBankAccount(cbbkPaymentRequest.getBankAccount());

        CbbkDepositHistory tempCbbkDepositHistory =
            cbbkService.getCbbkDepositHistory(cbbkDepositHistory);

        if (tempCbbkDepositHistory != null) {
          // 1. 가상계좌결제요청 결제상태를 완료로 수정한다.
          cbbkPaymentRequest.setRequestStatus(PaymentConst.REQUEST_STATUS_DONE);
          cbbkPaymentRequest.setDepositDatetime(tempCbbkDepositHistory.getDepositDatetime());
          cbbkPaymentRequest.setDepositName(tempCbbkDepositHistory.getDepositName());
          cbbkService.modifyCbbkPaymentRequestStatusDone(cbbkPaymentRequest);

          // 2.가상계좌결재할당을 추가한다.
          CbbkPaymentAllot cbbkPaymentAllot = new CbbkPaymentAllot();
          cbbkPaymentAllot.setCbbkPaymentRequestId(cbbkPaymentRequest.getCbbkPaymentRequestId());
          cbbkPaymentAllot
              .setCbbkDepositHistoryId(tempCbbkDepositHistory.getCbbkDepositHistoryId());
          cbbkPaymentAllot.setRegisteredEmpNumber(99999);
          cbbkService.createCbbkPaymentAllot(cbbkPaymentAllot);

          // 3. 가상계좌입금내역 입금배분상태를 수정한다.
          tempCbbkDepositHistory.setAllotStatus(PaymentConst.ALLOT_STATUS_DONE);
          tempCbbkDepositHistory.setLastUpdatedEmpNumber(99999);
          cbbkService.modifyCbbkDepositHistoryAllotStatus(tempCbbkDepositHistory);

          // 4. 분배 완료된 주문을 저장한다.
          Order order = new Order();
          order.setOrderId(cbbkPaymentRequest.getOrderId());
          order.setPayDoneAmt(cbbkPaymentRequest.getPaymentAmt());
          order.setPaymentId(cbbkPaymentRequest.getPaymentId());
          order.setPayAction(cbbkPaymentRequest.getPayAction());
          orderList.add(order);

        }

      }

    }

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("orderList", orderList);

    return RepeatStatus.FINISHED;

  }

}
