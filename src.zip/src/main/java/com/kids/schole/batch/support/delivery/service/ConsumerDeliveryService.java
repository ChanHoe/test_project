package com.kids.schole.batch.support.delivery.service;

import java.util.List;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

public interface ConsumerDeliveryService {
  
  void modifyConsumerDeliveryRequestStatusWait(DeliveryRequest deliveryRequest);
  
  List<Order> getConsumerDeliveryStatusWaitList();
  
  void modifyConsumerDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest);
  
  List<DeliveryRequest> getConsumerDeliveryStatusScmDeliveryList();
  
  void modifyConsumerDeliveryRequestStatus(DeliveryRequest tempDeliveryRequest);
  
  int getConsumerDeliveryStatusNotScmShippedCount(int orderId);
  
  void modifySingleCopyDeliveryStatusWait(SingleCopyDelivery singleCopyDelivery);
  
  List<SingleCopyOrder> getSingleCopyDeliveryStatusWaitList();
  
  void modifySingleCopyDeliveryStatusScmAccept(SingleCopyDelivery singleCopyDelivery);
  
  List<SingleCopyDelivery> getSingleCopyDeliveryStatusScmDeliveryList();
  
  void modifySingleCopyDeliveryStatus(SingleCopyDelivery singleCopyDelivery);
  
  int getSingleCopyDeliveryStatusNotScmShippedCount(int singleCopyOrderId);
}
