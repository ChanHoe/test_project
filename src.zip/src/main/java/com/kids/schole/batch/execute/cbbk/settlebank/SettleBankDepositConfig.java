package com.kids.schole.batch.execute.cbbk.settlebank;

/**
 * SettleBankDepositConfig는 새틀뱅크에서 가상계좌에 입금된 내역을 다시 
 * 가상계좌입금내역으로 전송하는 클래스입니다.
 * 
 * @version 1.0 2016.12.17
 * @author Jeongho Baek
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class SettleBankDepositConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  public SettleBankDepositTasklet settleBankDepositTasklet;
  
  @Autowired
  public CbbkDepositHistoryReadyTasklet cbbkDepositHistoryReadyTasklet;
  
  @Autowired
  public SettleBankDepositResultTasklet settleBankDepositResultTasklet;
  
  // 4분마다 실행
//  @Scheduled(fixedRate = 240000)
  @Scheduled(cron="0 */4 * * * *")
  public String runSettleBankDeposit() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(settleBankDepositJob(), param);
    
    return execution.getStatus().toString();

  }

  @Bean
  public Job settleBankDepositJob() {

    return jobBuilderFactory
        .get("settleBankDepositJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(settleBankDepositStep())
        .next(cbbkDepositHistoryReadyStep())
        .next(settleBankDepositResultStep())
        .build();
  }
  
  // 세틀뱅크 입금내역 조회
  @Bean
  public Step settleBankDepositStep() {

    return stepBuilderFactory
        .get("settleBankDepositStep")
        .tasklet(settleBankDepositTasklet)
        .build();
  }
  
  // 가상계좌 입금 히스토리 테이블 
  @Bean
  public Step cbbkDepositHistoryReadyStep() {
    
    return stepBuilderFactory
        .get("cbbkDepositHistoryReadyStep")
        .tasklet(cbbkDepositHistoryReadyTasklet)
        .build();
  }
  
  // 세틀뱅크 입금내역 조회
  @Bean
  public Step settleBankDepositResultStep() {
    
    return stepBuilderFactory
        .get("settleBankDepositStep")
        .tasklet(settleBankDepositResultTasklet)
        .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}