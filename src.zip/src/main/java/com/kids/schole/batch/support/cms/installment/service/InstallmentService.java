package com.kids.schole.batch.support.cms.installment.service;

import java.util.List;

import com.kids.schole.batch.support.order.domain.InstallmentPayment;

public interface InstallmentService {

  List<InstallmentPayment> getInstallmentPaymentStatusWaitList(
      InstallmentPayment installmentPayment);

  void modifyInstallmentPaymentStatusProcessing(String nowDate);

  void modifyInstallmentPaymentStatusFail(InstallmentPayment installmentPaymentFail);

  List<InstallmentPayment> getInstallmentPaymentProcessingList(
      InstallmentPayment installmentPayment);

  void modifyAllProcessingListDone(InstallmentPayment installmentPayment);

  void modifyInstallmentPaymentDoneStatusFail(InstallmentPayment tempInstallmentPayment);

  void modifyOrderPayDoneAmt(String paymentDueDate);
  
  void modifyConsumerOrderPayDoneAmt(String paymentDueDate);

  void modifyInstallmentPaymentRequestCheckStatus();

}
