package com.kids.schole.batch.support.albam.domain;

import com.google.gson.annotations.SerializedName;

public class RollsReponse {

  private Integer returnCode;
  private String returnMessage;
  @SerializedName("response")
  private RollsResult rollsResult;

  public Integer getReturnCode() {
    return returnCode;
  }
  public void setReturnCode(Integer returnCode) {
    this.returnCode = returnCode;
  }
  public String getReturnMessage() {
    return returnMessage;
  }
  public void setReturnMessage(String returnMessage) {
    this.returnMessage = returnMessage;
  }
  public RollsResult getRollsResult() {
    return rollsResult;
  }
  public void setRollsResult(RollsResult rollsResult) {
    this.rollsResult = rollsResult;
  }

}
