package com.kids.schole.batch.support.product.domain;

public class Product {

}
