package com.kids.schole.batch.execute.consumer.purchase;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.galaxia.api.Command;
import com.galaxia.api.MessageTag;
import com.galaxia.api.ServiceBroker;
import com.galaxia.api.ServiceCode;
import com.galaxia.api.merchant.Message;
import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.card.domain.PgTransactionLog;
import com.kids.schole.batch.support.card.service.CardService;
import com.kids.schole.batch.support.order.domain.PgCreditCard;
import com.kids.schole.batch.support.order.service.ConsumerOrderService;
import com.kids.schole.common.constant.PaymentConst;
import com.kids.schole.common.properties.PgCreditCardProperties;
import com.kids.schole.common.util.PaymentGateUtil;

@Component
public class PgSingleCopyPurchaseRequestTasklet implements Tasklet {

  @Autowired
  private PgCreditCardProperties pgCreditCardProperties;

  @Autowired
  private ConsumerOrderService consumerOrderService;

  @Autowired
  private CardService cardService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    List<PgCreditCard> pgCreditCardList = new ArrayList<PgCreditCard>();

    // 낱권유상 카드승인요청 리스트를 가져온다.
    List<CardPaymentRequest> cardPaymentRequestList = consumerOrderService.getSingleCopyOrderApprovalList();

    for (CardPaymentRequest cardPaymentRequest : cardPaymentRequestList) {

      PgCreditCard pgCreditCard = new PgCreditCard();
      pgCreditCard = getDefaultValuePgCreditCard(pgCreditCard);

      // 1. 매입정보 세팅
      pgCreditCard.setOrderDate(DateFormatUtils.format(new Date(), "yyyyMMddHHmmss"));
      pgCreditCard.setOrderId(cardPaymentRequest.getCardPaymentRequestId() + "");

      Message requestMsg = new Message(pgCreditCard.getVersion(), pgCreditCard.getServiceId(),
          ServiceCode.CREDIT_CARD, Command.JOB_START_REQUEST, pgCreditCard.getOrderId(),
          pgCreditCard.getOrderDate(),
          PaymentGateUtil.getGalaxiaCipher(pgCreditCard.getServiceId()));

      // 현재 카드 결재 요청ID 를 이용하여 마지막으로 통신한 PG 전문 기록을 가져온다.
      PgTransactionLog pgTransactionLog =
          cardService.getLastPgTransactionLog(cardPaymentRequest.getCardPaymentRequestId());

      requestMsg.put(MessageTag.TRANSACTION_ID, pgTransactionLog.getPgTransactionId());

      Message responseMsg = null;

      // 2. 오프라인(수기결제) 매입 요청을 한다.
      try {
        ServiceBroker sb = new ServiceBroker(PaymentGateUtil.getGalaxiaConfigEnvFilePath(),
            ServiceCode.CREDIT_CARD);
        responseMsg = sb.invoke(requestMsg);
      } catch (Exception e) {
        e.printStackTrace();
      }

      // 3. 응답받은 값을 다시 변환해서 저장을 한다.
      pgCreditCard.setServiceCode(responseMsg.getServiceCode());
      pgCreditCard.setResonpseCommand(responseMsg.getCommand());
      pgCreditCard.setResponseCode(responseMsg.get(MessageTag.RESPONSE_CODE));
      pgCreditCard.setResponseMessage(responseMsg.get(MessageTag.RESPONSE_MESSAGE));
      pgCreditCard.setDetailResponseCode(responseMsg.get(MessageTag.DETAIL_RESPONSE_CODE));
      pgCreditCard.setDetailResponseMessage(responseMsg.get(MessageTag.DETAIL_RESPONSE_MESSAGE));
      pgCreditCard.setTransactionId(responseMsg.get(MessageTag.TRANSACTION_ID));

      // 4. 전문결과를 테이블에 저장을 한다.
      PgTransactionLog tempPgTransactionLog = new PgTransactionLog();
      tempPgTransactionLog.setPgTransactionType(PaymentConst.PG_TRANSACTION_TYPE_PURCAHSE);
      tempPgTransactionLog =
          pgCreditCardConvertPgTransactionLog(pgCreditCard, tempPgTransactionLog);
      cardService.createPgTransactionLog(tempPgTransactionLog);

      pgCreditCardList.add(pgCreditCard);

    }

    // Step간의 값을 전달하기 위해 사용한다.
    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("cardPaymentRequestList", cardPaymentRequestList);
    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("pgCreditCardList", pgCreditCardList);

    return RepeatStatus.FINISHED;
  }

  /**
   * 신용카드 통신을 하기 위해 공통적으로 쓰이는 값을 기본 세팅한다.
   *
   * @param PgCreditCard 신용카드 정보
   * @return PgCreditCard 신용카드 정보
   * 
   */
  public PgCreditCard getDefaultValuePgCreditCard(PgCreditCard pgCreditCard) {

    // 사용자 IP
    try {
      InetAddress local = InetAddress.getLocalHost();
      pgCreditCard.setUserIp(local.getHostAddress());
    } catch (UnknownHostException e) {
      e.printStackTrace();
    }

    pgCreditCard.setVersion(pgCreditCardProperties.getVersion());
    pgCreditCard.setServiceId(pgCreditCardProperties.getServiceId());
    pgCreditCard.setItemCode(pgCreditCardProperties.getItemCode());
    pgCreditCard.setCertType(pgCreditCardProperties.getCertType());
    pgCreditCard.setUsingType(pgCreditCardProperties.getUsingType());
    pgCreditCard.setCurrency(pgCreditCardProperties.getCurrency());
    pgCreditCard.setOpcode(pgCreditCardProperties.getOpcode());

    return pgCreditCard;

  }

  // 전문 결과값을 다시 세팅을 한다.
  private PgTransactionLog pgCreditCardConvertPgTransactionLog(PgCreditCard pgCreditCard,
      PgTransactionLog pgTransactionLog) {

    pgTransactionLog.setCardPaymentRequestId(Integer.parseInt(pgCreditCard.getOrderId()));
    pgTransactionLog.setPgTransactionId(pgCreditCard.getTransactionId());
    pgTransactionLog.setResponseCode(pgCreditCard.getResponseCode());
    pgTransactionLog.setResponseMessage(pgCreditCard.getResponseMessage());
    pgTransactionLog.setDetailResponseCode(pgCreditCard.getDetailResponseCode());
    pgTransactionLog.setDetailResponseMessage(pgCreditCard.getDetailResponseMessage());
    pgTransactionLog.setRegisteredEmpNumber(99999);

    return pgTransactionLog;

  }

}
