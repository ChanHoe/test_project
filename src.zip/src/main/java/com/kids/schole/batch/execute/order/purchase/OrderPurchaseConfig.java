package com.kids.schole.batch.execute.order.purchase;

/**
 * OrderPurchaseConfig는 신용카드로 기승인한 주문을 PG와 연동하여 매입처리를 한 후  
 * 그 결과를 처리하는 클래스입니다.
 * 
 * @version 1.0 2016.12.17
 * @author Jeongho Baek
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class OrderPurchaseConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private PgPurchaseRequestTasklet pgPurchaseRequestTasklet;
  
  @Autowired
  private CardPaymentRequestPurchaseRequestTasklet cardPaymentRequestPurchaseRequestTasklet;
  
  @Autowired
  private OrderPaymentPurchaseRequestTasklet orderPaymentPurchaseRequestTasklet;
  
  @Autowired
  private OrderPurchaseRequestTasklet orderPurchaseRequestTasklet;
  
  @Autowired
  private DeliveryWaitTasklet deliveryWaitTasklet;
  
  @Autowired
  private InstallmentPaymentTasklet installmentPaymentTasklet;

  // 저녁 7시에 실행
  @Scheduled(cron = "0 0 19 * * ?")
  public String runOrderPurcahse() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(orderPurchaseJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job orderPurchaseJob() {

    return jobBuilderFactory
        .get("orderPurchaseJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(pgPurchaseRequestStep())
        .next(cardPaymentRequestPurchaseStep())
        .next(orderPaymentPurchaseStep())
        .next(orderPurchaseStep())
        .next(deliveryWaitStep())
        .next(installmentPaymentStep())
        .build();
  }

  // PG 전문통신 및 전문기록로그 기록
  @Bean
  public Step pgPurchaseRequestStep() {
    return stepBuilderFactory
        .get("pgPurchaseRequestStep")
        .tasklet(pgPurchaseRequestTasklet)
        .build();
  }

  // 카드결제요청 테이블 수정
  @Bean
  public Step cardPaymentRequestPurchaseStep() {
    return stepBuilderFactory
        .get("cardPaymentRequestPurchaseStep")
        .tasklet(cardPaymentRequestPurchaseRequestTasklet)
        .build();
  }
  
  // 결제작업정보 테이블 수정
  @Bean
  public Step orderPaymentPurchaseStep() {
    return stepBuilderFactory
        .get("orderPaymentPurchaseStep")
        .tasklet(orderPaymentPurchaseRequestTasklet)
        .build();
  }
  
  // 주문 테이블 수정
  @Bean
  public Step orderPurchaseStep() {
    return stepBuilderFactory
        .get("orderPurchaseStep")
        .tasklet(orderPurchaseRequestTasklet)
        .build();
  }
  
  // 배송 요청 상태를 대기로 변경
  @Bean
  public Step deliveryWaitStep() {
    return stepBuilderFactory
        .get("deliveryWaitStep")
        .tasklet(deliveryWaitTasklet)
        .build();
  }
  
  // 할부 일 경우 완료 시킴
  @Bean
  public Step installmentPaymentStep() {
    return stepBuilderFactory
        .get("installmentPaymentStep")
        .tasklet(installmentPaymentTasklet)
        .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}
