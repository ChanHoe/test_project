package com.kids.schole.batch.execute.consumer.autoAllot;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.service.ConsumerDeliveryService;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.common.constant.DeliveryConst;

@Component
public class ConsumerCbbkDeliveryWaitTasklet implements Tasklet {

  @Autowired
  private ConsumerDeliveryService consumerDeliveryService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<Order> orderList = (List<Order>) chunkContext.getStepContext().getStepExecution()
        .getJobExecution().getExecutionContext().get("orderList");

    for (Order order : orderList) {
      DeliveryRequest deliveryRequest = new DeliveryRequest();
      deliveryRequest.setOrderId(order.getOrderId());
      deliveryRequest.setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_WAIT);
      deliveryRequest.setLastUpdatedEmpNumber(99999);
      consumerDeliveryService.modifyConsumerDeliveryRequestStatusWait(deliveryRequest);
    }

    return RepeatStatus.FINISHED;
    
  }

}
