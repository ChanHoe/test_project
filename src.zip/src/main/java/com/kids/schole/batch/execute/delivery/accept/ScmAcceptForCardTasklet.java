package com.kids.schole.batch.execute.delivery.accept;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.WarehouseResponseStatus;
import com.kids.schole.batch.support.delivery.service.DeliveryService;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.WarehouseConst;
import com.kids.schole.common.properties.WarehouseProperties;
import com.kids.schole.common.util.DomainUtil;
import com.kids.schole.common.util.ScmBusinessDayUtil;
import com.kids.schole.common.util.StringUtil;
import com.kids.schole.common.util.WarehouseUtil;

@Component
public class ScmAcceptForCardTasklet implements Tasklet {

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private DeliveryService deliveryService;

  @Autowired
  private WarehouseProperties warehouseProperties;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    String businessDay = ScmBusinessDayUtil.getBusinessDayTodayCalc(1);

    List<DeliveryRequest> deliveryRequestList = new ArrayList<DeliveryRequest>();

    // 현재 배송 대기중인 주문 리스트(결제 타입이 Card)를 가져온다.
    List<Order> orderList = deliveryService.getDeliveryStatusWaitListForCard(businessDay);

    for (Order order : orderList) {

      String[] tempMobileNumber = order.getReceiverMobileNumber().split("-");

      String prefixPhoneNumber = null;
      String infixPhoneNumber = null;
      String suffixPhoneNumber = null;

      if (StringUtils.isNotBlank(order.getReceiverPhoneNumber())) {
        String[] tempPhoneNumber = order.getReceiverPhoneNumber().split("-");
        if (tempPhoneNumber.length == 3) {
          prefixPhoneNumber = tempPhoneNumber[0];
          infixPhoneNumber = tempPhoneNumber[1];
          suffixPhoneNumber = tempPhoneNumber[2];
        }
      }

      // 현재 시간 설정
      LocalDateTime now = LocalDateTime.now();
      DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

      Map<String, String> warehouseMap = new TreeMap<String, String>();
      // 필수 값
      warehouseMap.put("contents_id", order.getWarehouseContentsKey());
      warehouseMap.put("biz_code", warehouseProperties.getBizCode());
      warehouseMap.put("biz_order_number", order.getOrderId() + "");
      warehouseMap.put("biz_delivery_record_id", order.getDeliveryRequestId() + "");
      warehouseMap.put("sender_name", warehouseProperties.getSenderName());
      warehouseMap.put("sender_tel", warehouseProperties.getSenderTel());
      warehouseMap.put("sender_addr", warehouseProperties.getSenderAddr());
      warehouseMap.put("customer_user_id", order.getCustomerId() + "");
      warehouseMap.put("customer_name", order.getReceiverName());
      if (tempMobileNumber.length == 3) {
        warehouseMap.put("customer_phone1", tempMobileNumber[0]);
        warehouseMap.put("customer_phone2", tempMobileNumber[1]);
        warehouseMap.put("customer_phone3", tempMobileNumber[2]);
      } 
      else if (tempMobileNumber.length < 3) {

        String mobileNumber = StringUtil.replace(order.getReceiverMobileNumber(), "-", "");
        if (StringUtil.length(mobileNumber) == 11) {
          warehouseMap.put("customer_phone1", mobileNumber.substring(0, 3));
          warehouseMap.put("customer_phone2", mobileNumber.substring(3, 7));
          warehouseMap.put("customer_phone3", mobileNumber.substring(7));
        } else if (StringUtil.length(mobileNumber) == 10) {
          warehouseMap.put("customer_phone1", mobileNumber.substring(0, 3));
          warehouseMap.put("customer_phone2", mobileNumber.substring(3, 6));
          warehouseMap.put("customer_phone3", mobileNumber.substring(6));
        }
      }
      warehouseMap.put("customer_postcode", order.getDeliveryPostcode());
      warehouseMap.put("customer_addr1", order.getDeliveryAddress());

      // 선택 값
      warehouseMap.put("customer_tel1", StringUtils.defaultString(prefixPhoneNumber));
      warehouseMap.put("customer_tel2", StringUtils.defaultString(infixPhoneNumber));
      warehouseMap.put("customer_tel3", StringUtils.defaultString(suffixPhoneNumber));
      warehouseMap.put("customer_addr2", order.getDeliveryAddressDetail());
      warehouseMap.put("biz_contents_id", "");
      warehouseMap.put("customer_memo", order.getDeliveryMessage());
      warehouseMap.put("payment_time", now.format(dateTimeFormatter));
      warehouseMap.put("delivery_contents_divide_yn", "N");
      warehouseMap.put("record_sub_type", "");
      warehouseMap.put("cs_reason", "");
      warehouseMap.put("cs_admin_id", "");
      warehouseMap.put("cs_admin_name", "");

      warehouseMap = WarehouseUtil.setTimeStampNFingerPrint(warehouseMap);

      String url = warehouseProperties.getUrl() + WarehouseConst.DELIVERY_INSERT_URL;

      // Http Header 세팅
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

      HttpEntity<Map<String, String>> warehouseMapEntity =
          new HttpEntity<Map<String, String>>(warehouseMap, headers);

      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<String> responseEntity =
          restTemplate.postForEntity(url, warehouseMapEntity, String.class);

      Gson gson = new GsonBuilder()
          .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

      WarehouseResponseStatus warehouseResponseStatus =
          gson.fromJson(responseEntity.getBody(), WarehouseResponseStatus.class);

      DomainUtil.retriveDomain(warehouseResponseStatus);

      DeliveryRequest deliveryRequest = new DeliveryRequest();

      if (warehouseResponseStatus.getResultCode().equals("0000")) {
        deliveryRequest.setDeliveryRequestId(order.getDeliveryRequestId());
        deliveryRequest.setOrderId(order.getOrderId());
        deliveryRequest
            .setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_ACCEPTED);
        deliveryRequest.setWarehouseCompleteKey(
            warehouseResponseStatus.getWarehouseResult().getCustomerRecordId());
        deliveryRequest.setLastUpdatedEmpNumber(99999);
      } else {
        deliveryRequest.setDeliveryRequestId(order.getDeliveryRequestId());
        deliveryRequest.setOrderId(order.getOrderId());
        deliveryRequest.setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_WAIT);
        deliveryRequest.setWarehouseCompleteKey("");
        deliveryRequest.setLastUpdatedEmpNumber(99999);
      }

      deliveryRequestList.add(deliveryRequest);

    }

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("deliveryRequestList", deliveryRequestList);

    return RepeatStatus.FINISHED;

  }

}
