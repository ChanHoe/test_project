package com.kids.schole.batch.execute.consumer.purchase;

/**
 * ConsumerOrderPurchaseConfig는 소비자 처리 추가입금을 신용카드로 기승인한 주문을 PG와 연동하여 매입처리를 한 후  
 * 그 결과를 처리하는 클래스입니다.
 * 
 * @version 1.0 2017.03.21
 * @author chheo
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;
import com.kids.schole.batch.execute.order.purchase.CardPaymentRequestPurchaseRequestTasklet;

@Configuration
@EnableBatchProcessing
public class ConsumerOrderPurchaseConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private PgConsumerPurchaseRequestTasklet pgConsumerPurchaseRequestTasklet; 
  
  @Autowired
  private CardPaymentRequestPurchaseRequestTasklet cardPaymentRequestPurchaseRequestTasklet;
  
  @Autowired
  private ConsumerOrderPurchaseRequestTasklet consumerOrderPurchaseRequestTsaklet;
  
  @Autowired
  private ConsumerDeliveryWaitTasklet consumerDeliveryWaitTasklet;


  // 저녁 7시에 실행
  @Scheduled(cron = "0 0 19 * * ?")
  public String runConsumerOrderPurchase() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(consumerOrderPurchaseJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job consumerOrderPurchaseJob() {
    
    return jobBuilderFactory
        .get("consumerOrderPurchaseJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(pgConsumerPurchaseRequestStep())
        .next(consumerCardPaymentRequestPurchaseStep())
        .next(consumerOrderPurchaseStep())
        .next(consumerDeliveryWaitStep())
        .build();
    
  }
  
  //PG 전문통신 및 전문기록로그 기록
  @Bean
  public Step pgConsumerPurchaseRequestStep() {
    return stepBuilderFactory
        .get("pgConsumerPurchaseRequestStep")
        .tasklet(pgConsumerPurchaseRequestTasklet)
        .build();
  }
  
  //카드결제요청 테이블 수정
  @Bean
  public Step consumerCardPaymentRequestPurchaseStep() {
    return stepBuilderFactory
        .get("consumerCardPaymentRequestPurchaseStep")
        .tasklet(cardPaymentRequestPurchaseRequestTasklet)
        .build();
  }
  
  //주문 테이블 수정
  @Bean
  public Step consumerOrderPurchaseStep() {
    return stepBuilderFactory
        .get("consumerOrderPurchaseStep")
        .tasklet(consumerOrderPurchaseRequestTsaklet)
        .build();
  }
  
  //배송 요청 상태를 대기로 변경
  @Bean
  public Step consumerDeliveryWaitStep() {
    return stepBuilderFactory
        .get("consumerDeliveryWaitStep")
        .tasklet(consumerDeliveryWaitTasklet)
        .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}
