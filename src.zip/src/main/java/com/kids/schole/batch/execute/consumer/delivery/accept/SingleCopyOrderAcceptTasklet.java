package com.kids.schole.batch.execute.consumer.delivery.accept;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;
import com.kids.schole.batch.support.order.service.ConsumerOrderService;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.OrderConst;

@Component
public class SingleCopyOrderAcceptTasklet implements Tasklet {

  @Autowired
  private ConsumerOrderService consumerOrderService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<SingleCopyDelivery> singleCopyDeliveryList =
        (List<SingleCopyDelivery>) chunkContext.getStepContext().getStepExecution().getJobExecution()
            .getExecutionContext().get("singleCopyDeliveryList");

    for (SingleCopyDelivery singleCopyDelivery : singleCopyDeliveryList) {
      SingleCopyOrder singleCopyOrder = new SingleCopyOrder();
      singleCopyOrder.setSingleCopyOrderId(singleCopyDelivery.getSingleCopyOrderId());
      
      if(singleCopyDelivery.getSingleCopyDeliveryStatus().equals(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_ACCEPTED)) {
        singleCopyOrder.setSingleCopyOrderStatus(OrderConst.ORDER_STATUS_SCM_ACCEPTED);
      } else {
        singleCopyOrder.setSingleCopyOrderStatus(OrderConst.ORDER_STATUS_ACCEPTED);
      }
      
      consumerOrderService.modifySingleCopyOrderStatus(singleCopyOrder);
    }
    
    return RepeatStatus.FINISHED;

  }

}
