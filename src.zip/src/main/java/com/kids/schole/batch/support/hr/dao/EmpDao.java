package com.kids.schole.batch.support.hr.dao;

import com.kids.schole.batch.support.hr.domain.Emp;

public interface EmpDao {

  public void updatePositionCode(Emp emp);

}
