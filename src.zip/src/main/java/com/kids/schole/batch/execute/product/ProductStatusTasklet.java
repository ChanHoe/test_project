package com.kids.schole.batch.execute.product;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.product.domain.Product;
import com.kids.schole.batch.support.product.service.ProductService;

@Component
public class ProductStatusTasklet implements Tasklet {
  
  /* 로거를 위한 변수 */
  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private ProductService productService;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {
    // TODO Auto-generated method stub
    
    productService.modifyProductStatus();
    
    return RepeatStatus.FINISHED;
  }

}
