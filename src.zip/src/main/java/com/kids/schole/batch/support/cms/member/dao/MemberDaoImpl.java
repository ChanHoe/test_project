package com.kids.schole.batch.support.cms.member.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.domain.OrderAttachedFile;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;

@Repository
public class MemberDaoImpl implements MemberDao {

  @Autowired
  private SqlSession sqlSession;

  @Override
  public List<OrderAttachedFile> selectOrderAttachedFileNewWaitList() {
    return sqlSession.selectList("member.selectOrderAttachedFileNewWaitList");
  }

  @Override
  public void updateMemberProofStatus(OrderAttachedFile orderAttachedFile) {
    sqlSession.update("member.updateMemberProofStatus", orderAttachedFile);
  }

  @Override
  public List<OrderAttachedFile> selectOrderAttachedFileProcessingList() {
    return sqlSession.selectList("member.selectOrderAttachedFileProcessingList");
  }

  @Override
  public List<OrderAttachedFile> selectOrderAttachedFileCancelList() {
    return sqlSession.selectList("member.selectOrderAttachedFileCancelList");
  }

  @Override
  public List<Member> selectMemberWaitList(InstallmentPaymentRequest installmentPaymentRequest) {
    return sqlSession.selectList("member.selectMemberWaitList", installmentPaymentRequest);
  }

  @Override
  public void updateApplicationStatusProcessing(
      InstallmentPaymentRequest installmentPaymentRequest) {
    sqlSession.update("member.updateApplicationStatusProcessing", installmentPaymentRequest);
  }

  @Override
  public void updateApplicationStatusFail(InstallmentPaymentRequest installmentPaymentRequest) {
    sqlSession.update("member.updateApplicationStatusFail", installmentPaymentRequest);
  }

  @Override
  public List<Member> selectMemberProcessingList(
      InstallmentPaymentRequest installmentPaymentRequest) {
    return sqlSession.selectList("member.selectMemberProcessingList", installmentPaymentRequest);
  }

  @Override
  public void updateAllProcessingListDone(InstallmentPaymentRequest installmentPaymentRequest) {
    sqlSession.update("member.updateAllProcessingListDone", installmentPaymentRequest);
  }

  /** 할부계좌 변경한 주문 목록 */
  @Override
  public List<Member> selectModifyAccountInstallments(InstallmentPaymentRequest installmentPaymentRequest) {
    return sqlSession.selectList("member.selectModifyAccountInstallments", installmentPaymentRequest);
  }

  /** 할부계좌 변경한 목록의 회원신청 종류와 상태를 변경해준다.  */
  @Override
  public void updateApplicationStatusWaitAndModify(int installmentPaymentRequestId) {
    sqlSession.update("member.updateApplicationStatusWaitAndModify", installmentPaymentRequestId);
  }
}
