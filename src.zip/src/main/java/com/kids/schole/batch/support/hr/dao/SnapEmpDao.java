package com.kids.schole.batch.support.hr.dao;

import java.util.List;

import com.kids.schole.batch.support.hr.domain.SnapEmp;
import com.kids.schole.batch.support.hr.domain.SnapOrganizationEmp;
import com.kids.schole.batch.support.hr.domain.SnapPersonnelChange;
import com.kids.schole.batch.support.hr.domain.SnapOrganization;

public interface SnapEmpDao {

  public List<SnapEmp> selectEmpList();

  public void deleteSnapEmp(SnapEmp snapEmp);

  public void insertSnapEmp(List<SnapEmp> empList);

  public List<SnapOrganizationEmp> selectOrganizationEmpList();

  public void deleteSnapOrganizationEmp(SnapOrganizationEmp snapOrganizationEmp);

  public void insertSnapOrganizationEmp(List<SnapOrganizationEmp> organizationEmpList);

  public List<SnapOrganization> selectOrganizationList();

  public void deleteSnapOrganization(SnapOrganization snapOrganization);

  public void insertSnapOrganization(List<SnapOrganization> organizationList);

  public List<SnapPersonnelChange> selectPersonnelChangeList();

  public void deleteSnapPersonnelChange(SnapPersonnelChange snapPersonnelChange);

  public void insertSnapPersonnelChange(List<SnapPersonnelChange> personnelChangeList);

}
