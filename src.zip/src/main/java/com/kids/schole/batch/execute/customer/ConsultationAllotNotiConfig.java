package com.kids.schole.batch.execute.customer;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * CustomerStatusConfig는 고객 상담 배분을 처리하는 클래스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
@Configuration
@EnableBatchProcessing
public class ConsultationAllotNotiConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private ConsultationAllotNotiTasklet consultationAllotNotiTasklet;
  
  // 10시 10분 마다 실행한다.
  @Scheduled(cron = "0 10 10 * * ?")
  public String runConsultationAllot() throws Exception {
    
    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
    
    JobExecution execution = jobLauncher.run(consultationAllotNotiJob(), param);
    
    return execution.getStatus().toString();
  }
  
  @Bean
  public Job consultationAllotNotiJob() {
    
    return jobBuilderFactory
        .get("consultationAllotNotiJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(consultationAllotNotiStep())
        .build();
  }
  
  // 고객 상담 미배분 사항 노티 한다.
  @Bean
  public Step consultationAllotNotiStep() {
    
    return stepBuilderFactory
        .get("consultationAllotNotiStep")
        .tasklet(consultationAllotNotiTasklet)
        .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
  
}
