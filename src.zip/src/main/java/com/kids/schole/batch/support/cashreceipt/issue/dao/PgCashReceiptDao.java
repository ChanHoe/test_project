package com.kids.schole.batch.support.cashreceipt.issue.dao;

import java.util.List;

import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceipt;
import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceiptRefund;
import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.domain.SingleCopyCashReceipt;

public interface PgCashReceiptDao {

  // -----------------------------------------------------------------------------------
  // Cashreceipt

  /** 현금영수증 대상건 생성 */
  void insertCashReceipt(CashReceipt cashReceipt);

  /** 현금영수증 대상 조회 */
  List<String> selectCashReceiptsForIssue(String targetDate);
  /** 현금영수증 대상ID 조회 */
  List<Integer> selectCashReceiptIdsForIssue(String targetDate);

  /** 현금영수증  대상건 수정 */
  void updateCashReceiptForBatchLogId(PgCashReceiptBatchLog pgCashReceiptBatchLog);
  /** 현금영수증  대상건(한건) 수정 */
  void updateCashReceiptResultById(CashReceipt cashReceipt);

  /** 가상계좌 현금영수증  대상건 생성(여러건) */
  void insertCashReceiptsForCbbk(String nowDate);
  /** 할부 대체결제 가상계좌 현금영수증  대상건 생성(여러건) */
  void insertCashReceiptsForCbbkSubstitute(String nowDate);

  /** 즉시출금 현금영수증  대상건 생성(여러건) */
  void insertCashReceiptsForCms(String nowDate);
  /** 할부 대체결제 즉시출금 현금영수증  대상건 생성(여러건) */
  void insertCashReceiptsForCmsSubstitute(String nowDate);

  /** 할부 현금영수증  대상건 생성(여러건) */
  void insertCashReceiptsForInstallment(String nowDate);

  /** 현금영수증 취소 대상(여러건, 소비자 포함) */
  List<CashReceiptRefund> selectCashReceiptsForRefund(String nowDate);
  /** 현금영수증 취소 대상 주문ID로 조회 */
  List<CashReceipt> selectCashReceiptsByOrderId(int orderId);

  /** 소비자 처리한 주문의 가상계좌 현금영수증 대상 생성을 위해 주문ID로 조회 */
  List<CashReceipt> selectCbbkCashReceiptsForConsumerByOrderId(int orderId);
  /** 소비자 처리한 주문의 즉시출금 현금영수증 대상 생성을 위해 주문ID로 조회 */
  List<CashReceipt> selectBankCashReceiptsForConsumerByOrderId(int orderId);
  /** 소비자 처리한 주문의 할부금 현금영수증 대상 생성을 위해 주문ID로 조회 */
  List<CashReceipt> selectInstallmentCashReceiptsForConsumerByOrderId(int orderId);

  //-----------------------------------------------------------------------------------
  // SingleCopyCashReceipt

  /** 낱권유상 현금영수증 대상 조회 */
  List<String> selectSingleCopyCashReceiptsForIssue(String targetDate);
  /** 낱권유상 현금영수증 대상ID 조회 */
  List<Integer> selectSingleCopyCashReceiptIdsForIssue(String targetDate);

  /** 낱권유상 현금영수증  대상건 수정 */
  void updateSingleCopyCashReceiptsForBatch(PgCashReceiptBatchLog pgCashReceiptBatchLog);
  /** 낱권유상 현금영수증  대상건(한건) 수정 */
  void updateSingleCopyCashReceiptResultById(SingleCopyCashReceipt singleCopyCashReceipt);

  // -----------------------------------------------------------------------------------
  // PgCashReceiptBatchLog

  /** 현금영수증 배치로그 생성 */
  void insertCashReceiptBatchLog(PgCashReceiptBatchLog pgCashReceiptBatchLog);
  /** 현금영수증 배치로그 수정 */
  void updateCashReceiptBatchLog(PgCashReceiptBatchLog pgCashReceiptBatchLog);


}
