package com.kids.schole.batch.support.log.dao;

/**
 * LogDao는 배치로그 삭제를 위한 DAO 인터페이스입니다.
 * 
 * @version 1.0 2017.01.04
 * @author Jeongwon Son
 */
public interface LogDao {
  
  void deleteBatchStepExecutionContext();
  
  void deleteBatchStepExecution();
  
  void deleteBatchJobExecutionContext();
  
  void deleteBatchJobExecutionParams();
  
  void deleteBatchJobExecution();
  
  void deleteBatchJobInstance();
  
}
