package com.kids.schole.batch.support.cashreceipt.issue.domain;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.kids.schole.common.constant.PaymentConst;
import com.kids.schole.common.properties.CashReceiptProperties;
import com.kids.schole.common.util.StringUtil;

/**
 * 현금영수증 배치 로그
 *
 * @author 최인혜
 */
public class PgCashReceiptBatchLog {

  /** ID */
  private int cashReceiptBatchLogId;
  /** 배치유형(issue:발행요청, result:결과조회) */
  private String batchType;
  /** 파일경로 */
  private String filePath;
  /** 파일명 */
  private String fileName;
  /** 발행요청일자 */
  private String requestDate;
  /** 응답코드 */
  private String responseCode;
  /** 응답메시지 */
  private String responseMessage;
  /** 상세 응답코드 */
  private String detailResponseCode;
  /** 상세 응답메시지 */
  private String detailResponseMessage;
  /** 생성자 */
  private int registeredEmpNumber;
  /** 생성일시 */
  private String registeredDatetime;
  /** 변경자 */
  private int lastUpdatedEmpNumber;
  /** 변경일시 */
  private String lastUpdatedDatetime;

  //---------------------------------------------------------------------------------------------------------------
  // 실제 저장되는 값이 아님.

  private List<CashReceipt> cashReceipts;
  private List<Integer> cashReceiptIds;
  private List<Integer> singleCopyCashReceiptIds;

  //---------------------------------------------------------------------------------------------------------------

  public PgCashReceiptBatchLog() {}

  public PgCashReceiptBatchLog(String batchType) {
    this();
    this.batchType = batchType;
    this.requestDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
  }

  public static PgCashReceiptBatchLog createIssueCashReceipt(CashReceiptProperties cashReceiptProperties) {
    PgCashReceiptBatchLog cashReceiptBatchLog = new PgCashReceiptBatchLog(PaymentConst.CASH_RECEIPT_BATCH_REQUEST_TYPE_ISSUE);

    LocalDate now = LocalDate.now();

    StringBuilder filePathBuilder = new StringBuilder(cashReceiptProperties.getRequestFilePath());
    filePathBuilder.append(now.format(DateTimeFormatter.ofPattern("yyyy")));
    filePathBuilder.append(File.separator);
    filePathBuilder.append(File.separator);
    cashReceiptBatchLog.setFilePath(filePathBuilder.toString());

    cashReceiptBatchLog.setFileName(now.format(DateTimeFormatter.ofPattern("yyyyMMdd"))+".txt");

    return cashReceiptBatchLog;
  }

  public static PgCashReceiptBatchLog createResultCashReceipt(String fromDate, String thruDate, CashReceiptProperties cashReceiptProperties) {
    PgCashReceiptBatchLog cashReceiptBatchLog = new PgCashReceiptBatchLog(PaymentConst.CASH_RECEIPT_BATCH_REQUEST_TYPE_RESULT);

    LocalDate now = LocalDate.now();

    StringBuilder filePathBuilder = new StringBuilder(cashReceiptProperties.getResponseFilePath());
    filePathBuilder.append(now.format(DateTimeFormatter.ofPattern("yyyy")));
    cashReceiptBatchLog.setFilePath(filePathBuilder.toString());

    String searchDate = now.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    if (StringUtil.isBlank(fromDate)) fromDate = searchDate;
    if (StringUtil.isBlank(thruDate)) thruDate = searchDate;

    StringBuilder fileNameBuilder = new StringBuilder(cashReceiptProperties.getMid());
    fileNameBuilder.append("_");
    fileNameBuilder.append(searchDate);
    fileNameBuilder.append("_NTS_");
    fileNameBuilder.append(fromDate);
    fileNameBuilder.append("_");
    fileNameBuilder.append(thruDate);
    fileNameBuilder.append(".txt");
    cashReceiptBatchLog.setFileName(fileNameBuilder.toString());

    return cashReceiptBatchLog;
  }

  /** 성공여부 */
  public boolean isSuccess() {
    if (StringUtil.isBlank(this.responseCode)) return false;
    if ("0000".equals(this.responseCode)) {
      return true;
    }
    return false;
  }

  /** 파일명을 path까지 가져옴 */
  public String getFullFileName() {
    if (StringUtil.isBlank(this.filePath)) return "";
    if (StringUtil.isBlank(this.fileName)) return "";

    if (PaymentConst.CASH_RECEIPT_BATCH_REQUEST_TYPE_RESULT.equals(this.batchType)) {
      this.filePath += File.separator;
    }
    return this.filePath + this.fileName;
  }

  /** 현금영수증 요청상태 */
  public String getRequestReadyStatus() {
    return PaymentConst.CASH_RECEIPT_REQUEST_STATUS_READY;
  }
  public String getRequestProcessingStatus() {
    return PaymentConst.CASH_RECEIPT_REQUEST_STATUS_PROCESSING;
  }
  public String getRequestSuccessStatus() {
    return PaymentConst.CASH_RECEIPT_REQUEST_STATUS_SUCCESS;
  }

  //---------------------------------------------------------------------------------------------------------------

  public int getCashReceiptBatchLogId() {
    return cashReceiptBatchLogId;
  }
  public void setCashReceiptBatchLogId(int cashReceiptBatchLogId) {
    this.cashReceiptBatchLogId = cashReceiptBatchLogId;
  }
  public String getBatchType() {
    return batchType;
  }
  public void setBatchType(String batchType) {
    this.batchType = batchType;
  }
  public String getFilePath() {
    return filePath;
  }
  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }
  public String getFileName() {
    return fileName;
  }
  public void setFileName(String fileName) {
    this.fileName = fileName;
  }
  public String getResponseCode() {
    return responseCode;
  }
  public void setResponseCode(String responseCode) {
    this.responseCode = responseCode;
  }
  public String getResponseMessage() {
    return responseMessage;
  }
  public void setResponseMessage(String responseMessage) {
    this.responseMessage = responseMessage;
  }
  public String getDetailResponseCode() {
    return detailResponseCode;
  }
  public void setDetailResponseCode(String detailResponseCode) {
    this.detailResponseCode = detailResponseCode;
  }
  public String getDetailResponseMessage() {
    return detailResponseMessage;
  }
  public void setDetailResponseMessage(String detailResponseMessage) {
    this.detailResponseMessage = detailResponseMessage;
  }
  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public List<CashReceipt> getCashReceipts() {
    return cashReceipts;
  }

  public void setCashReceipts(List<CashReceipt> cashReceipts) {
    this.cashReceipts = cashReceipts;
  }

  public List<Integer> getCashReceiptIds() {
    return cashReceiptIds;
  }

  public void setCashReceiptIds(List<Integer> cashReceiptIds) {
    this.cashReceiptIds = cashReceiptIds;
  }

  public String getRequestDate() {
    return requestDate;
  }

  public void setRequestDate(String requestDate) {
    this.requestDate = requestDate;
  }

  public List<Integer> getSingleCopyCashReceiptIds() {
    return singleCopyCashReceiptIds;
  }

  public void setSingleCopyCashReceiptIds(List<Integer> singleCopyCashReceiptIds) {
    this.singleCopyCashReceiptIds = singleCopyCashReceiptIds;
  }



}
