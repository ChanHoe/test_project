package com.kids.schole.batch.support.hr.service;

public interface SnapEmpService {

  public void createSnapEmp();

  public void createSnapOrganizationEmp();

  public void createSnapOrganiztion();

  public void createSnapPersonnelChange();

}
