package com.kids.schole.batch.support.hr.domain;

/**
 * SnapOrganizationEmp 테이블과 매핑하기 위한 도메인 클래스입니다.
 *
 * @version 1.0 2017. 02. 02
 * @author Jeongwon Son
 */
public class SnapOrganizationEmp {

  private Integer organizationId;
  private Integer empNumber;
  private String jobTitleCode;
  private Integer registeredEmpNumber;
  private String registeredDatetime;
  private Integer lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;
 
  // 판매년도, 판매월
  private String saleYear;
  private String saleMonth;
  
  public Integer getOrganizationId() {
    return organizationId;
  }
  public void setOrganizationId(Integer organizationId) {
    this.organizationId = organizationId;
  }
  public Integer getEmpNumber() {
    return empNumber;
  }
  public void setEmpNumber(Integer empNumber) {
    this.empNumber = empNumber;
  }
  public String getJobTitleCode() {
    return jobTitleCode;
  }
  public void setJobTitleCode(String jobTitleCode) {
    this.jobTitleCode = jobTitleCode;
  }
  public Integer getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(Integer registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public Integer getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(Integer lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public String getSaleYear() {
    return saleYear;
  }
  public void setSaleYear(String saleYear) {
    this.saleYear = saleYear;
  }
  public String getSaleMonth() {
    return saleMonth;
  }
  public void setSaleMonth(String saleMonth) {
    this.saleMonth = saleMonth;
  }
  
}
