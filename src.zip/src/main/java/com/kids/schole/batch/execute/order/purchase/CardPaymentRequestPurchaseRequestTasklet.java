package com.kids.schole.batch.execute.order.purchase;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.card.service.CardService;
import com.kids.schole.batch.support.order.domain.PgCreditCard;
import com.kids.schole.common.constant.PaymentConst;

@Component
public class CardPaymentRequestPurchaseRequestTasklet implements Tasklet {

  @Autowired
  private CardService cardService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<PgCreditCard> pgCreditCardList = (List<PgCreditCard>) chunkContext.getStepContext()
        .getStepExecution().getJobExecution().getExecutionContext().get("pgCreditCardList");

    for (PgCreditCard pgCreditCard : pgCreditCardList) {

      // 응답받은 데이터를 다시 카드결제요청 테이블에 업데이트 시킨다. (요청상태만 변경)
      CardPaymentRequest responseCardPaymentRequest = new CardPaymentRequest();

      responseCardPaymentRequest
          .setCardPaymentRequestId(Integer.parseInt(pgCreditCard.getOrderId()));

      if (pgCreditCard.getResponseCode().equals("0000")) {
        responseCardPaymentRequest.setRequestStatus(PaymentConst.REQUEST_STATUS_PURCHASE);
      } else {
        responseCardPaymentRequest.setRequestStatus(PaymentConst.REQUEST_STATUS_PURCHASE_FAIL);
      }

      responseCardPaymentRequest.setLastUpdatedEmpNumber(99999);
      cardService.modifyCardPaymentRequestStatus(responseCardPaymentRequest);

    }

    return RepeatStatus.FINISHED;

  }

}
