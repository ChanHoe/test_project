package com.kids.schole.batch.support.sales.service;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.sales.dao.SalesInfoDao;
import com.kids.schole.common.util.DateUtil;
import com.kids.schole.common.util.StringUtil;

/**
 * SalesInfoServiceImpl은 매출 집계 처리를 위한 서비스 클래스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
@Service
public class SalesInfoServiceImpl implements SalesInfoService {

	@Autowired
	private SalesInfoDao salesInfoDao;

	/**
	 * 일별 매출
	 * 
	 */
	@Override
	public int createDailySaleInfo(String firstDate) {

		try {
			// 입력 또는 시스템 날짜
			if(StringUtil.isNull(firstDate)){
				firstDate = DateUtil.getSysDateFirst();
			}
			String nextDate = firstDate;
			
			// 해당월 첫날과 다음월 첫날 구함
			Date date = DateUtil.getDate(firstDate);
			firstDate = DateUtil.getSysDateFormat(date, "yyyy-MM-")+"01";
			nextDate = DateUtil.getSysDateFormat(DateUtil.getDateAdd(date, Calendar.MONTH, 1), "yyyy-MM-")+"01";
			String saleYear  = DateUtil.getSysDateFormat(date, "yyyy");
			String saleMonth = DateUtil.getSysDateFormat(date, "MM");
		
			HashMap<String, String> param = new HashMap<String, String>();
			param.put("firstDate", firstDate);
			param.put("nextDate", nextDate);
			param.put("saleYear", saleYear);
			param.put("saleMonth", saleMonth);
			
			System.out.println(param.toString());
			salesInfoDao.insertDailySaleInfo(param);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 1;
	}

	/**
	 * 월간 매출
	 *  
	 */
	@Override
	public int createMonthlySaleInfo(String firstDate) {

		try {
			// 입력 또는 시스템 날짜
			if(StringUtil.isNull(firstDate)){
				firstDate = DateUtil.getSysDateFirst();
			}

			// 해당 연도와 월을 구함
			Date date = DateUtil.getDate(firstDate);
			String saleYear  = DateUtil.getSysDateFormat(date, "yyyy");
			String saleMonth = DateUtil.getSysDateFormat(date, "MM");

			HashMap<String, String> param = new HashMap<String, String>();
			param.put("saleYear", saleYear);
			param.put("saleMonth", saleMonth);
			
			salesInfoDao.insertMonthlySaleInfo(param);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
	}

	/**
	 * 월별 인원현황
	 * 
	 */
	@Override
	public int createMonthlyEMPSaleInfo(String firstDate) {

		try {
			// 입력 또는 시스템 날짜
			if(StringUtil.isNull(firstDate)){
				firstDate = DateUtil.getSysDateFirst();
			}

			// 해당 연도와 월을 구함
			Date date = DateUtil.getDate(firstDate);
			String saleYear  = DateUtil.getSysDateFormat(date, "yyyy");
			String saleMonth = DateUtil.getSysDateFormat(date, "MM");

			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("saleYear", saleYear);
			param.put("saleMonth", saleMonth);
			
			// 1. 재직중 인원 현황 추출
			List<HashMap<String, Object>> mapList = new ArrayList<HashMap<String,Object>>();
			
			if(saleYear.equals(DateUtil.getSysDateFormat("yyyy")) && saleMonth.equals(DateUtil.getSysDateFormat("MM"))){
				mapList = salesInfoDao.selectCurrentMonthlyEMPSaleInfoList(param);
			}else{
				mapList = salesInfoDao.selectMonthlyEMPSaleInfoList(param);
			}
			
			System.out.println("mapList.size() :: "+mapList.size());
			HashMap<String, Object> returnMap = null;

			salesInfoDao.deleteMonthlyEmpInfo(param);
			
			for(HashMap<String, Object> result : mapList){
				
				// 2. 최근 발령 정보 추출
				int empNumber = (int) result.get("emp_number");
				param.put("empNumber", empNumber);

				if(saleYear.equals(DateUtil.getSysDateFormat("yyyy")) && saleMonth.equals(DateUtil.getSysDateFormat("MM"))){
					returnMap = salesInfoDao.selectCurrentPersonnelChange(param);
				}else{
					returnMap = salesInfoDao.selectPersonnelChange(param);
				}
				
				result.put("personnel_change_name", returnMap.get("code_name"));
				result.put("personnel_change_type", returnMap.get("personnel_change_type"));
				result.put("personnel_change_datetime", returnMap.get("work_begin_date"));
				result.put("position_code", returnMap.get("position_code"));
				
				// 3. 누적금액 추출
				returnMap.clear();
				param.put("empKey", (String) result.get("emp_key"));
				returnMap = salesInfoDao.selectMonthlySaleInfoSum(param);
				result.put("pay_total_order_amt", returnMap.get("pay_total_order_amt"));
				result.put("pay_month_order_amt", returnMap.get("pay_month_order_amt"));
				
				// 4. 미팅일수
				int meeting_count = salesInfoDao.selectDailyMeetingCount(param);
				result.put("meeting_count", meeting_count);
				
				// 5. 저장
				salesInfoDao.insertMonthlyEmpInfo(result);
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
	}

	/**
	 * 월별 조직현황
	 * 
	 */
	@Override
	public int createMonthlyORGSaleInfo(String firstDate) {
		
		try {
			// 입력 또는 시스템 날짜
			if(StringUtil.isNull(firstDate)){
				firstDate = DateUtil.getSysDateFirst();
			}

			// 해당 연도와 월을 구함
			Date date = DateUtil.getDate(firstDate);
			String saleYear  = DateUtil.getSysDateFormat(date, "yyyy");
			String saleMonth = DateUtil.getSysDateFormat(date, "MM");
			
			// 해당월 첫날과 다음월 첫날 구함
			firstDate = DateUtil.getSysDateFormat(date, "yyyy-MM-")+"01";
			String nextDate = DateUtil.getSysDateFormat(DateUtil.getDateAdd(date, Calendar.MONTH, 1), "yyyy-MM-")+"01";

			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("saleYear", saleYear);
			param.put("saleMonth", saleMonth);
			param.put("firstDate", firstDate);
			param.put("nextDate", nextDate);
			
			// 1. 월별 지점 조직 현황
			List<HashMap<String, Object>> mapList = salesInfoDao.selectMonthlyORGBranchInfoList(param);
			System.out.println("mapList.size() :: "+mapList.size());
			salesInfoDao.deleteMonthlyORGInfo(param);
			
			for(HashMap<String, Object> result : mapList){
			
				// 2. 활동인원, 실적인원
				int branch_organization_id = (int) result.get("branch_organization_id");
				param.put("branchOrganizationId", branch_organization_id);
			//	List<HashMap<String, Object>> empList = salesInfoDao.selectMonthlyORGEmpCount(param);


				List<HashMap<String, Object>> empList = new ArrayList<HashMap<String,Object>>();
				
				if(saleYear.equals(DateUtil.getSysDateFormat("yyyy")) && saleMonth.equals(DateUtil.getSysDateFormat("MM"))){
					empList = salesInfoDao.selectCurrentMonthlyORGEmpCount(param);
				}else{
					empList = salesInfoDao.selectMonthlyORGEmpCount(param);
				}
				
				int saleEmpCount = 0;
				int activeEmpCount = 0;
				for(HashMap<String, Object> empCountList : empList){
					/** 매출100만원이상, 미팅15일이상 인 인원 >> 예외1) 업무등록월은 미팅 7일이상만 체크, 예외2) 외곽지여부가 true인 경우 5일만 체크
						사업런칭 1월만 5일체크 */
					int pay_total_order_amt = StringUtil.toInt(String.valueOf(empCountList.get("pay_total_order_amt")));
					boolean is_suburb = (boolean) empCountList.get("is_suburb");
					String work_begin_date  = String.valueOf(empCountList.get("work_begin_date"));

					int meet_count = Integer.parseInt(String.valueOf( empCountList.get("meet_count") ));
					if(saleYear.equals("2017") && saleMonth.equals("01")){
						// 사업런칭 1월만 5일체크
						if(meet_count >= 5){
							activeEmpCount += 1;
						}
					}else{
						// 업무등록월은 매출 100만원 이상, 7일 체크
						if(work_begin_date.contains(saleYear+"-"+saleMonth)){
							// 매출 100만원 이상 체크
							if(pay_total_order_amt >= 100000 ){
								// 외곽지여부가 true인 경우 5일 이상 체크
								if(is_suburb){
									if(meet_count >= 5)  activeEmpCount += 1;
								// 외곽지여부가 false인 경우 7일 이상 체크
								}else{
									if(meet_count >= 7)  activeEmpCount += 1;
								}
							}
						// 이외는 매출 1000만원 이상 체크
						}else if(pay_total_order_amt >= 1000000 ){

							// 외곽지여부가 true인 경우 5일 이상 체크
							if(is_suburb){
								if(meet_count >= 5)  activeEmpCount += 1;
							// 외곽지여부가 false인 경우 15일 이상 체크
							}else{
								if(meet_count >= 15)  activeEmpCount += 1;
							}
						}
					} //if 런칭일

					// 실적인원
					if(pay_total_order_amt > 0){
						saleEmpCount += 1;
					}
				}// for
				
				// 1. 활동인원 조건 위에서
				result.put("active_emp_count", activeEmpCount);
				
				// 2. 실적인원 1원 이상
				result.put("sale_emp_count", saleEmpCount);
				
				// 3. 지점 등록 인원
				int registerEmpCount = 0;
				if(saleYear.equals(DateUtil.getSysDateFormat("yyyy")) && saleMonth.equals(DateUtil.getSysDateFormat("MM"))){
					registerEmpCount = salesInfoDao.selectCurrentMonthlyORGRegisterEmpCount(param);
				}else{
					registerEmpCount = salesInfoDao.selectMonthlyORGRegisterEmpCount(param);
				}
				
				result.put("register_emp_count", registerEmpCount);
				
				// 4. 무실적 인원
				result.put("ready_emp_count", empList.size()-saleEmpCount);
				
				// 5. 해약인원
				int expireEmpCount = 0;
				if(saleYear.equals(DateUtil.getSysDateFormat("yyyy")) && saleMonth.equals(DateUtil.getSysDateFormat("MM"))){
					expireEmpCount = salesInfoDao.selectCurrentMonthlyORGExpireEmpCount(param);
				}else{
					expireEmpCount = salesInfoDao.selectMonthlyORGExpireEmpCount(param);
				}
				result.put("expire_emp_count", expireEmpCount);
			
				// 6. 최종 입력
				salesInfoDao.insertMonthlyORGInfo(result);
			}

			// 7. 지점 롤업하여 라운지 생성
			salesInfoDao.insertMonthlyORGLoungeInfo(param);
			
		}catch(Exception e){
			e.printStackTrace();
		}	
		return 0;
	}
}
