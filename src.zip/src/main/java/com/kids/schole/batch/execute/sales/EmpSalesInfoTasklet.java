package com.kids.schole.batch.execute.sales;

import java.util.Map;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.sales.service.SalesInfoService;

@Component
public class EmpSalesInfoTasklet implements Tasklet {
  
  @Autowired
  private SalesInfoService salesInfoService;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {
    
	  Map<String, Object> param = chunkContext.getStepContext().getJobParameters();
	  
	  salesInfoService.createMonthlyEMPSaleInfo((String)param.get("firstDate"));
    
	  return RepeatStatus.FINISHED;
  }

}
