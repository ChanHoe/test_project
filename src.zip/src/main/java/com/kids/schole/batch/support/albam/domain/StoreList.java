package com.kids.schole.batch.support.albam.domain;

public class StoreList {
  
  private Integer storeId;
  private String storeName;
  private Integer staffCnt;

  public Integer getStoreId() {
    return storeId;
  }
  public void setStoreId(Integer storeId) {
    this.storeId = storeId;
  }
  public String getStoreName() {
    return storeName;
  }
  public void setStoreName(String storeName) {
    this.storeName = storeName;
  }
  public Integer getStaffCnt() {
    return staffCnt;
  }
  public void setStaffCnt(Integer staffCnt) {
    this.staffCnt = staffCnt;
  }
  
}
