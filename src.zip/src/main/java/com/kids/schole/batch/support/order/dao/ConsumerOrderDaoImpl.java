package com.kids.schole.batch.support.order.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

@Repository
public class ConsumerOrderDaoImpl implements ConsumerOrderDao {
  
  @Autowired
  private SqlSession sqlSession;
  
  @Override
  public List<CardPaymentRequest> selectConsumerOrderApprovalList() {
    return sqlSession.selectList("consumerOrder.selectConsumerOrderApprovalList");
  }

  @Override
  public void updateConsumerOrderPayDoneAmt(Order order) {
    sqlSession.update("consumerOrder.updateConsumerOrderPayDoneAmt", order);
  }

  @Override
  public void updateConsumerOrderStatusDone(Order order) {
    sqlSession.update("consumerOrder.updateConsumerOrderStatusDone", order);
  }

  @Override
  public CardPaymentRequest selectConsumerCardPaymentRequestPurchase(int cardPaymentRequestId) {
    return sqlSession.selectOne("consumerOrder.selectConsumerCardPaymentRequestPurchase", cardPaymentRequestId);
  }

  @Override
  public List<CardPaymentRequest> selectSingleCopyOrderApprovalList() {
    return sqlSession.selectList("consumerOrder.selectSingleCopyOrderApprovalList");
  }

  @Override
  public CardPaymentRequest selectSingleCopyCardPaymentRequestPurchase(int cardPaymentRequestId) {
    return sqlSession.selectOne("consumerOrder.selectSingleCopyCardPaymentRequestPurchase", cardPaymentRequestId);
  }

  @Override
  public void updateSingleCopyPaymentAmt(SingleCopyOrder singleCopyOrder) {
    sqlSession.update("consumerOrder.updateSingleCopyPaymentAmt", singleCopyOrder);
  }
  
  @Override
  public void updateSingleCopyOrderStatus(SingleCopyOrder singleCopyOrder) {
    sqlSession.update("consumerOrder.updateSingleCopyOrderStatus", singleCopyOrder);
  }
  
  @Override
  public void updateSingleCopyOrderStatusDone(SingleCopyOrder singleCopyOrder) {
    sqlSession.update("consumerOrder.updateSingleCopyOrderStatusDone", singleCopyOrder);
  }

}
