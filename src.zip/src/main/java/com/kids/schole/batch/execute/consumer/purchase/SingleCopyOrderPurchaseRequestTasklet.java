package com.kids.schole.batch.execute.consumer.purchase;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;
import com.kids.schole.batch.support.order.service.ConsumerOrderService;

@Component
public class SingleCopyOrderPurchaseRequestTasklet implements Tasklet {

  @Autowired
  private ConsumerOrderService consumerOrderService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<CardPaymentRequest> cardPaymentRequestList =
        (List<CardPaymentRequest>) chunkContext.getStepContext().getStepExecution()
            .getJobExecution().getExecutionContext().get("cardPaymentRequestList");

    List<Integer> tempCardPaymentRequestIdList = new ArrayList<Integer>();
    for (CardPaymentRequest cardPaymentRequest : cardPaymentRequestList) {
      tempCardPaymentRequestIdList.add(cardPaymentRequest.getCardPaymentRequestId());
    }
    
    List<Integer> cardPaymentRequestIdList = new ArrayList<Integer>(new HashSet<Integer>(tempCardPaymentRequestIdList));
    
    List<SingleCopyOrder> orderList = new ArrayList<SingleCopyOrder>();
    
    for(int cardPaymentRequestId : cardPaymentRequestIdList) {
      CardPaymentRequest tempCardPaymentRequest = 
          consumerOrderService.getSingleCopyCardPaymentRequestPurchase(cardPaymentRequestId);
      
      if(tempCardPaymentRequest != null) {
        SingleCopyOrder singleCopyOrder = new SingleCopyOrder();
        singleCopyOrder.setSingleCopyOrderId(tempCardPaymentRequest.getSingleCopyOrderId());
        singleCopyOrder.setSingleCopyPaymentAmt(tempCardPaymentRequest.getAuthAmt());
        orderList.add(singleCopyOrder);
      }
    }
    
    for(SingleCopyOrder singleCopyOrder : orderList) {
      consumerOrderService.modifySingleCopyPaymentAmt(singleCopyOrder);
    }

    return RepeatStatus.FINISHED;

  }

}
