package com.kids.schole.batch.execute.delivery.accept;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.service.OrderService;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.OrderConst;

@Component
public class OrderAcceptTasklet implements Tasklet {

  @Autowired
  private OrderService orderService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<DeliveryRequest> deliveryRequestList =
        (List<DeliveryRequest>) chunkContext.getStepContext().getStepExecution().getJobExecution()
            .getExecutionContext().get("deliveryRequestList");

    for (DeliveryRequest deliveryRequest : deliveryRequestList) {
      Order order = new Order();
      order.setOrderId(deliveryRequest.getOrderId());
      if(deliveryRequest.getDeliveryRequestStatus().equals(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_ACCEPTED)) {
        order.setOrderStatus(OrderConst.ORDER_STATUS_SCM_ACCEPTED);
      } else {
        order.setOrderStatus(OrderConst.ORDER_STATUS_ACCEPTED);
      }
      order.setLastUpdatedEmpNumber(99999);
      orderService.modifyOrderStatus(order);
    }
    
    return RepeatStatus.FINISHED;

  }

}
