package com.kids.schole.batch.support.cbbk.domain;

/**
 * Cbbk는 가상계좌 도메인 클래스입니다.
 * 
 * @version 1.0 2016.11.14
 * @author Jeongwon Son
 */
public class Cbbk {
	
	private int cbbkId;
	private String bankAccount;
	private String bankCode;
	private String bankName;
	private Boolean isUsed;
	private int registeredEmpNumber;
	private String registeredDatetime;
	
	// 고객별 가상계좌 조회 필요한 값
	private int customerId;
	private String customerNumber;
	private String name;
	private String mobileNumber;
	
	private int orderId;
	private String orderNumber;
	
	private String useBeginDate;
	private String useEndDate;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getUseBeginDate() {
		return useBeginDate;
	}
	public void setUseBeginDate(String useBeginDate) {
		this.useBeginDate = useBeginDate;
	}
	public String getUseEndDate() {
		return useEndDate;
	}
	public void setUseEndDate(String useEndDate) {
		this.useEndDate = useEndDate;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getCbbkId() {
		return cbbkId;
	}
	public void setCbbkId(int cbbkId) {
		this.cbbkId = cbbkId;
	}
	public String getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Boolean getIsUsed() {
		return isUsed;
	}
	public void setIsUsed(Boolean isUsed) {
		this.isUsed = isUsed;
	}
	public int getRegisteredEmpNumber() {
		return registeredEmpNumber;
	}
	public void setRegisteredEmpNumber(int registeredEmpNumber) {
		this.registeredEmpNumber = registeredEmpNumber;
	}
	public String getRegisteredDatetime() {
		return registeredDatetime;
	}
	public void setRegisteredDatetime(String registeredDatetime) {
		this.registeredDatetime = registeredDatetime;
	}
	
	
	

}
