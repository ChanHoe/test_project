package com.kids.schole.batch.support.card.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.card.dao.CardDao;
import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.card.domain.PgTransactionLog;

@Service
public class CardServiceImpl implements CardService {

  @Autowired
  private CardDao cardDao;
  
  @Override
  public PgTransactionLog getLastPgTransactionLog(int cardPaymentRequestId) {
    return cardDao.selectLastPgTransactionLog(cardPaymentRequestId);
  }
  
  @Override
  public void createPgTransactionLog(PgTransactionLog pgTransactionLog) {
    cardDao.insertPgTransactionLog(pgTransactionLog);
  }

  @Override
  public void modifyCardPaymentRequestStatus(CardPaymentRequest cardPaymentRequest) {
    cardDao.updateCardPaymentRequestStatus(cardPaymentRequest);
  }

}
