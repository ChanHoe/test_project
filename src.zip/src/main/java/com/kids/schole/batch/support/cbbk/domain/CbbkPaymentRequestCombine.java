package com.kids.schole.batch.support.cbbk.domain;


/**
 * CbbkPaymentRequest는 가상계좌 결제 요청 도메인 클래스입니다.
 * 
 * @version 1.0 2016.12.14
 * @author Jeongwon Son
 */
public class CbbkPaymentRequestCombine {

  private String orderId;
  private String customerId;
  private String paymentId;
  private String cbbkPaymentRequestId;
  private String bankCode;
  private String bankName;
  private String bankAccount;
  private long paymentAmt;
  private long depositAmt;
  private String requestStatus;

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public String getCustomerId() {
    return customerId;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public String getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(String paymentId) {
    this.paymentId = paymentId;
  }

  public String getCbbkPaymentRequestId() {
    return cbbkPaymentRequestId;
  }

  public void setCbbkPaymentRequestId(String cbbkPaymentRequestId) {
    this.cbbkPaymentRequestId = cbbkPaymentRequestId;
  }

  public String getBankCode() {
    return bankCode;
  }

  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public String getBankAccount() {
    return bankAccount;
  }

  public void setBankAccount(String bankAccount) {
    this.bankAccount = bankAccount;
  }

  public long getPaymentAmt() {
    return paymentAmt;
  }

  public void setPaymentAmt(long paymentAmt) {
    this.paymentAmt = paymentAmt;
  }

  public long getDepositAmt() {
    return depositAmt;
  }

  public void setDepositAmt(long depositAmt) {
    this.depositAmt = depositAmt;
  }

  public String getRequestStatus() {
    return requestStatus;
  }

  public void setRequestStatus(String requestStatus) {
    this.requestStatus = requestStatus;
  }

}
