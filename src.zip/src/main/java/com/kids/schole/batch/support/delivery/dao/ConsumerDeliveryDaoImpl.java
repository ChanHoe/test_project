package com.kids.schole.batch.support.delivery.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

@Repository
public class ConsumerDeliveryDaoImpl implements ConsumerDeliveryDao {
  
  @Autowired
  private SqlSession sqlSession;
  
  @Override
  public void updateConsumerDeliveryRequestStatusWait(DeliveryRequest deliveryRequest) {
    sqlSession.update("consumerDelivery.updateConsumerDeliveryRequestStatusWait", deliveryRequest);
  }

  @Override
  public List<Order> selectConsumerDeliveryStatusWaitList() {
    return sqlSession.selectList("consumerDelivery.selectConsumerDeliveryStatusWaitList");
  }

  @Override
  public void updateConsumerDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest) {
    sqlSession.update("consumerDelivery.updateConsumerDeliveryRequestStatusScmAccept", deliveryRequest);
  }

  @Override
  public List<DeliveryRequest> selectConsumerDeliveryStatusScmDeliveryList() {
    return sqlSession.selectList("consumerDelivery.selectConsumerDeliveryStatusScmDeliveryList");
  }

  @Override
  public void updateConsumerDeliveryRequestStatus(DeliveryRequest deliveryRequest) {
    sqlSession.update("consumerDelivery.updateConsumerDeliveryRequestStatus", deliveryRequest);
  }

  @Override
  public int selectConsumerDeliveryStatusNotScmShippedCount(int orderId) {
    return sqlSession.selectOne("consumerDelivery.selectConsumerDeliveryStatusNotScmShippedCount", orderId);
  }

  @Override
  public void updateSingleCopyDeliveryStatusWait(SingleCopyDelivery singleCopyDelivery) {
    sqlSession.update("consumerDelivery.updateSingleCopyDeliveryStatusWait", singleCopyDelivery);
  }

  @Override
  public List<SingleCopyOrder> selectSingleCopyDeliveryStatusWaitList() {
    return sqlSession.selectList("consumerDelivery.selectSingleCopyDeliveryStatusWaitList");
  }

  @Override
  public void updateSingleCopyDeliveryStatusScmAccept(SingleCopyDelivery singleCopyDelivery) {
    sqlSession.update("consumerDelivery.updateSingleCopyDeliveryStatusScmAccept", singleCopyDelivery);
  }

  @Override
  public List<SingleCopyDelivery> selectSingleCopyDeliveryStatusScmDeliveryList() {
    return sqlSession.selectList("consumerDelivery.selectSingleCopyDeliveryStatusScmDeliveryList");
  }

  @Override
  public void updateSingleCopyDeliveryStatus(SingleCopyDelivery singleCopyDelivery) {
    sqlSession.update("consumerDelivery.updateSingleCopyDeliveryStatus", singleCopyDelivery);
  }

  @Override
  public int selectSingleCopyDeliveryStatusNotScmShippedCount(int singleCopyOrderId) {
    return sqlSession.selectOne("consumerDelivery.selectSingleCopyDeliveryStatusNotScmShippedCount", singleCopyOrderId);
  }
  
}
