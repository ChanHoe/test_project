package com.kids.schole.batch.execute.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.log.service.LogService;

@Component
public class BatchLogRemoveTasklet implements Tasklet {

  private Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private LogService logService;
  
  @Override
  public RepeatStatus execute(StepContribution arg0, ChunkContext arg1) throws Exception {
    
    logService.removeBatchLogWithinTwoWeeks();
    
    return RepeatStatus.FINISHED;
  }

}
