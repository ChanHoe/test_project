package com.kids.schole.batch.support.cbbk.domain;

/**
 * CbbkCombine는 가상계좌 결제 통합 도메인 클래스입니다.
 * 
 * @version 1.0 2016.12.14
 * @author Jeongwon Son
 */
public class CbbkCombine {
	
	private int cbbkCombineId;
	private int cbbkPaymentRequestId;	// 가상계좌 대체 결제 ID
	private String bankAccount;		// 가상 은행 계좌
	private boolean isAllotComplete;	//	할당완료여부
	private String combineStatus;	// 통합상태
	private String lastSmsSendDatetime;	// 최종sms발송일자
	private int registeredEmpNumber;
	private String registeredDatetime;
	
	// 통합상태 건 조회할때
	private int customerId;
	private int cbbkId;
	private String requestStatus;

	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getCbbkId() {
		return cbbkId;
	}
	public void setCbbkId(int cbbkId) {
		this.cbbkId = cbbkId;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getCombineStatus() {
		return combineStatus;
	}
	public void setCombineStatus(String combineStatus) {
		this.combineStatus = combineStatus;
	}
	public String getLastSmsSendDatetime() {
		return lastSmsSendDatetime;
	}
	public void setLastSmsSendDatetime(String lastSmsSendDatetime) {
		this.lastSmsSendDatetime = lastSmsSendDatetime;
	}
	public void setAllotComplete(boolean isAllotComplete) {
		this.isAllotComplete = isAllotComplete;
	}
	public int getCbbkCombineId() {
		return cbbkCombineId;
	}
	public void setCbbkCombineId(int cbbkCombineId) {
		this.cbbkCombineId = cbbkCombineId;
	}
	public String getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	public int getRegisteredEmpNumber() {
		return registeredEmpNumber;
	}
	public void setRegisteredEmpNumber(int registeredEmpNumber) {
		this.registeredEmpNumber = registeredEmpNumber;
	}
	public String getRegisteredDatetime() {
		return registeredDatetime;
	}
	public void setRegisteredDatetime(String registeredDatetime) {
		this.registeredDatetime = registeredDatetime;
	}
	public int getCbbkPaymentRequestId() {
		return cbbkPaymentRequestId;
	}
	public void setCbbkPaymentRequestId(int cbbkPaymentRequestId) {
		this.cbbkPaymentRequestId = cbbkPaymentRequestId;
	}
	public boolean isAllotComplete() {
		return isAllotComplete;
	}
	public void setIsAllotComplete(boolean isAllotComplete) {
		this.isAllotComplete = isAllotComplete;
	}

	
}
