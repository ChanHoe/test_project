package com.kids.schole.batch.support.customer.domain;

public class CsAllotMapping {

  private Integer csConsultationId;     // CS상담 ID
  private String postCode;              // 우편번호
  private Integer organizationId;       // 조직 ID
  private String organizationName;       // 조직명
  private Integer registeredEmpNumber;  // 등록사원번호
  private String registeredDatetime;    // 등록일시

  private String name;       		// 고객명
  private String empName;      		// 담당자
  private String mobileNumber;      // 담당핸드폰
  
  public Integer getCsConsultationId() {
    return csConsultationId;
  }
  public void setCsConsultationId(Integer csConsultationId) {
    this.csConsultationId = csConsultationId;
  }
  public String getPostCode() {
    return postCode;
  }
  public void setPostCode(String postCode) {
    this.postCode = postCode;
  }
  public Integer getOrganizationId() {
    return organizationId;
  }
  public void setOrganizationId(Integer organizationId) {
    this.organizationId = organizationId;
  }
  public String getOrganizationName() {
	return organizationName;
  }
  public void setOrganizationName(String organizationName) {
	this.organizationName = organizationName;
  }
  public Integer getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(Integer registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public String getName() {
	return name;
  }

  public void setName(String name) {
	this.name = name;
  }
  
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	  
}
