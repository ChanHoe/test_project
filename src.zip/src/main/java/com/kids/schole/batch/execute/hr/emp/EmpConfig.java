package com.kids.schole.batch.execute.hr.emp;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * 임직원 데이터에 대한 처리를 담당하는 클래스입니다.
 *
 * @version 1.0 2017. 2. 3.
 * @author Eunsung Ju
 */
@Configuration
@EnableBatchProcessing
public class EmpConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private EmpTasklet positionCodeModifyTasklet;

  // 매일 00시 02분 00초 실행
  @Scheduled(cron="0 2 0 * * ?")
  public String runEmp() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(positionCodeModifyJob(), param);

    return execution.getStatus().toString();
  }

  @Bean
  public Job positionCodeModifyJob() {

    return jobBuilderFactory
            .get("positionCodeModifyJob")
            .incrementer(new RunIdIncrementer())
            .listener(listener())
            .start(positionCodeModifyStep())
            .build();
  }

  @Bean
  public Step positionCodeModifyStep() {

    return stepBuilderFactory
            .get("positionCodeModifyStep")
            .tasklet(positionCodeModifyTasklet)
            .build();
  }

  @Bean
  public JobExecutionListener listener() {

    return new JobCompletionNotificationListener();
  }
}
