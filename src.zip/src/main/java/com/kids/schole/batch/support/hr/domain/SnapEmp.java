package com.kids.schole.batch.support.hr.domain;

/**
 * SnapEmp 테이블과 매핑하기 위한 도메인 클래스입니다.
 *
 * @version 1.0 2017. 02. 02
 * @author Jeongwon Son
 */
public class SnapEmp {
  
  private int empNumber;
  private String empKey;
  private String empName;
  private String empStatus;
  private String empPassword;
  private int profileImageId;
  private String empRrn;
  private String mainJobTitle;
  private String empPostcode;
  private String empAddress;
  private String empAddressDetail;
  private String phoneNumber;
  private String mobileNumber;
  private String emailAddress;
  private String finalEducation;
  private int isMarried;
  private String marriedDate;
  private String positionCode;
  private String joinedDate;
  private int recruiter;
  private String recruitChannel;
  private String requiredDocuments;
  private int isSuburb;
  private String workBeginDate;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;
  private String lastLoginDatetime;
  
  // 판매년도, 판매월
  private String saleYear;
  private String saleMonth;
  
  public int getEmpNumber() {
    return empNumber;
  }
  public void setEmpNumber(int empNumber) {
    this.empNumber = empNumber;
  }
  public String getEmpKey() {
    return empKey;
  }
  public void setEmpKey(String empKey) {
    this.empKey = empKey;
  }
  public String getEmpName() {
    return empName;
  }
  public void setEmpName(String empName) {
    this.empName = empName;
  }
  public String getEmpStatus() {
    return empStatus;
  }
  public void setEmpStatus(String empStatus) {
    this.empStatus = empStatus;
  }
  public String getEmpPassword() {
    return empPassword;
  }
  public void setEmpPassword(String empPassword) {
    this.empPassword = empPassword;
  }
  public int getProfileImageId() {
    return profileImageId;
  }
  public void setProfileImageId(int profileImageId) {
    this.profileImageId = profileImageId;
  }
  public String getEmpRrn() {
    return empRrn;
  }
  public void setEmpRrn(String empRrn) {
    this.empRrn = empRrn;
  }
  public String getMainJobTitle() {
    return mainJobTitle;
  }
  public void setMainJobTitle(String mainJobTitle) {
    this.mainJobTitle = mainJobTitle;
  }
  public String getEmpPostcode() {
    return empPostcode;
  }
  public void setEmpPostcode(String empPostcode) {
    this.empPostcode = empPostcode;
  }
  public String getEmpAddress() {
    return empAddress;
  }
  public void setEmpAddress(String empAddress) {
    this.empAddress = empAddress;
  }
  public String getEmpAddressDetail() {
    return empAddressDetail;
  }
  public void setEmpAddressDetail(String empAddressDetail) {
    this.empAddressDetail = empAddressDetail;
  }
  public String getPhoneNumber() {
    return phoneNumber;
  }
  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }
  public String getMobileNumber() {
    return mobileNumber;
  }
  public void setMobileNumber(String mobileNumber) {
    this.mobileNumber = mobileNumber;
  }
  public String getEmailAddress() {
    return emailAddress;
  }
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }
  public String getFinalEducation() {
    return finalEducation;
  }
  public void setFinalEducation(String finalEducation) {
    this.finalEducation = finalEducation;
  }
  public int getIsMarried() {
    return isMarried;
  }
  public void setIsMarried(int isMarried) {
    this.isMarried = isMarried;
  }
  public String getMarriedDate() {
    return marriedDate;
  }
  public void setMarriedDate(String marriedDate) {
    this.marriedDate = marriedDate;
  }
  public String getPositionCode() {
    return positionCode;
  }
  public void setPositionCode(String positionCode) {
    this.positionCode = positionCode;
  }
  public String getJoinedDate() {
    return joinedDate;
  }
  public void setJoinedDate(String joinedDate) {
    this.joinedDate = joinedDate;
  }
  public int getRecruiter() {
    return recruiter;
  }
  public void setRecruiter(int recruiter) {
    this.recruiter = recruiter;
  }
  public String getRecruitChannel() {
    return recruitChannel;
  }
  public void setRecruitChannel(String recruitChannel) {
    this.recruitChannel = recruitChannel;
  }
  public String getRequiredDocuments() {
    return requiredDocuments;
  }
  public void setRequiredDocuments(String requiredDocuments) {
    this.requiredDocuments = requiredDocuments;
  }
  public int getIsSuburb() {
    return isSuburb;
  }
  public void setIsSuburb(int isSuburb) {
    this.isSuburb = isSuburb;
  }
  public String getWorkBeginDate() {
    return workBeginDate;
  }
  public void setWorkBeginDate(String workBeginDate) {
    this.workBeginDate = workBeginDate;
  }
  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public String getLastLoginDatetime() {
    return lastLoginDatetime;
  }
  public void setLastLoginDatetime(String lastLoginDatetime) {
    this.lastLoginDatetime = lastLoginDatetime;
  }
  public String getSaleYear() {
    return saleYear;
  }
  public void setSaleYear(String saleYear) {
    this.saleYear = saleYear;
  }
  public String getSaleMonth() {
    return saleMonth;
  }
  public void setSaleMonth(String saleMonth) {
    this.saleMonth = saleMonth;
  }

}
