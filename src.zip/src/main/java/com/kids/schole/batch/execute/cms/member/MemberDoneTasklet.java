package com.kids.schole.batch.execute.cms.member;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.service.MemberService;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.common.cms.BaseAction;
import com.kids.schole.common.cms.XcJavaSocket;
import com.kids.schole.common.cms.util.UtilMethod;
import com.kids.schole.common.constant.PaymentConst;
import com.kids.schole.common.properties.PgCmsProperties;
import com.kids.schole.common.util.BusinessDayUtil;

@Component
public class MemberDoneTasklet implements Tasklet {

  @Autowired
  private BatchCmsCommonTelegram memberCommonTelegram;

  @Autowired
  private PgCmsProperties pgCmsProperties;

  @Autowired
  private MemberService memberService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 회원결과 조회를 할 데이터가 있을때만 전문을 실행한다.
    // 회원신청결과는 영업일 기준 -1일부터 조회가 된다.
    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    nowDate = BusinessDayUtil.getBusinessDayCalc(nowDate, -1);
    InstallmentPaymentRequest installmentPaymentRequest = new InstallmentPaymentRequest();
    installmentPaymentRequest.setApplicationDate(nowDate);

    List<Member> memberList = memberService.getMemberProcessingList(installmentPaymentRequest);

    if (memberList.size() > 0) {

      BaseAction conn = new XcJavaSocket();
      conn.connect(pgCmsProperties.getDomain(), pgCmsProperties.getBatchMemberApplyPort());

      // 1. 업무 개시 시작전문 송신
      conn.sendData(memberCommonTelegram.getBatchCmsStartTelegram("MEM", "R", nowDate));

      System.out.println(
          "회원신청결과 시작전문 송신 : " + memberCommonTelegram.getBatchCmsStartTelegram("MEM", "R", nowDate));

      String startResult = new String(conn.recvData(), "euc-kr");

      System.out.println("회원신청결과 시작전문 수신 : " + startResult);

      // 업무 개시 승인이 나면 처리를 한다.
      if (startResult.charAt(243) == 'Y') {

        int totalCount = 0;
        int failCount = 0;

        List<InstallmentPaymentRequest> installmentPaymentRequestList =
            new ArrayList<InstallmentPaymentRequest>();

        while (true) {

          String tgr = new String(conn.recvData(), "euc-kr");

          if (tgr.substring(0, 1).equals("D")) {
            System.out.println("회원신청결과 오류수신 : " + tgr);
            String tempCustomerId = tgr.substring(12, 32).trim();
            String resultMessage = UtilMethod.subString(tgr, 187, 30);

            InstallmentPaymentRequest tempInstallmentPaymentRequest =
                new InstallmentPaymentRequest();
            int installmentPaymentRequestId = Integer.parseInt(tempCustomerId);
            tempInstallmentPaymentRequest
                .setInstallmentPaymentRequestId(installmentPaymentRequestId);
            tempInstallmentPaymentRequest.setApplicationStatus(
                PaymentConst.INSTALLMENT_PAYMENT_REQUEST_APPLICATION_STATUS_FAIL);
            tempInstallmentPaymentRequest.setApplicationResponseMessage(resultMessage);

            installmentPaymentRequestList.add(tempInstallmentPaymentRequest);

          } else if (tgr.substring(0, 1).equals("H")) {
            System.out.println("회원신청결과 Header 수신 : " + tgr);
            totalCount = Integer.parseInt(tgr.substring(9, 15).trim());
            continue;
          } else if (tgr.substring(0, 1).charAt(0) == 'T') {
            System.out.println("회원신청결과 Tail 수신 : " + tgr);
            break;
          }

          failCount++;
        }

        System.out.println("총 건수 : " + totalCount);
        System.out.println("실패 건수 : " + failCount);

        /**
         * 종료전문수신
         */
        String resultTgl = new String(conn.recvData(), "euc-kr");
        System.out.println("회원신청결과 종료전문 수신 : " + resultTgl);
        conn.close();

        // 기존 신청상태가 진행중인걸 모두 성공 처리 한 뒤 나머지 오류건을 수정한다.
         memberService.modifyAllProcessingListDone(installmentPaymentRequest);

        for (InstallmentPaymentRequest tempInstallmentPaymentRequest : installmentPaymentRequestList) {
           memberService.modifyApplicationStatusFail(tempInstallmentPaymentRequest);
        }

      } else {
        // 업무 개시 승인이 나지 않았을때.
        System.out.println("error");
        conn.close();
      }

    } else {
      System.out.println("진행중인 데이터가 없음.");
    }

    return RepeatStatus.FINISHED;

  }

}
