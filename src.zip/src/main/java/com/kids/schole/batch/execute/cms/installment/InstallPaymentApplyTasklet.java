package com.kids.schole.batch.execute.cms.installment;

import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.execute.cms.member.BatchCmsCommonTelegram;
import com.kids.schole.batch.support.cms.installment.service.InstallmentService;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.common.cms.BaseAction;
import com.kids.schole.common.cms.XcJavaSocket;
import com.kids.schole.common.cms.util.UtilMethod;
import com.kids.schole.common.properties.PgCmsProperties;
import com.kids.schole.common.util.BusinessDayUtil;

@Component
public class InstallPaymentApplyTasklet implements Tasklet {

  @Autowired
  private BatchCmsCommonTelegram memberCommonTelegram;

  @Autowired
  private PgCmsProperties pgCmsProperties;

  @Autowired
  private InstallmentService installmentService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    InstallmentPayment installmentPayment = new InstallmentPayment();
    installmentPayment.setPaymentDueDate(nowDate);

    List<InstallmentPayment> installmentPaymentList =
        installmentService.getInstallmentPaymentStatusWaitList(installmentPayment);

    if (installmentPaymentList.size() > 0) {

      BaseAction conn = new XcJavaSocket();
      conn.connect(pgCmsProperties.getDomain(), pgCmsProperties.getBatchPaymentApplyPort());

      // 현재 nowDate는 신청일 (출금일 기준: 영업일 -1일)
      // 실제 출금일은 nowDate 영업일+1일로 설정한다.
      String withdrawDay = BusinessDayUtil.getBusinessDayCalc(nowDate.replaceAll("-", ""), 1);

      // 1. 업무 개시 시작전문 송신
      conn.sendData(memberCommonTelegram.getBatchCmsStartTelegram("PAY", "A", withdrawDay));
      System.out.println("출금신청 시작전문 송신 : "
          + memberCommonTelegram.getBatchCmsStartTelegram("PAY", "A", withdrawDay));

      byte[] b = null;
      b = conn.recvData();

      String startResult = new String(b, "euc-kr");

      System.out.println("출금신청 시작전문 수신 : " + startResult);

      // 업무 개시 승인이 나면 처리를 한다.
      if (startResult.charAt(243) == 'Y') {

        List<InstallmentPayment> installmentPaymentFailList = new ArrayList<InstallmentPayment>();

        long applyTotalAmt = 0;

        for (InstallmentPayment tempInstallmentPayment : installmentPaymentList) {
          applyTotalAmt += tempInstallmentPayment.getInstallmentPaymentAmt();
        }

        // 2. 신청 데이터 (Header, Data, Tail) 전문으로 3번을 송신을 한다.
        // 2.1 출금신청 Header 전문을 발송한다.
        conn.sendData(memberCommonTelegram
            .getInstallmentApplyHeaderTelegram(installmentPaymentList.size(), applyTotalAmt));
        System.out.println("출금신청 Header 송신 : " + memberCommonTelegram
            .getInstallmentApplyHeaderTelegram(installmentPaymentList.size(), applyTotalAmt));

        // 2.2 출금신청 Data 전문을 발송한다.
        int index = 1;
        for (InstallmentPayment tempInstallmentPayment : installmentPaymentList) {
          String installmentApplyDataTelegram =
              getMemberApplyDataTelegram(tempInstallmentPayment, index++);
          byte[] euckrStringBuffer =
              installmentApplyDataTelegram.getBytes(Charset.forName("euc-kr"));
          String decodedFromEucKr = new String(euckrStringBuffer, "euc-kr");
          System.out.println("출금신청 Data 송신 : " + decodedFromEucKr);
          conn.sendData(decodedFromEucKr);
        }

        // 2.3 출금신청 Tail 전문을 발송한다.
        conn.sendData(
            getInstallmentApplyTailTelegram(installmentPaymentList.size(), applyTotalAmt));
        System.out.println("출금신청 Tail 송신 : "
            + getInstallmentApplyTailTelegram(installmentPaymentList.size(), applyTotalAmt));

        // 3. 신청 데이터에 대한 결과 처리를 한다.
        int dataCnt = installmentPaymentList.size();

        if (dataCnt == 1) {

          String tgl = new String(conn.recvData(), "euc-kr");
          System.out.println("출금신청 Header 수신 : " + tgl);
          b = conn.recvData();
          String resultTelegram = new String(b, "euc-kr");

          // 성공
          if (resultTelegram.substring(0, 1).equals("T")) {
            System.out.println("출금신청 Tail 수신 : " + resultTelegram);
          }

          // 실패
          if (resultTelegram.substring(0, 1).equals("D")) {
            System.out.println("출금신청 Data 오류 수신 : " + resultTelegram);

            InstallmentPayment failInstallmentPayment = new InstallmentPayment();
            String tempCustomerId = resultTelegram.substring(12, 32).trim();
            String resultMessage = UtilMethod.subString(resultTelegram, 248, 30).trim();
            String tempInstallmentPaymentOrder = UtilMethod.subString(resultTelegram, 58, 6).trim();

            int installmentPaymentRequestId = Integer.parseInt(tempCustomerId);
            int installmentPaymentOrder = Integer.parseInt(tempInstallmentPaymentOrder);

            failInstallmentPayment.setInstallmentPaymentRequestId(installmentPaymentRequestId);
            failInstallmentPayment.setInstallmentPaymentOrder(installmentPaymentOrder);
            failInstallmentPayment.setPaymentDueDate(nowDate);
            failInstallmentPayment.setFailedPaymentReason(resultMessage);
            installmentPaymentFailList.add(failInstallmentPayment);

            b = conn.recvData();
            tgl = new String(b, "euc-kr");
            System.out.println("출금신청 Tail 수신 : " + tgl);
          }

        } else {

          while (dataCnt > 0) {
            dataCnt--;
            String tgl = new String(conn.recvData(), "euc-kr");

            if (tgl.substring(0, 1).equals("T")) {
              System.out.println("출금신청 Tail 수신 : " + tgl);
              break;
            } else {
              if (tgl.substring(0, 1).equals("D")) {
                System.out.println("출금신청 Data 오류 수신 : " + tgl);

                InstallmentPayment failInstallmentPayment = new InstallmentPayment();
                String tempCustomerId = tgl.substring(12, 32).trim();
                String resultMessage = UtilMethod.subString(tgl, 248, 30).trim();
                String tempInstallmentPaymentOrder = UtilMethod.subString(tgl, 58, 6).trim();

                int installmentPaymentRequestId = Integer.parseInt(tempCustomerId);
                int installmentPaymentOrder = Integer.parseInt(tempInstallmentPaymentOrder);

                failInstallmentPayment.setInstallmentPaymentRequestId(installmentPaymentRequestId);
                failInstallmentPayment.setInstallmentPaymentOrder(installmentPaymentOrder);
                failInstallmentPayment.setPaymentDueDate(nowDate);
                failInstallmentPayment.setFailedPaymentReason(resultMessage);
                installmentPaymentFailList.add(failInstallmentPayment);

                dataCnt++;
              } else {
                System.out.println("출금신청 Header 수신 : " + tgl);
              }
            }
          }

        }

        // 4. 종료전문 수신.
        b = conn.recvData();
        String resultTgl = new String(b, "euc-kr");
        conn.close();
        System.out.println("출금신청 종료전문 수신 : " + resultTgl);

        // 전문이 틀린데이터만 리턴으로 돌려주므로 기존값을 전부 대기로 업데이트 시키고
        // 오류난거만 다시 실패로 업데이트를 한다.
         installmentService.modifyInstallmentPaymentStatusProcessing(nowDate);

        for (InstallmentPayment installmentPaymentFail : installmentPaymentFailList) {
          installmentService.modifyInstallmentPaymentStatusFail(installmentPaymentFail);
        }

      } else {
        // 업무 개시 승인이 나지 않았을때.
        System.out.println("error");
        conn.close();
      }

    } else {
      System.out.println("신청할 데이터가 없음.");
    }

    return RepeatStatus.FINISHED;

  }

  private String getMemberApplyDataTelegram(InstallmentPayment installmentPayment, int index) {

    StringBuffer sb = new StringBuffer();

    sb.append("D");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append("N");
    sb.append(
        StringUtils.rightPad(installmentPayment.getInstallmentPaymentRequestId() + "", 20, " "));
    sb.append(UtilMethod.subString(installmentPayment.getPayerName(), 0, 20));
    sb.append(StringUtils.leftPad(index + "", 6, "0"));
    sb.append(StringUtils.rightPad(installmentPayment.getInstallmentPaymentOrder() + "", 6, " "));
    sb.append(StringUtils.rightPad(installmentPayment.getInstallmentPaymentAmt() + "", 10, " "));

    sb.append(StringUtils.rightPad("", 20, " "));
    sb.append(StringUtils.rightPad("", 2, " "));
    sb.append(StringUtils.rightPad("", 8, " "));
    sb.append(StringUtils.rightPad("", 12, " "));
    sb.append(StringUtils.rightPad("", 6, " "));
    sb.append(StringUtils.rightPad("", 8, " "));
    sb.append(StringUtils.rightPad("", 113, " "));
    sb.append(StringUtils.rightPad("", 1, " "));
    sb.append(StringUtils.rightPad("", 4, " "));
    sb.append(StringUtils.rightPad("", 30, " "));
    sb.append(StringUtils.rightPad("", 20, " "));
    sb.append("\r\n");

    return sb.toString();

  }

  private String getInstallmentApplyTailTelegram(int applyCount, long applyTotalAmt) {

    StringBuffer sb = new StringBuffer();

    sb.append("T");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append(StringUtils.rightPad(applyCount + "", 6, " "));
    sb.append(StringUtils.rightPad(applyTotalAmt + "", 15, " "));
    sb.append(StringUtils.rightPad("", 266, " "));
    sb.append("\r\n");

    return sb.toString();

  }

}
