package com.kids.schole.batch.execute.order.purchase;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.OrderPayment;
import com.kids.schole.batch.support.order.service.OrderService;
import com.kids.schole.common.constant.OrderConst;

@Component
public class OrderPaymentPurchaseRequestTasklet implements Tasklet {

  @Autowired
  private OrderService orderService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<CardPaymentRequest> cardPaymentRequestList =
        (List<CardPaymentRequest>) chunkContext.getStepContext().getStepExecution()
            .getJobExecution().getExecutionContext().get("cardPaymentRequestList");

    // 주문정보 ID가 여러개 중복되어 있어서 중복제거를 한다.
    List<Integer> tempOrderIdList = new ArrayList<Integer>();
    for (CardPaymentRequest cardPaymentRequest : cardPaymentRequestList) {
      tempOrderIdList.add(cardPaymentRequest.getOrderId());
    }
    List<Integer> orderIdList = new ArrayList<Integer>(new HashSet<Integer>(tempOrderIdList));

    for (int orderId : orderIdList) {
      // 1. 신용카드는 매입성공에 상관 없이 무조건 결제완료이다.(실패건은 미수금으로 관리함)
      OrderPayment orderPayment = new OrderPayment();
      orderPayment.setOrderId(orderId);
      orderPayment.setPayStatus(OrderConst.PAY_STATUS_DONE);
      orderPayment.setLastUpdatedEmpNumber(99999);
      orderService.modifyOrderPaymentPayStatus(orderPayment);
    }

    return RepeatStatus.FINISHED;
    
  }

}
