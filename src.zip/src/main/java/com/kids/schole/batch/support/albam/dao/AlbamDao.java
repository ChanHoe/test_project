package com.kids.schole.batch.support.albam.dao;

import java.util.List;

import com.kids.schole.batch.support.albam.domain.DailyMeetingInfo;
import com.kids.schole.batch.support.albam.domain.VwSalesEmpInfo;

public interface AlbamDao {

  public List<VwSalesEmpInfo> selectVwSalesEmpInfoList(VwSalesEmpInfo vwSalesEmpInfo);
  
  public int selectDuplicateDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo);
  
  public void insertDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo);
  
  public void updateDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo);
  
}
