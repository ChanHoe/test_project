package com.kids.schole.batch.support.delivery.dao;

import java.util.List;

import com.kids.schole.batch.support.delivery.domain.ChannelSales;
import com.kids.schole.batch.support.delivery.domain.ChannelSalesDeliveryRequest;

/**
 * 채널주문의 배송 dao
 *
 * @author 최인혜
 */
public interface ChannelSalesDeliveryDao {

  /** 배송대기 상태의 채널주문을 조회 */
  List<ChannelSales> selectDeliveryStatusWaitList(String businessDay);

  /** 채널주문의 배송상태를 변경 */
  void updateChannelSalesDeliveryRequestStatusScmAccept(ChannelSalesDeliveryRequest deliveryRequest);
}
