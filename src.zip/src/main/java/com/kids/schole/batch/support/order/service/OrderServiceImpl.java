package com.kids.schole.batch.support.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.dao.OrderDao;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.OrderPayment;

@Service
public class OrderServiceImpl implements OrderService {

  @Autowired
  private OrderDao orderDao;

  @Override
  public List<CardPaymentRequest> getOrderApprovalList() {
    return orderDao.selectOrderApprovalList();
  }

  @Override
  public void modifyOrderPaymentPayStatus(OrderPayment orderPayment) {
    orderDao.updateOrderPaymentPayStatus(orderPayment);
  }

  @Override
  public void modifyOrderPayDoneAmt(Order order) {
    orderDao.updateOrderPayDoneAmt(order);
  }

  @Override
  public void modifyOrderStatus(Order order) {
    orderDao.updateOrderStatus(order);
  }

  @Override
  public void modifyOrderStatusDone(Order order) {
    orderDao.updateOrderStatusDone(order);
  }

  @Override
  public void modifyInstallmentPaymentRequestStatus(
      InstallmentPaymentRequest installmentPaymentRequest) {
    orderDao.updateInstallmentPaymentRequestStatus(installmentPaymentRequest);
  }

  @Override
  public void modifyInstallmentPaymentStatus(InstallmentPayment installmentPayment) {
    orderDao.updateInstallmentPaymentStatus(installmentPayment);
  }

  @Override
  public Order getOrder(int orderId) {
    return orderDao.selectOrder(orderId);
  }

  @Override
  public void modifyOrderAttachedFileProofStatusFailToWait() {
    orderDao.updateOrderAttachedFileProofStatusFailToWait();
  }

}
