package com.kids.schole.batch.support.product.service;

public interface ProductService {

  void modifyProductStatus();

}
