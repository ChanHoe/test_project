package com.kids.schole.batch.support.albam.domain;

public class Rolls {

  private Integer rollsId;
  private Integer userId;
  private String staffName;
  private String customValue;
  private String convertedStartTime;
  private String convertedEndTime;
 
  private String convertedStartTimeE;
  private String convertedEndTimeE;
  
  public Integer getRollsId() {
    return rollsId;
  }
  public void setRollsId(Integer rollsId) {
    this.rollsId = rollsId;
  }
  public Integer getUserId() {
    return userId;
  }
  public void setUserId(Integer userId) {
    this.userId = userId;
  }
  public String getStaffName() {
    return staffName;
  }
  public void setStaffName(String staffName) {
    this.staffName = staffName;
  }
  public String getCustomValue() {
    return customValue;
  }
  public void setCustomValue(String customValue) {
    this.customValue = customValue;
  }
  public String getConvertedStartTime() {
    return convertedStartTime;
  }
  public void setConvertedStartTime(String convertedStartTime) {
    this.convertedStartTime = convertedStartTime;
  }
  public String getConvertedEndTime() {
    return convertedEndTime;
  }
  public void setConvertedEndTime(String convertedEndTime) {
    this.convertedEndTime = convertedEndTime;
  }
  public String getConvertedStartTimeE() {
	return convertedStartTimeE;
  }
  public void setConvertedStartTimeE(String convertedStartTimeE) {
	this.convertedStartTimeE = convertedStartTimeE;
  }
  public String getConvertedEndTimeE() {
	return convertedEndTimeE;
  }
  public void setConvertedEndTimeE(String convertedEndTimeE) {
	this.convertedEndTimeE = convertedEndTimeE;
  }
  
}
