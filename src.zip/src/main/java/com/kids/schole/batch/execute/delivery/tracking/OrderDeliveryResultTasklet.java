package com.kids.schole.batch.execute.delivery.tracking;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberAllStepData;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResponseStatus;
import com.kids.schole.batch.support.delivery.domain.TrackingNumberTraceResult;
import com.kids.schole.batch.support.delivery.service.DeliveryService;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.service.OrderService;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.OrderConst;

@Component
public class OrderDeliveryResultTasklet implements Tasklet {

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private OrderService orderService;

  @Autowired
  private DeliveryService deliveryService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<DeliveryRequest> deliveryRequestList =
        (List<DeliveryRequest>) chunkContext.getStepContext().getStepExecution().getJobExecution()
            .getExecutionContext().get("deliveryRequestList");

    for (DeliveryRequest deliveryRequest : deliveryRequestList) {

      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus =
          deliveryRequest.getTrackingNumberTraceResponseStatus();

      TrackingNumberTraceResult trackingNumberTraceResult =
          deliveryRequest.getTrackingNumberTraceResponseStatus().getTrackingNumberTraceResult();

      // 결과값이 정상이면
      if (trackingNumberTraceResponseStatus.getResultCode().equals("0000")) {
        Order order = new Order();
        order.setOrderId(deliveryRequest.getOrderId());
        order.setDeliveryDoneDate(
            trackingNumberTraceResponseStatus.getTrackingNumberTraceResult().getLastStepTime());
        order.setSalesDoneDate(
            trackingNumberTraceResponseStatus.getTrackingNumberTraceResult().getLastStepTime());
        order.setLastUpdatedEmpNumber(99999);

        if (trackingNumberTraceResult.getLastStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
          order.setOrderStatus(OrderConst.ORDER_STATUS_DONE);
          // 모든 물류가 배송완료가 되었으면 주문 완료가 된다.
          if (deliveryService
              .getDeliveryStatusNotScmShippedCount(deliveryRequest.getOrderId()) == 0) {
            orderService.modifyOrderStatusDone(order);
          }

        } else if (trackingNumberTraceResult.getLastStepText()
            .equals(DeliveryConst.CJ_DELIVERY_REJECT)) {

          // 미배달인경우 모든 배달과정을 찾아서 배달완료인지를 체크를 한다.
          List<TrackingNumberAllStepData> trackingNumberAllStepDataList =
              trackingNumberTraceResult.getTrackingNumberAllStepDataList();

          boolean isShipped = false;

          for (TrackingNumberAllStepData trackingNumberAllStepData : trackingNumberAllStepDataList) {
            if (trackingNumberAllStepData.getStepText().equals(DeliveryConst.CJ_DELIVERY_SHIPPED)) {
              isShipped = true;
              order.setDeliveryDoneDate(trackingNumberAllStepData.getStepTime());
              order.setSalesDoneDate(trackingNumberAllStepData.getStepTime());
              order.setOrderStatus(OrderConst.ORDER_STATUS_DONE);
              break;
            }
          }

          // 배달완료가 있고 미배달 사유가 아래와 같으면 주문완료로 처리를 한다.
          if (isShipped == true && (trackingNumberTraceResult.getLastStepNote().equals("지연도착")
              || trackingNumberTraceResult.getLastStepNote().equals("도서/외곽지역")
              || trackingNumberTraceResult.getLastStepNote().equals("토요휴무"))) {
            if (deliveryService
                .getDeliveryStatusNotScmShippedCount(deliveryRequest.getOrderId()) == 0) {
              orderService.modifyOrderStatusDone(order);
            }

          }

        }
      }

    }

    return RepeatStatus.FINISHED;

  }

}
