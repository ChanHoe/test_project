package com.kids.schole.batch.execute.channel.delivery.accept;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.delivery.domain.ChannelSales;
import com.kids.schole.batch.support.delivery.domain.ChannelSalesDeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.WarehouseResponseStatus;
import com.kids.schole.batch.support.delivery.service.ChannelSalesDeliveryService;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.WarehouseConst;
import com.kids.schole.common.properties.WarehouseProperties;
import com.kids.schole.common.util.DomainUtil;
import com.kids.schole.common.util.ScmBusinessDayUtil;
import com.kids.schole.common.util.StringUtil;
import com.kids.schole.common.util.WarehouseUtil;

@Component
public class ChannelSalesScmAcceptTasklet implements Tasklet {

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private ChannelSalesDeliveryService channelOrderDeliveryService;

  @Autowired
  private WarehouseProperties warehouseProperties;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

    if (logger.isDebugEnabled()) logger.debug("채널주문의 배송시작");

    String businessDay = ScmBusinessDayUtil.getBusinessDayTodayCalc(1);
    List<ChannelSalesDeliveryRequest> deliveryRequestList = new ArrayList<ChannelSalesDeliveryRequest>();

    // 현재 배송 대기중인 주문 리스트를 가져온다.
    List<ChannelSales> channelSalesList = channelOrderDeliveryService.getDeliveryStatusWaitList(businessDay);

    for (ChannelSales channelSales : channelSalesList) {

      String[] tempMobileNumber = channelSales.getCustomerMobileNumber().split("-");

      String prefixPhoneNumber = null;
      String infixPhoneNumber = null;
      String suffixPhoneNumber = null;

      // 현재 시간 설정
      LocalDateTime now = LocalDateTime.now();
      DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

      Map<String, String> warehouseMap = new TreeMap<String, String>();
      // 필수 값
      warehouseMap.put("contents_id", channelSales.getWarehouseContentsKey());
      warehouseMap.put("biz_code", warehouseProperties.getBizCode());
      warehouseMap.put("biz_order_number", "B"+channelSales.getChannelSalesId());
      warehouseMap.put("biz_delivery_record_id", "B"+channelSales.getChannelSalesDeliveryRequestId());
      warehouseMap.put("sender_name", warehouseProperties.getSenderName());
      warehouseMap.put("sender_tel", warehouseProperties.getSenderTel());
      warehouseMap.put("sender_addr", warehouseProperties.getSenderAddr());
      warehouseMap.put("customer_user_id", "D9999"); //채널주문의 배송 고객아이디를 통일한다.(고객을 등록하지 않으므로)
      warehouseMap.put("customer_name", channelSales.getCustomerName());
      if (tempMobileNumber.length == 3) {
        warehouseMap.put("customer_phone1", tempMobileNumber[0]);
        warehouseMap.put("customer_phone2", tempMobileNumber[1]);
        warehouseMap.put("customer_phone3", tempMobileNumber[2]);
      } 
      else if (tempMobileNumber.length < 3) {

        String mobileNumber = StringUtil.replace(channelSales.getCustomerMobileNumber(), "-", "");
        if (StringUtil.length(mobileNumber) == 11) {
          warehouseMap.put("customer_phone1", mobileNumber.substring(0, 3));
          warehouseMap.put("customer_phone2", mobileNumber.substring(3, 7));
          warehouseMap.put("customer_phone3", mobileNumber.substring(7));
        } else if (StringUtil.length(mobileNumber) == 10) {
          warehouseMap.put("customer_phone1", mobileNumber.substring(0, 3));
          warehouseMap.put("customer_phone2", mobileNumber.substring(3, 6));
          warehouseMap.put("customer_phone3", mobileNumber.substring(6));
        }
      }
      warehouseMap.put("customer_postcode", channelSales.getDeliveryPostcode());
      warehouseMap.put("customer_addr1", channelSales.getDeliveryAddress());

      // 선택 값
      warehouseMap.put("customer_tel1", StringUtils.defaultString(prefixPhoneNumber));
      warehouseMap.put("customer_tel2", StringUtils.defaultString(infixPhoneNumber));
      warehouseMap.put("customer_tel3", StringUtils.defaultString(suffixPhoneNumber));
      warehouseMap.put("customer_addr2", StringUtils.defaultString(channelSales.getDeliveryAddressDetail()));
      warehouseMap.put("biz_contents_id", "");
      warehouseMap.put("customer_memo", StringUtils.defaultString(channelSales.getDeliveryMessage()));
      warehouseMap.put("payment_time", now.format(dateTimeFormatter));
      warehouseMap.put("delivery_contents_divide_yn", "N");
      warehouseMap.put("record_sub_type", "");
      warehouseMap.put("cs_reason", "");
      warehouseMap.put("cs_admin_id", "");
      warehouseMap.put("cs_admin_name", "");

      warehouseMap = WarehouseUtil.setTimeStampNFingerPrint(warehouseMap);

      String url = warehouseProperties.getUrl() + WarehouseConst.DELIVERY_INSERT_URL;

      // Http Header 세팅
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

      HttpEntity<Map<String, String>> warehouseMapEntity =
          new HttpEntity<Map<String, String>>(warehouseMap, headers);

      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<String> responseEntity =
          restTemplate.postForEntity(url, warehouseMapEntity, String.class);

      Gson gson = new GsonBuilder()
          .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

      WarehouseResponseStatus warehouseResponseStatus =
          gson.fromJson(responseEntity.getBody(), WarehouseResponseStatus.class);

       DomainUtil.retriveDomain(warehouseResponseStatus);

      ChannelSalesDeliveryRequest deliveryRequest = new ChannelSalesDeliveryRequest();

      if ("0000".equals(warehouseResponseStatus.getResultCode())) {
        deliveryRequest.setChannelSalesDeliveryRequestId(channelSales.getChannelSalesDeliveryRequestId());
        deliveryRequest.setChannelSalesId(channelSales.getChannelSalesId());
        deliveryRequest.setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_ACCEPTED);
        deliveryRequest.setWarehouseCompleteKey(warehouseResponseStatus.getWarehouseResult().getCustomerRecordId());
        deliveryRequest.setLastUpdatedEmpNumber(99999);
      } else {

        System.out.println("deliveryRequestId : " + channelSales.getChannelSalesDeliveryRequestId());
        System.out.println("ResultCode: " + warehouseResponseStatus.getResultCode() + " - "
            + warehouseResponseStatus.getResultMsg());

        deliveryRequest.setChannelSalesDeliveryRequestId(channelSales.getChannelSalesDeliveryRequestId());
        deliveryRequest.setChannelSalesId(channelSales.getChannelSalesId());
        deliveryRequest.setDeliveryRequestStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_WAIT);
        deliveryRequest.setWarehouseCompleteKey("");
        deliveryRequest.setLastUpdatedEmpNumber(99999);
      }

      deliveryRequestList.add(deliveryRequest);

    }

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("channelOrderDeliveryRequestList", deliveryRequestList);

    return RepeatStatus.FINISHED;

  }

}
