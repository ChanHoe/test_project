package com.kids.schole.batch.support.cms.installment.dao;

import java.util.List;

import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;

public interface InstallmentDao {

  List<InstallmentPayment> selectInstallmentPaymentStatusWaitList(
      InstallmentPayment installmentPayment);

  void updateInstallmentPaymentStatusProcessing(String nowDate);

  void updateInstallmentPaymentStatusFail(InstallmentPayment installmentPayment);

  void updateInstallmentPaymentRequestStatus(InstallmentPaymentRequest installmentPaymentRequest);

  List<InstallmentPayment> selectInstallmentPaymentProcessingList(
      InstallmentPayment installmentPayment);

  void updateAllProcessingListDone(InstallmentPayment installmentPayment);

  void updateOrderPayDoneAmt(String paymentDueDate);
  
  void updateConsumerOrderPayDoneAmt(String paymentDueDate);

  void updateInstallmentPaymentRequestCheckStatus();

}
