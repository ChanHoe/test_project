package com.kids.schole.batch.execute.cashreceipt.result;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * 현금영수증 결과조회 배치
 *
 * @author 최인혜
 */
@Configuration
@EnableBatchProcessing
public class CashReceiptResultConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private ReadyCashReceiptResultTasklet readyCashReceiptResultTasklet;

  @Autowired
  private ResultCashReceiptTasklet resultCashReceiptTasklet;

  @Autowired
  private ResultCashReceiptApplyTasklet resultCashReceiptApplyTasklet;

  // 하루두번 : 새벽1시30분, 오후4시30분
  @Scheduled(cron = "0 30 1,16 * * ?")
  public String runResultCashReceipt() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(resultCashReceiptBatchJob(), param);

    return execution.getStatus().toString();
  }

  @Bean
  public Job resultCashReceiptBatchJob() {

    return jobBuilderFactory
        .get("resultCashReceiptBatchJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(readyCashReceiptResultStep())
        .next(resultCashReceiptStep())
        .next(resultCashReceiptApplyStep())
        .build();
  }

  @Bean
  public Step readyCashReceiptResultStep() {
    return stepBuilderFactory
        .get("readyCashReceiptResultStep")
        .tasklet(readyCashReceiptResultTasklet)
        .build();
  }

  @Bean
  public Step resultCashReceiptStep() {
    return stepBuilderFactory
        .get("resultCashReceiptStep")
        .tasklet(resultCashReceiptTasklet)
        .build();
  }
  @Bean
  public Step resultCashReceiptApplyStep() {
    return stepBuilderFactory
        .get("resultCashReceiptApplyStep")
        .tasklet(resultCashReceiptApplyTasklet)
        .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}
