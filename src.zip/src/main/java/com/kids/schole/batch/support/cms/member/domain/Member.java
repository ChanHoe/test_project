package com.kids.schole.batch.support.cms.member.domain;

public class Member {

  private int customerId;
  private String name;
  private int installmentPaymentRequestId;
  private String applicationType;
  private String applicationStatus;
  private String payDay;
  private long installmentPaymentAmt;
  private String payCode;
  private String payInfo;
  private String payerName;
  private String payerBirthDate;

  public int getCustomerId() {
    return customerId;
  }

  public void setCustomerId(int customerId) {
    this.customerId = customerId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getInstallmentPaymentRequestId() {
    return installmentPaymentRequestId;
  }

  public void setInstallmentPaymentRequestId(int installmentPaymentRequestId) {
    this.installmentPaymentRequestId = installmentPaymentRequestId;
  }

  public String getApplicationType() {
    return applicationType;
  }

  public void setApplicationType(String applicationType) {
    this.applicationType = applicationType;
  }

  public String getApplicationStatus() {
    return applicationStatus;
  }

  public void setApplicationStatus(String applicationStatus) {
    this.applicationStatus = applicationStatus;
  }

  public String getPayDay() {
    return payDay;
  }

  public void setPayDay(String payDay) {
    this.payDay = payDay;
  }

  public long getInstallmentPaymentAmt() {
    return installmentPaymentAmt;
  }

  public void setInstallmentPaymentAmt(long installmentPaymentAmt) {
    this.installmentPaymentAmt = installmentPaymentAmt;
  }

  public String getPayCode() {
    return payCode;
  }

  public void setPayCode(String payCode) {
    this.payCode = payCode;
  }

  public String getPayInfo() {
    return payInfo;
  }

  public void setPayInfo(String payInfo) {
    this.payInfo = payInfo;
  }

  public String getPayerName() {
    return payerName;
  }

  public void setPayerName(String payerName) {
    this.payerName = payerName;
  }

  public String getPayerBirthDate() {
    return payerBirthDate;
  }

  public void setPayerBirthDate(String payerBirthDate) {
    this.payerBirthDate = payerBirthDate;
  }

}
