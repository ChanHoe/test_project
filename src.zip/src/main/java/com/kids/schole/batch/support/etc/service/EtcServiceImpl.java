package com.kids.schole.batch.support.etc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.etc.dao.EtcDao;
import com.kids.schole.batch.support.etc.domain.SpecialHoliday;

@Service
public class EtcServiceImpl implements EtcService {

  @Autowired
  private EtcDao etcDao;

  @Override
  @Cacheable(value = "specialHoliday")
  public List<SpecialHoliday> getCacheSpecialHolidayList() {
    return etcDao.selectCacheSpecialHolidayList();
  }

}
