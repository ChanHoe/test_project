package com.kids.schole.batch.execute.albam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.albam.domain.AuthenticateResponse;
import com.kids.schole.common.constant.AlbamConst;
import com.kids.schole.common.properties.AlbamProperties;
import com.kids.schole.common.util.DomainUtil;

@Component
public class AlbamAuthenticateTasklet implements Tasklet{
  
  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private AlbamProperties albamProperties;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

    MultiValueMap<String, String> authMap = new LinkedMultiValueMap<String, String>(); 
    authMap.add("key", albamProperties.getKey());
    authMap.add("secret", albamProperties.getSecret());
    
    String url = albamProperties.getUrl() + AlbamConst.ALBAM_AUTHENTICATE_URL;
    
    // Http Header 세팅
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    
    HttpEntity<MultiValueMap<String, String>> authMapEntity =
        new HttpEntity<MultiValueMap<String, String>>(authMap, headers);
    
    RestTemplate restTemplate = new RestTemplate();
    ResponseEntity<String> responseEntity =
        restTemplate.postForEntity(url, authMapEntity, String.class);
    
    Gson gson = new GsonBuilder()
        .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
    
    AuthenticateResponse authenticateResponse =
        gson.fromJson(responseEntity.getBody(), AuthenticateResponse.class);
    
    DomainUtil.retriveDomain(authenticateResponse);
    
    logger.debug("accessToken 확인 {}" , authenticateResponse.getAuthenticateResult().getAccessToken());
    
    return RepeatStatus.FINISHED;
  }
  
}
