package com.kids.schole.batch.execute.consumer.autoAllot;

/**
 * ConsumerAutoAllotConfig는 소비자 처리건 주문금액과 가상계좌 입금금액이 일치하면 자동배분을 해주는 클래스입니다. 
 * 
 * @version 1.0 2017.03.23
 * @author chheo
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;
import com.kids.schole.batch.execute.cbbk.autoAllot.CbbkPaymentRequestDoneTasklet;

@Configuration
@EnableBatchProcessing
public class ConsumerAutoAllotConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private ConsumerOrderStatusCbbkReadyTasklet consumerOrderStatusCbbkReadyTasklet;
  
  @Autowired
  private CbbkPaymentRequestDoneTasklet cbbkPaymentRequestDoneTasklet;
  
  @Autowired
  private ConsumerOrderStatusCbbkDoneTasklet consumerOrderStatusCbbkDoneTasklet;
  
  @Autowired
  private ConsumerCbbkDeliveryWaitTasklet consumerCbbkDeliveryWaitTasklet;
  
  // 매 시간 30분마다
  @Scheduled(cron = "0 30 0/1 * * ?")
  public String runConsumerAutoAllot() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(ConsumerAutoAllotJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job ConsumerAutoAllotJob() {
    
    return jobBuilderFactory
        .get("autoAllotJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(consumerOrderStatusCbbkReadyStep())
        .next(cbbkPaymentRequestDoneStep())
        .next(consumerOrderStatusCbbkDoneStep())
        .next(consumerCbbkDeliveryWaitStep())
        .build();
  }
  
  // 소비자 처리건 가상계좌 입금대기 조회
  @Bean
  public Step consumerOrderStatusCbbkReadyStep() {

    return stepBuilderFactory
        .get("consumerOrderStatusCbbkReadyStep")
        .tasklet(consumerOrderStatusCbbkReadyTasklet)
        .build();
  }
  
  // 자동분배
  @Bean
  public Step cbbkPaymentRequestDoneStep() {
    
    return stepBuilderFactory
        .get("cbbkPaymentRequestDoneStep")
        .tasklet(cbbkPaymentRequestDoneTasklet)
        .build();
  }
  
  // 주문 수정
  @Bean
  public Step consumerOrderStatusCbbkDoneStep() {
    
    return stepBuilderFactory
        .get("consumerOrderStatusCbbkDoneStep")
        .tasklet(consumerOrderStatusCbbkDoneTasklet)
        .build();
  }
  
  // 배송 요청 상태를 대기로 변경
  @Bean
  public Step consumerCbbkDeliveryWaitStep() {
    return stepBuilderFactory
        .get("consumerCbbkDeliveryWaitStep")
        .tasklet(consumerCbbkDeliveryWaitTasklet)
        .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}