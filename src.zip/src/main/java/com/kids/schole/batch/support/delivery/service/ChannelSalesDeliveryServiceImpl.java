/**
 *
 */
package com.kids.schole.batch.support.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.delivery.dao.ChannelSalesDeliveryDao;
import com.kids.schole.batch.support.delivery.domain.ChannelSales;
import com.kids.schole.batch.support.delivery.domain.ChannelSalesDeliveryRequest;

@Service
public class ChannelSalesDeliveryServiceImpl implements ChannelSalesDeliveryService {

  @Autowired
  private ChannelSalesDeliveryDao channelOrderDeliveryDao;

  @Override
  public List<ChannelSales> getDeliveryStatusWaitList(String businessDay) {
    //
    return channelOrderDeliveryDao.selectDeliveryStatusWaitList(businessDay);
  }

  @Override
  public void modifyChannelSalesDeliveryRequestStatusScmAccept(ChannelSalesDeliveryRequest deliveryRequest) {
    //
    channelOrderDeliveryDao.updateChannelSalesDeliveryRequestStatusScmAccept(deliveryRequest);
  }

}
