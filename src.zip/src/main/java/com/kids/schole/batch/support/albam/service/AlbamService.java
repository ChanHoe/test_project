package com.kids.schole.batch.support.albam.service;

import java.util.List;

import com.kids.schole.batch.support.albam.domain.DailyMeetingInfo;
import com.kids.schole.batch.support.albam.domain.VwSalesEmpInfo;

public interface AlbamService {
  
  List<VwSalesEmpInfo> getVwSalesEmpInfoList(VwSalesEmpInfo vwSalesEmpInfo);
  
  int getDuplicateDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo);
  
  void createDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo);

  void modifyDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo);
}
