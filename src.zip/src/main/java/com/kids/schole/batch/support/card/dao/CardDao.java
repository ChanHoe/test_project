package com.kids.schole.batch.support.card.dao;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.card.domain.PgTransactionLog;

public interface CardDao {

  PgTransactionLog selectLastPgTransactionLog(int cardPaymentRequestId);

  void insertPgTransactionLog(PgTransactionLog pgTransactionLog);

  void updateCardPaymentRequestStatus(CardPaymentRequest cardPaymentRequest);


}
