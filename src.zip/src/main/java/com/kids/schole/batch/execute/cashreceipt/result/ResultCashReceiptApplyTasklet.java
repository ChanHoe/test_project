package com.kids.schole.batch.execute.cashreceipt.result;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cashreceipt.issue.domain.CashReceipt;
import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.domain.SingleCopyCashReceipt;
import com.kids.schole.batch.support.cashreceipt.issue.service.PgCashReceiptService;
import com.kids.schole.common.constant.PaymentConst;
import com.kids.schole.common.util.StringUtil;

/**
 *
 * 현금영주승 결과조회(통신)한 것을 요청내역에 하나하나 매핑해준다.
 *
 * @author 최인혜
 */
@Component
public class ResultCashReceiptApplyTasklet implements Tasklet {

  @Autowired
  private PgCashReceiptService pgCashReceiptService;

  @Override
  @SuppressWarnings("unchecked")
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    PgCashReceiptBatchLog cashReceiptBatchLog = (PgCashReceiptBatchLog) chunkContext.getStepContext()
        .getStepExecution().getJobExecution().getExecutionContext().get("cashReceiptBatchLog");

    FileInputStream fileInputStream = new FileInputStream(cashReceiptBatchLog.getFullFileName());
    InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "euc-kr");
    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

    String line = null;
    while ((line = bufferedReader.readLine()) != null) {
       Object result = makeCashReceiptFromFile(line);
       if (result != null) {
         if (result instanceof SingleCopyCashReceipt) {
           // 낱권유상
           pgCashReceiptService.modifySingleCopyCashReceiptResultById((SingleCopyCashReceipt) result);
         }
         else if (result instanceof CashReceipt) {
           // 일반주문
           pgCashReceiptService.modifyCashReceiptResultById((CashReceipt) result);
         }
       }
    }

    return RepeatStatus.FINISHED;
  }

  // 파일에서 읽어온 데이터를 분리하여 CashReceipt로 생성
  private Object makeCashReceiptFromFile(String cashReceiptString) {
    //
    // ex) 20170822143000,310005539,2017082214361145,0,0,20,01012341234,909,0,91,1000,car,전송대기,성공,1,,,
    String[] splitedLine = StringUtil.split(cashReceiptString, ",");
    int dealtype = Integer.parseInt(splitedLine[3]); // 발급요청 : 0, 취소요청 : 1
    int cashReceiptSize = splitedLine.length;

    // 제대로 된 값이 아님.
    if (cashReceiptSize < 15) {
      return null;
    }
    // 취소요청일땐 값이 더옴.
    else if (PaymentConst.CASH_RECEIPT_DEAL_TYPE_CANCEL.equals(dealtype)  && cashReceiptSize < 18) {
      return null;
    }

    String authNumber = splitedLine[1]; // 국세청 발급번호
    String cashReceiptId = splitedLine[2]; // CashReceipt id
    String response = splitedLine[12]; // 처리결과(배치상태)
    String detailResponse = splitedLine[13]; // 응답코드(국세청에서 보내주는 상태)

    if (StringUtil.startsWith(cashReceiptId, "A")) {

      SingleCopyCashReceipt result = new SingleCopyCashReceipt();
      result.setAuthNumber(authNumber);
      if (StringUtil.length(cashReceiptId) < 12) { //잘못된 값인지 체크
        cashReceiptId = StringUtil.substring(cashReceiptId, 1);
        result.setSingleCopyCashReceiptId(Integer.parseInt(cashReceiptId));
      }

      if (PaymentConst.CASH_RECEIPT_SUCCESS.equals(detailResponse)) {
        result.setResponseCode(PaymentConst.CASH_RECEIPT_SUCCESS_CODE);
      }
      result.setResponseMessage(response);
      result.setDetailResponseMessage(detailResponse);

      // 승인성공이면
      if (PaymentConst.CASH_RECEIPT_REQUEST_SUCCESS.equals(response)) {
        result.setRequestStatus(PaymentConst.CASH_RECEIPT_REQUEST_STATUS_SUCCESS);
      } else if (PaymentConst.CASH_RECEIPT_REQUEST_FAIL.equals(response)) {
        result.setRequestStatus(PaymentConst.CASH_RECEIPT_REQUEST_STATUS_FAIL);
      }

      // 현금영수증 발급취소요청일 경우
      if (PaymentConst.CASH_RECEIPT_DEAL_TYPE_CANCEL.equals(dealtype)) {
        String requestDate = splitedLine[16]; // 승인거래 거래일자(취소)
        String cancelReason = splitedLine[17];
        result.setRequestDate(requestDate);
        result.setCancelReasonType(cancelReason);
      }
      return result;
    }
    else if (StringUtil.isNumeric(cashReceiptId)) {
      CashReceipt result = new CashReceipt();
      result.setAuthNumber(authNumber);
      if (StringUtil.length(cashReceiptId) < 12) {
        result.setCashReceiptId(Integer.parseInt(cashReceiptId));
      }

      if (PaymentConst.CASH_RECEIPT_SUCCESS.equals(detailResponse)) {
        result.setResponseCode(PaymentConst.CASH_RECEIPT_SUCCESS_CODE);
      }
      result.setResponseMessage(response);
      result.setDetailResponseMessage(detailResponse);

      // 승인성공이면
      if (PaymentConst.CASH_RECEIPT_REQUEST_SUCCESS.equals(response)) {
        result.setRequestStatus(PaymentConst.CASH_RECEIPT_REQUEST_STATUS_SUCCESS);
      } else if (PaymentConst.CASH_RECEIPT_REQUEST_FAIL.equals(response)) {
        result.setRequestStatus(PaymentConst.CASH_RECEIPT_REQUEST_STATUS_FAIL);
      }

      // 현금영수증 발급취소요청일 경우
      if (PaymentConst.CASH_RECEIPT_DEAL_TYPE_CANCEL.equals(dealtype)) {
//      String originalAuthNumber = splitedLine[15]; // 승인거래 승인번호(취소) == 국세청 발급번호
        String requestDate = splitedLine[16]; // 승인거래 거래일자(취소)
        String cancelReason = splitedLine[17];
        result.setRequestDate(requestDate);
        result.setCancelReasonType(cancelReason);
      }
      return result;
    }
    return null;


  }

}
