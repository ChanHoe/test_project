package com.kids.schole.batch.execute.channel.delivery.accept;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.delivery.domain.ChannelSalesDeliveryRequest;
import com.kids.schole.batch.support.delivery.service.ChannelSalesDeliveryService;

@Component
public class ChannelSalesDeliveryRequestAcceptTasklet implements Tasklet {

  @Autowired
  private ChannelSalesDeliveryService channelOrderDeliveryService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<ChannelSalesDeliveryRequest> channelOrderDeliveryRequestList =
        (List<ChannelSalesDeliveryRequest>) chunkContext.getStepContext().getStepExecution().getJobExecution()
            .getExecutionContext().get("channelOrderDeliveryRequestList");

    for (ChannelSalesDeliveryRequest channelOrderDeliveryRequest : channelOrderDeliveryRequestList) {
      channelOrderDeliveryService.modifyChannelSalesDeliveryRequestStatusScmAccept(channelOrderDeliveryRequest);
    }

    return RepeatStatus.FINISHED;
  }

}
