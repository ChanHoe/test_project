package com.kids.schole.batch.execute.consumer.delivery.tracking;

/**
 * TrackingNumberTraceConfig는 소비자 처리건 배송 중인 주문을 주기적으로 체크를 해서 
 * 주문 결과를 처리하는 클래스입니다.
 * 
 * @version 1.0 2017.03.22
 * @author chheo
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class ConsumerTrackingNumberTraceConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private ConsumerScmDeliveryTasklet consumerScmDeliveryTasklet;
  
  @Autowired
  private ConsumerDeliveryRequestResultTasklet consumerDeliveryRequestResultTasklet;
  
  @Autowired
  private ConsumerOrderDeliveryResultTasklet consumerOrderDeliveryResultTasklet;

  
  // 매 2시간마다 실행한다.
  @Scheduled(cron = "0 0 0/2 * * ?")
 // @Scheduled(cron = "0 0 0/1 * * ?")
  public String runConsumerTrackingNumberTrace() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(consumerTrackingNumberTraceJob(), param);

    return execution.getStatus().toString();

  }

  @Bean
  public Job consumerTrackingNumberTraceJob() {
    
    return jobBuilderFactory
        .get("consumerTrackingNumberTraceJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(consumerScmDeliveryStep())
        //.next(consumerDeliveryRequestResultStep())
        //.next(consumerOrderDeliveryResultStep())
        .build();
  }

  // 배송 중인 리스트를 가져온다.
  @Bean
  public Step consumerScmDeliveryStep() {
    return stepBuilderFactory
        .get("consumerScmDeliveryStep")
        .tasklet(consumerScmDeliveryTasklet)
        .build();
  }
  
  // 배송요청 테이블의 배송상태를 업데이트한다.
  @Bean
  public Step consumerDeliveryRequestResultStep() {
    return stepBuilderFactory
        .get("consumerDeliveryRequestResultStep")
        .tasklet(consumerDeliveryRequestResultTasklet)
        .build();
  }
  
  // 주문 테이블의 주문상태를 업데이트한다.
  @Bean
  public Step consumerOrderDeliveryResultStep() {
    return stepBuilderFactory
        .get("consumerOrderDeliveryResultStep")
        .tasklet(consumerOrderDeliveryResultTasklet)
        .build();
  }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
}
