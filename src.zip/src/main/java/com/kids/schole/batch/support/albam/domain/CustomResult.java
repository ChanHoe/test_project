package com.kids.schole.batch.support.albam.domain;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class CustomResult {
  
  private String accessToken;
  private Integer expiredAt; 
  
  @SerializedName("update")
  private List<CustomUpdate> customUpdateList;

  public String getAccessToken() {
    return accessToken;
  }
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }
  public Integer getExpiredAt() {
    return expiredAt;
  }
  public void setExpiredAt(Integer expiredAt) {
    this.expiredAt = expiredAt;
  }
  public List<CustomUpdate> getCustomUpdateList() {
    return customUpdateList;
  }
  public void setCustomUpdateList(List<CustomUpdate> customUpdateList) {
    this.customUpdateList = customUpdateList;
  }

}
