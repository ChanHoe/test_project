package com.kids.schole.batch.support.delivery.domain;

public class DeliveryRequest {

  private int deliveryRequestId;
  private int orderId;
  private int customerId;
  private String deliveryRequestStatus;
  private int deliveryProcessingOrder;
  private String invoiceNumber;
  private String warehouseContentsKey;
  private String warehouseCompleteKey;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  private TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus;

  public int getDeliveryRequestId() {
    return deliveryRequestId;
  }

  public void setDeliveryRequestId(int deliveryRequestId) {
    this.deliveryRequestId = deliveryRequestId;
  }

  public int getOrderId() {
    return orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public int getCustomerId() {
    return customerId;
  }

  public void setCustomerId(int customerId) {
    this.customerId = customerId;
  }

  public String getDeliveryRequestStatus() {
    return deliveryRequestStatus;
  }

  public void setDeliveryRequestStatus(String deliveryRequestStatus) {
    this.deliveryRequestStatus = deliveryRequestStatus;
  }

  public int getDeliveryProcessingOrder() {
    return deliveryProcessingOrder;
  }

  public void setDeliveryProcessingOrder(int deliveryProcessingOrder) {
    this.deliveryProcessingOrder = deliveryProcessingOrder;
  }

  public String getInvoiceNumber() {
    return invoiceNumber;
  }

  public void setInvoiceNumber(String invoiceNumber) {
    this.invoiceNumber = invoiceNumber;
  }

  public String getWarehouseContentsKey() {
    return warehouseContentsKey;
  }

  public void setWarehouseContentsKey(String warehouseContentsKey) {
    this.warehouseContentsKey = warehouseContentsKey;
  }

  public String getWarehouseCompleteKey() {
    return warehouseCompleteKey;
  }

  public void setWarehouseCompleteKey(String warehouseCompleteKey) {
    this.warehouseCompleteKey = warehouseCompleteKey;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public TrackingNumberTraceResponseStatus getTrackingNumberTraceResponseStatus() {
    return trackingNumberTraceResponseStatus;
  }

  public void setTrackingNumberTraceResponseStatus(
      TrackingNumberTraceResponseStatus trackingNumberTraceResponseStatus) {
    this.trackingNumberTraceResponseStatus = trackingNumberTraceResponseStatus;
  }


}
