package com.kids.schole.batch.execute.cms.member;

import java.io.File;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cms.member.domain.OrderAttachedFile;
import com.kids.schole.batch.support.cms.member.service.MemberService;
import com.kids.schole.common.cms.BaseAction;
import com.kids.schole.common.cms.XcJavaSocket;
import com.kids.schole.common.cms.util.UtilMethod;
import com.kids.schole.common.constant.OrderConst;
import com.kids.schole.common.constant.PaymentGateConst;
import com.kids.schole.common.properties.PgCmsProperties;

@Component
public class MemberProofApplyTasklet implements Tasklet {

  @Autowired
  private PgCmsProperties pgCmsProperties;

  @Autowired
  private MemberService memberService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {


    List<OrderAttachedFile> orderAttachedFileList = memberService.getOrderAttachedFileNewWaitList();

    for (OrderAttachedFile orderAttachedFile : orderAttachedFileList) {

      BaseAction conn = new XcJavaSocket();
      conn.connect(pgCmsProperties.getRealMemberProofIp(),
          pgCmsProperties.getRealMemberProofPort());

      boolean sended = false;
      String contractFileName =
          orderAttachedFile.getAttachedFilePath() + orderAttachedFile.getHashFileName();
      File contractFile = new File(contractFileName);

      String contractFileNameExtension =
          FilenameUtils.getExtension(orderAttachedFile.getHashFileName());

      try {

        byte[] fileBuf = Files.readAllBytes(new File(contractFileName).toPath());

        String memeberProofApplyTelegram =
            memeberProofStartTelegram(PaymentGateConst.PG_REAL_MEMBER_PROOF_APPLY_TELEGRAM_CODE,
                PaymentGateConst.PG_REAL_MEMBER_PROOF_APPLY_PROCESS_CODE,
                orderAttachedFile.getInstallmentPaymentRequestId(), contractFileNameExtension,
                contractFile.length() + "");

        conn.sendData(memeberProofApplyTelegram);
        
        System.out.println("회원증빙 신청 시작전문 송신 : " + memeberProofApplyTelegram);

        byte[] tgr = null;
        tgr = conn.recvData();

        String startResult = new String(tgr, "euc-kr");
        System.out.println("회원증빙 신청 시작전문 수신 : " + startResult);

        if (startResult.substring(90, 91).equals("Y")) {

          // 증빙데이터전문구성
          StringBuffer sb = new StringBuffer();
          sb.append("D");
          sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
          sb.append("B");
          sb.append(StringUtils.rightPad(orderAttachedFile.getInstallmentPaymentRequestId() + "",
              20, " ")); // 회원번호

          String proofApplyDataTelegram = sb.toString();

          String encodeData = new String(Base64.encodeBase64(fileBuf));

          int loopCount = (encodeData.getBytes().length / 60000);
          if ((encodeData.getBytes().length % 60000) > 0) {
            loopCount++;
          }
          
          int start = 0;
          byte[] b_encodeData = encodeData.getBytes();

          for (int j = 0; j < loopCount; j++) {
            String sendData = proofApplyDataTelegram;
            start = j * 60000;

            if (j == loopCount - 1) {
              sendData = sendData + "Y" + "0" + (j + 1) + UtilMethod.fillSpace("", 65);
              int last_size = encodeData.getBytes().length - start;
              sendData += new String(b_encodeData, start, last_size);
              sendData += UtilMethod.fillSpace("", 60000 - last_size);
              sendData += "\r\n";
              sended = conn.sendData(sendData);
            } else {
              sendData = sendData + "N" + "0" + (j + 1) + UtilMethod.fillSpace("", 65);
              sendData += new String(b_encodeData, start, 60000);
              sendData += "\r\n";

              sended = conn.sendData(sendData);
            }
            if (sended) {
              System.out.println("회원증빙 신청 데이터전문 송신 : " + new String(sendData));
            }
          }

          tgr = conn.recvData();

          String tgl = new String(tgr, "euc-kr");
          System.out.println("회원증빙 신청 종료 전문 수신 : " + tgl);

          // 전문 종료 후 진행 중으로 업데이트 한다.
          orderAttachedFile
              .setApplyDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
          orderAttachedFile.setProofStatus(OrderConst.PROOF_STATUS_PROCESSING);
          orderAttachedFile.setFailedProofReason("");
          memberService.modifyMemberProofStatus(orderAttachedFile);

        } else {

          orderAttachedFile
              .setApplyDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
          orderAttachedFile.setProofStatus(OrderConst.PROOF_STATUS_FAIL);
          orderAttachedFile.setFailedProofReason(UtilMethod.subString(startResult, 95, 30));
          memberService.modifyMemberProofStatus(orderAttachedFile);
        
        }

      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        System.out.println("종료");
        conn.close();
      }

    }

    return RepeatStatus.FINISHED;
  }

  // 회원 증빙 시작전문
  private String memeberProofStartTelegram(String telegramType, String workType,
      int installmentPaymentRequestId, String fileExetension, String fileLength) {

    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));

    StringBuffer sb = new StringBuffer();

    sb.append("S");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyPassword(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getSwId(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getSwPassword(), 10, " "));
    sb.append(nowDate);
    sb.append(telegramType);
    sb.append(workType);
    sb.append("B");
    sb.append(StringUtils.rightPad(installmentPaymentRequestId + "", 20, " ")); // 회원번호
    sb.append("01");
    sb.append(StringUtils.rightPad(fileExetension, 5, " "));
    sb.append(StringUtils.leftPad(fileLength, 6, "0"));
    sb.append(StringUtils.rightPad("", 110, " "));
    sb.append("\r\n");

    return sb.toString();

  }

}
