package com.kids.schole.batch.support.card.service;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.card.domain.PgTransactionLog;

public interface CardService {

  // 마지막으로 PG 전문 통신한 것을 가져온다.
  public PgTransactionLog getLastPgTransactionLog(int cardPaymentRequestId);

  // pg 통신 로그 등록
  public void createPgTransactionLog(PgTransactionLog pgTransactionLog);

  public void modifyCardPaymentRequestStatus(CardPaymentRequest responseCardPaymentRequest);


}
