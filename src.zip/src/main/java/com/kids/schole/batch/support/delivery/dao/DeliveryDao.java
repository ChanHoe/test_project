package com.kids.schole.batch.support.delivery.dao;

import java.util.List;

import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.order.domain.Order;

public interface DeliveryDao {

  void updateDeliveryRequestStatusWait(DeliveryRequest deliveryRequest);

  List<Order> selectDeliveryStatusWaitList(String businessDay);

  void updateDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest);

  List<DeliveryRequest> selectDeliveryStatusScmDeliveryList();

  void updateDeliveryRequestStatus(DeliveryRequest deliveryRequest);

  int selectDeliveryStatusNotScmShippedCount(int orderId);

  List<Order> selectDeliveryStatusWaitListForCard(String businessDay);

}
