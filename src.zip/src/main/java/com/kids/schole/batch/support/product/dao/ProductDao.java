package com.kids.schole.batch.support.product.dao;

public interface ProductDao {

  void updateProductStatus();

}
