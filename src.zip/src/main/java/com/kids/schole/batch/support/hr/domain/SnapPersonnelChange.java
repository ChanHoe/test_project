package com.kids.schole.batch.support.hr.domain;

/**
 * SnapPersonnelChange 테이블과 매핑하기 위한 도메인 클래스입니다.
 *
 * @version 1.0 2017. 02. 02
 * @author Jeongwon Son
 */
public class SnapPersonnelChange {

  private Integer personnelChangeId;
  private Integer empNumber;
  private String workBeginDate;
  private String workEndDate;
  private String personnelChangeType;
  private String affiliationName;
  private Integer affiliationOrganizationId;
  private String positionCode;
  private Integer registeredEmpNumber;
  private String registeredDatetime;
  private Integer lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;
  
  // 판매년도, 판매월
  private String saleYear;
  private String saleMonth;
  
  public Integer getPersonnelChangeId() {
    return personnelChangeId;
  }
  public void setPersonnelChangeId(Integer personnelChangeId) {
    this.personnelChangeId = personnelChangeId;
  }
  public Integer getEmpNumber() {
    return empNumber;
  }
  public void setEmpNumber(Integer empNumber) {
    this.empNumber = empNumber;
  }
  public String getWorkBeginDate() {
    return workBeginDate;
  }
  public void setWorkBeginDate(String workBeginDate) {
    this.workBeginDate = workBeginDate;
  }
  public String getWorkEndDate() {
    return workEndDate;
  }
  public void setWorkEndDate(String workEndDate) {
    this.workEndDate = workEndDate;
  }
  public String getPersonnelChangeType() {
    return personnelChangeType;
  }
  public void setPersonnelChangeType(String personnelChangeType) {
    this.personnelChangeType = personnelChangeType;
  }
  public String getAffiliationName() {
    return affiliationName;
  }
  public void setAffiliationName(String affiliationName) {
    this.affiliationName = affiliationName;
  }
  public Integer getAffiliationOrganizationId() {
    return affiliationOrganizationId;
  }
  public void setAffiliationOrganizationId(Integer affiliationOrganizationId) {
    this.affiliationOrganizationId = affiliationOrganizationId;
  }
  public String getPositionCode() {
    return positionCode;
  }
  public void setPositionCode(String positionCode) {
    this.positionCode = positionCode;
  }
  public Integer getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }
  public void setRegisteredEmpNumber(Integer registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }
  public String getRegisteredDatetime() {
    return registeredDatetime;
  }
  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }
  public Integer getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }
  public void setLastUpdatedEmpNumber(Integer lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }
  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }
  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }
  public String getSaleYear() {
    return saleYear;
  }
  public void setSaleYear(String saleYear) {
    this.saleYear = saleYear;
  }
  public String getSaleMonth() {
    return saleMonth;
  }
  public void setSaleMonth(String saleMonth) {
    this.saleMonth = saleMonth;
  }
  
}
