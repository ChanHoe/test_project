package com.kids.schole.batch.execute.cms.installment;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.common.properties.PgCmsProperties;

@Component
public class InstallmentCommonTelegram {

  @Autowired
  private PgCmsProperties pgCmsProperties;
  
  public String getMemberStartTelegram(String dataType, String workType, String nowDate) {
    
    StringBuffer sb = new StringBuffer();

    sb.append("S");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyPassword(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getSwId(), 10, " "));
    sb.append(StringUtils.rightPad(pgCmsProperties.getSwPassword(), 10, " "));
    sb.append(dataType);
    sb.append(workType);
    sb.append(nowDate.replaceAll("-", ""));
    sb.append(StringUtils.rightPad("", 245, " "));
    sb.append("\r\n");

    return sb.toString();

  }
  
  public String getMemberApplyHeaderTelegram(int customerCount) {

    StringBuffer sb = new StringBuffer();

    sb.append("H");
    sb.append(StringUtils.rightPad(pgCmsProperties.getCompanyId(), 10, " "));
    sb.append(StringUtils.rightPad(customerCount + "", 6, " "));
    sb.append(StringUtils.rightPad("", 281, " "));
    sb.append("\r\n");

    return sb.toString();

  }
  
}
