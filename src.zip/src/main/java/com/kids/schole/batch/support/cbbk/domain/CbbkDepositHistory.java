package com.kids.schole.batch.support.cbbk.domain;

/**
 * CbbkDepositHistory는 가상계좌 입금 내역 도메인 클래스입니다.
 * 
 * @version 1.0 2016.11.14
 * @author Jeongwon Son
 */
public class CbbkDepositHistory {

  private int cbbkDepositHistoryId;
  private String bankAccount;
  private String bankCode;
  private String bankName;
  private String depositDatetime;
  private String depositName;
  private long depositAmt;
  private long totalAllotAmt;
  private String allotStatus;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;
  
  // 세틀뱅크 거래 고유번호
  private String sbKey;

  public int getCbbkDepositHistoryId() {
    return cbbkDepositHistoryId;
  }

  public void setCbbkDepositHistoryId(int cbbkDepositHistoryId) {
    this.cbbkDepositHistoryId = cbbkDepositHistoryId;
  }

  public String getBankAccount() {
    return bankAccount;
  }

  public void setBankAccount(String bankAccount) {
    this.bankAccount = bankAccount;
  }

  public String getBankCode() {
    return bankCode;
  }

  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public String getDepositDatetime() {
    return depositDatetime;
  }

  public void setDepositDatetime(String depositDatetime) {
    this.depositDatetime = depositDatetime;
  }

  public String getDepositName() {
    return depositName;
  }

  public void setDepositName(String depositName) {
    this.depositName = depositName;
  }

  public long getDepositAmt() {
    return depositAmt;
  }

  public void setDepositAmt(long depositAmt) {
    this.depositAmt = depositAmt;
  }

  public long getTotalAllotAmt() {
    return totalAllotAmt;
  }

  public void setTotalAllotAmt(long totalAllotAmt) {
    this.totalAllotAmt = totalAllotAmt;
  }

  public String getAllotStatus() {
    return allotStatus;
  }

  public void setAllotStatus(String allotStatus) {
    this.allotStatus = allotStatus;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public String getSbKey() {
    return sbKey;
  }

  public void setSbKey(String sbKey) {
    this.sbKey = sbKey;
  }
  

}