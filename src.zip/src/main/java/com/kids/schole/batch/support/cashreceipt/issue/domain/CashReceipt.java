package com.kids.schole.batch.support.cashreceipt.issue.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.kids.schole.common.constant.PaymentConst;

/**
 * 현금영수증
 * @author 최인혜
 *
 */
public class CashReceipt {

  /** id */
  private int cashReceiptId;
  /** 현금영수증배치로그ID */
  private int cashReceiptBatchLogId;
  /** 거래구분 (발급요청 : approval(0), 취소요청 : cancel(1)) */
  private String dealType;
  /** 거래자구분 (소비자 소득공제용 : 0, 사업자 지출증빙용 : 1) */
  private String usingType;
  /** 현금영수증 발행 타입 (10 : 주민번호 발급, 20 : 휴대전화번호 발급, 30 : 사업자번호 발급, 40 : 카드번호 발급) */
  private String identifierType;
  /** 현금영수증 발행 키 값 (ex: 주민등록번호) */
  private String identifier;
  /** 고객명 */
  private String customerName;
  /** 현금영수증 공급금액(VAT 제외 금액) */
  private long dealAmt;
  /** 현금영수증 봉사료 */
  private long serviceCharge;
  /** 현금영수증 부가세 */
  private long vat;
  /** 구매 상품명 */
  private String productName;
  /** 결제구분 (cbbk : 가상계좌, cms : CMS 즉시출금, bank : 할부금 CMS 출금) */
  private String payType;
  /** 사업자구분 (1 : 일반, 2 : 간이, 3 : 기타, 4 : 면세, 5 : 법인) */
  private int businessType;
  /** 발행구분 (신규, 누락, 정정, 취소, 오류) */
  private String issueType;
  /** 요청일자 (형식은 YYYY-MM-DD) */
  private String requestDate;
  /** 요청상태(ready, processing, fail, done) */
  private String requestStatus;
  /** 국세청 승인번호 */
  private String authNumber;
  /** 국세청 원거래 승인번호(취소를 위하여) */
  private String originalAuthNumber;
  /** 원거래 승인일자(취소를 위하여) : 원거래 승인번호와 원거래 승인일자를 조합해야 유일하다. */
  private String originalAuthDate;
  /** 취소사유  (취소 거래인 경우 필수 - cancel_deal(1) : 거래취소, cancel_error(2) : 오류발급, cancel_etc(3) : 기타) */
  private String cancelReasonType;
  /** 취소일자 */
  private String cancelDatetime;
  /** 응답코드 */
  private String responseCode;
  /** 응답메시지 */
  private String responseMessage;
  /** 상세 응답코드 */
  private String detailResponseCode;
  /** 상세 응답메시지 */
  private String detailResponseMessage;
  /** 주문ID */
  private int orderId;
  /** 결제ID(대체결제일 경우는 대체결제 아이디) */
  private int paymentId;

  /** 결제종류별ID
   *
   * 가상계좌일 경우 : cbbk_payment_request_id
   * 즉시출금일 경우 : bank_payment_request_id
   * 할부금일 경우 : installment_payment_id
   */
  private int payTypeId;
  /** 생성자 */
  private int registeredEmpNumber;
  /** 생성일시 */
  private String registeredDatetime;
  /** 변경자 */
  private int lastUpdatedEmpNumber;
  /** 변경일시 */
  private String lastUpdatedDatetime;

  // 추가
  private boolean canceledCashReceipt;

//---------------------------------------------------------------

  public CashReceipt() {
    //
    this.dealType = PaymentConst.CASH_RECEIPT_DEAL_TYPE_ISSUE; //초기값.
    this.issueType = PaymentConst.CASH_RECEIPT_ISSUE_TYPE_NEW;
    this.businessType = PaymentConst.CASH_RECEIPT_CORPORATE_TYPE_TAX_FREE; // 면세사업자라서.
    this.registeredEmpNumber = 99999;
    this.serviceCharge = 0;
    this.vat = 0; // 면세사업자라서.
  }

  /** 현금영수증 복사(취소위해서) */
  public static CashReceipt copyCashReceiptForCancel(CashReceipt cashReceipt) {
    //
    CashReceipt result = new CashReceipt();
    result.setDealType(PaymentConst.CASH_RECEIPT_DEAL_TYPE_CANCEL);
    result.setRequestStatus(PaymentConst.CASH_RECEIPT_REQUEST_STATUS_READY);
    result.setUsingType(cashReceipt.getUsingType());
    result.setIdentifierType(cashReceipt.getIdentifierType());
    result.setIdentifier(cashReceipt.getIdentifier());
    result.setCustomerName(cashReceipt.getCustomerName());
    result.setDealAmt(cashReceipt.getDealAmt());
    result.setProductName(cashReceipt.getProductName());
    result.setPayType(cashReceipt.getPayType());
    result.setIssueType(PaymentConst.CASH_RECEIPT_ISSUE_TYPE_CANCEL);
    result.setRequestDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    result.setOriginalAuthNumber(cashReceipt.getAuthNumber());
    result.setOriginalAuthDate(cashReceipt.getRequestDate());
    result.setCancelReasonType(PaymentConst.CASH_RECEIPT_CANCEL_REASON_GENERAL);
    result.setCancelDatetime(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    result.setOrderId(cashReceipt.getOrderId());
    result.setPaymentId(cashReceipt.getPaymentId());
    result.setPayTypeId(cashReceipt.getPayTypeId());

    return result;
  }

  /** 현금영수증 복사(취소건을 금액만 바꿔서 재승인을 위해서) */
  public static CashReceipt copyCashReceiptForReIssue(CashReceipt cashReceipt, long dealAmt) {
    //
    CashReceipt result = new CashReceipt();
    result.setDealType(PaymentConst.CASH_RECEIPT_DEAL_TYPE_ISSUE);
    result.setRequestStatus(PaymentConst.CASH_RECEIPT_REQUEST_STATUS_READY);
    result.setUsingType(cashReceipt.getUsingType());
    result.setIdentifierType(cashReceipt.getIdentifierType());
    result.setIdentifier(cashReceipt.getIdentifier());
    result.setCustomerName(cashReceipt.getCustomerName());
    result.setDealAmt(dealAmt);
    result.setProductName(cashReceipt.getProductName());
    result.setPayType(cashReceipt.getPayType());
    result.setIssueType(PaymentConst.CASH_RECEIPT_ISSUE_TYPE_CORRECTION);
    result.setRequestDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    result.setOrderId(cashReceipt.getOrderId());
    result.setPaymentId(cashReceipt.getPaymentId());
    result.setPayTypeId(cashReceipt.getPayTypeId());

    return result;
  }

  // ---------------------------------------------------------------

  public int getCashReceiptId() {
    return cashReceiptId;
  }

  public void setCashReceiptId(int cashReceiptId) {
    this.cashReceiptId = cashReceiptId;
  }

  public int getCashReceiptBatchLogId() {
    return cashReceiptBatchLogId;
  }

  public void setCashReceiptBatchLogId(int cashReceiptBatchLogId) {
    this.cashReceiptBatchLogId = cashReceiptBatchLogId;
  }

  public String getIdentifier() {
    return identifier;
  }

  public void setIdentifier(String identifier) {
    this.identifier = identifier;
  }

  public String getCustomerName() {
    return customerName;
  }

  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }

  public long getDealAmt() {
    return dealAmt;
  }

  public void setDealAmt(long dealAmt) {
    this.dealAmt = dealAmt;
  }

  public long getServiceCharge() {
    return serviceCharge;
  }

  public void setServiceCharge(long serviceCharge) {
    this.serviceCharge = serviceCharge;
  }

  public long getVat() {
    return vat;
  }

  public void setVat(long vat) {
    this.vat = vat;
  }

  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public String getPayType() {
    return payType;
  }

  public void setPayType(String payType) {
    this.payType = payType;
  }

  public int getBusinessType() {
    return businessType;
  }

  public void setBusinessType(int businessType) {
    this.businessType = businessType;
  }

  public String getIssueType() {
    return issueType;
  }

  public void setIssueType(String issueType) {
    this.issueType = issueType;
  }

  public String getOriginalAuthNumber() {
    return originalAuthNumber;
  }

  public void setOriginalAuthNumber(String originalAuthNumber) {
    this.originalAuthNumber = originalAuthNumber;
  }

  public String getCancelDatetime() {
    return cancelDatetime;
  }

  public void setCancelDatetime(String cancelDatetime) {
    this.cancelDatetime = cancelDatetime;
  }

  public String getResponseCode() {
    return responseCode;
  }

  public void setResponseCode(String responseCode) {
    this.responseCode = responseCode;
  }

  public String getResponseMessage() {
    return responseMessage;
  }

  public void setResponseMessage(String responseMessage) {
    this.responseMessage = responseMessage;
  }

  public String getDetailResponseCode() {
    return detailResponseCode;
  }

  public void setDetailResponseCode(String detailResponseCode) {
    this.detailResponseCode = detailResponseCode;
  }

  public String getDetailResponseMessage() {
    return detailResponseMessage;
  }

  public void setDetailResponseMessage(String detailResponseMessage) {
    this.detailResponseMessage = detailResponseMessage;
  }

  public int getOrderId() {
    return orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public int getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(int paymentId) {
    this.paymentId = paymentId;
  }

  public int getPayTypeId() {
    return payTypeId;
  }

  public void setPayTypeId(int payTypeId) {
    this.payTypeId = payTypeId;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public String getAuthNumber() {
    return authNumber;
  }

  public void setAuthNumber(String authNumber) {
    this.authNumber = authNumber;
  }

  public String getRequestDate() {
    return requestDate;
  }

  public void setRequestDate(String requestDate) {
    this.requestDate = requestDate;
  }

  public String getUsingType() {
    return usingType;
  }

  public void setUsingType(String usingType) {
    this.usingType = usingType;
  }

  public String getIdentifierType() {
    return identifierType;
  }

  public void setIdentifierType(String identifierType) {
    this.identifierType = identifierType;
  }

  public String getDealType() {
    return dealType;
  }

  public void setDealType(String dealType) {
    this.dealType = dealType;
  }

  public String getCancelReasonType() {
    return cancelReasonType;
  }

  public void setCancelReasonType(String cancelReasonType) {
    this.cancelReasonType = cancelReasonType;
  }

  public boolean isCanceledCashReceipt() {
    return canceledCashReceipt;
  }

  public void setCanceledCashReceipt(boolean canceledCashReceipt) {
    this.canceledCashReceipt = canceledCashReceipt;
  }

  public String getRequestStatus() {
    return requestStatus;
  }

  public void setRequestStatus(String requestStatus) {
    this.requestStatus = requestStatus;
  }

  public String getOriginalAuthDate() {
    return originalAuthDate;
  }

  public void setOriginalAuthDate(String originalAuthDate) {
    this.originalAuthDate = originalAuthDate;
  }

}
