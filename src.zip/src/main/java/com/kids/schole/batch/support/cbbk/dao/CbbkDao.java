package com.kids.schole.batch.support.cbbk.dao;

import java.util.List;

import com.kids.schole.batch.support.cbbk.domain.CbbkCombine;
import com.kids.schole.batch.support.cbbk.domain.CbbkDepositHistory;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentAllot;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequest;
import com.kids.schole.batch.support.cbbk.domain.CbbkPaymentRequestCombine;
import com.kids.schole.batch.support.order.domain.Order;

public interface CbbkDao {

  void insertCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory);

  void deleteCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory);

  List<CbbkPaymentRequest> selectCbbkPaymentRequestReadyList();

  CbbkDepositHistory selectCbbkDepositHistory(CbbkDepositHistory cbbkDepositHistory);

  void updateCbbkPaymentRequestStatusDone(CbbkPaymentRequest cbbkPaymentRequest);

  void insertCbbkPaymentAllot(CbbkPaymentAllot cbbkPaymentAllot);

  void updateCbbkDepositHistoryAllotStatus(CbbkDepositHistory cbbkDepositHistory);

  void updateOrderStatusPayDoneAmt(Order order);

  List<CbbkPaymentRequestCombine> selectCbbkPaymentRequestReadyCombineList();

  void updateCbbkCombineIsAllotComplete(CbbkCombine cbbkCombine);

  CbbkPaymentRequest selectCbbkPaymentRequest(CbbkPaymentRequest cbbkPaymentRequest);
  
  List<CbbkPaymentRequest> selectConsumerCbbkPaymentRequestReadyList();

}
