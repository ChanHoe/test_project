package com.kids.schole.batch.support.order.domain;

public class OrderPayment {

  private int paymentId;
  private int orderId;
  private String payType;
  private int isArsAgree;
  private String payStatus;
  private String superOrganizationName;
  private int superOrganizationId;
  private String vdEmpName;
  private int vdEmpNumber;
  private String cdEmpName;
  private int cdEmpNumber;
  private String cdEmpKey;
  private String cdPositionCode;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  // 주문상세
  private String cdPositionCodeName;
  private String vdEmpKey;
  private String paySubAction;
  private int installmentPaymentCount;

  public int getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(int paymentId) {
    this.paymentId = paymentId;
  }

  public int getOrderId() {
    return orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public String getPayType() {
    return payType;
  }

  public void setPayType(String payType) {
    this.payType = payType;
  }

  public int getIsArsAgree() {
    return isArsAgree;
  }

  public void setIsArsAgree(int isArsAgree) {
    this.isArsAgree = isArsAgree;
  }

  public String getPayStatus() {
    return payStatus;
  }

  public void setPayStatus(String payStatus) {
    this.payStatus = payStatus;
  }

  public String getSuperOrganizationName() {
    return superOrganizationName;
  }

  public void setSuperOrganizationName(String superOrganizationName) {
    this.superOrganizationName = superOrganizationName;
  }

  public int getSuperOrganizationId() {
    return superOrganizationId;
  }

  public void setSuperOrganizationId(int superOrganizationId) {
    this.superOrganizationId = superOrganizationId;
  }

  public String getVdEmpName() {
    return vdEmpName;
  }

  public void setVdEmpName(String vdEmpName) {
    this.vdEmpName = vdEmpName;
  }

  public int getVdEmpNumber() {
    return vdEmpNumber;
  }

  public void setVdEmpNumber(int vdEmpNumber) {
    this.vdEmpNumber = vdEmpNumber;
  }

  public String getCdEmpName() {
    return cdEmpName;
  }

  public void setCdEmpName(String cdEmpName) {
    this.cdEmpName = cdEmpName;
  }

  public int getCdEmpNumber() {
    return cdEmpNumber;
  }

  public void setCdEmpNumber(int cdEmpNumber) {
    this.cdEmpNumber = cdEmpNumber;
  }

  public String getCdEmpKey() {
    return cdEmpKey;
  }

  public void setCdEmpKey(String cdEmpKey) {
    this.cdEmpKey = cdEmpKey;
  }

  public String getCdPositionCode() {
    return cdPositionCode;
  }

  public void setCdPositionCode(String cdPositionCode) {
    this.cdPositionCode = cdPositionCode;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public String getCdPositionCodeName() {
    return cdPositionCodeName;
  }

  public void setCdPositionCodeName(String cdPositionCodeName) {
    this.cdPositionCodeName = cdPositionCodeName;
  }

  public String getVdEmpKey() {
    return vdEmpKey;
  }

  public void setVdEmpKey(String vdEmpKey) {
    this.vdEmpKey = vdEmpKey;
  }

  public String getPaySubAction() {
    return paySubAction;
  }

  public void setPaySubAction(String paySubAction) {
    this.paySubAction = paySubAction;
  }

  public int getInstallmentPaymentCount() {
    return installmentPaymentCount;
  }

  public void setInstallmentPaymentCount(int installmentPaymentCount) {
    this.installmentPaymentCount = installmentPaymentCount;
  }

}
