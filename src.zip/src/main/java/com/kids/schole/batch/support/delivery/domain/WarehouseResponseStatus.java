package com.kids.schole.batch.support.delivery.domain;

import com.google.gson.annotations.SerializedName;

public class WarehouseResponseStatus {

  private String status;
  @SerializedName("resultCode")
  private String resultCode;
  @SerializedName("resultMsg")
  private String resultMsg;
  @SerializedName("result")
  private WarehouseResult warehouseResult;

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getResultCode() {
    return resultCode;
  }

  public void setResultCode(String resultCode) {
    this.resultCode = resultCode;
  }

  public String getResultMsg() {
    return resultMsg;
  }

  public void setResultMsg(String resultMsg) {
    this.resultMsg = resultMsg;
  }

  public WarehouseResult getWarehouseResult() {
    return warehouseResult;
  }

  public void setWarehouseResult(WarehouseResult warehouseResult) {
    this.warehouseResult = warehouseResult;
  }

}
