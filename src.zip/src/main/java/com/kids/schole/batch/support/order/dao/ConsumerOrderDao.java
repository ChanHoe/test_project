package com.kids.schole.batch.support.order.dao;

import java.util.List;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

public interface ConsumerOrderDao {
  List<CardPaymentRequest> selectConsumerOrderApprovalList();
  
  void updateConsumerOrderPayDoneAmt(Order order);
  
  void updateConsumerOrderStatusDone(Order order);
  
  CardPaymentRequest selectConsumerCardPaymentRequestPurchase(int cardPaymentRequestId);
  
  List<CardPaymentRequest> selectSingleCopyOrderApprovalList();
  
  CardPaymentRequest selectSingleCopyCardPaymentRequestPurchase(int cardPaymentRequestId);
  
  void updateSingleCopyPaymentAmt(SingleCopyOrder singleCopyOrder);
  
  void updateSingleCopyOrderStatus(SingleCopyOrder singleCopyOrder);
  
  void updateSingleCopyOrderStatusDone(SingleCopyOrder singleCopyOrder);
}
