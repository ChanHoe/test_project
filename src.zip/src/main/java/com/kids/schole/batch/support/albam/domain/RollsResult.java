package com.kids.schole.batch.support.albam.domain;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class RollsResult {

  private String accessToken;
  private Integer expiredAt;
  @SerializedName("rolls")
  private List<Rolls> rollsList;

  public String getAccessToken() {
    return accessToken;
  }
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }
  public Integer getExpiredAt() {
    return expiredAt;
  }
  public void setExpiredAt(Integer expiredAt) {
    this.expiredAt = expiredAt;
  }
  public List<Rolls> getRollsList() {
    return rollsList;
  }
  public void setRollsList(List<Rolls> rollsList) {
    this.rollsList = rollsList;
  }
  
}
