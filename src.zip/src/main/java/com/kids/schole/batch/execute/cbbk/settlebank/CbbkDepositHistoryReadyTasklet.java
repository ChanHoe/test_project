package com.kids.schole.batch.execute.cbbk.settlebank;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cbbk.domain.CbbkDepositHistory;
import com.kids.schole.batch.support.cbbk.service.CbbkService;
import com.kids.schole.batch.support.settlebank.domain.Vacs;
import com.kids.schole.common.security.AES256Util;

@Component
public class CbbkDepositHistoryReadyTasklet implements Tasklet {

  @Autowired
  private CbbkService cbbkService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    @SuppressWarnings("unchecked")
    List<Vacs> vacsList = (List<Vacs>) chunkContext.getStepContext().getStepExecution()
        .getJobExecution().getExecutionContext().get("vacsList");

    for (Vacs vacs : vacsList) {

      CbbkDepositHistory cbbkDepositHistory = new CbbkDepositHistory();
      cbbkDepositHistory.setBankAccount(AES256Util.encrypt(vacs.getIacctNo()));
      cbbkDepositHistory.setBankCode("BK" + vacs.getBankCd().substring(1));
      cbbkDepositHistory.setBankName(getBankName(vacs.getBankCd()));
      cbbkDepositHistory.setDepositDatetime(vacs.getTrIl() + vacs.getTrSi());
      cbbkDepositHistory.setDepositName(vacs.getIacctNm());
      cbbkDepositHistory.setDepositAmt(vacs.getTrAmt());
      cbbkDepositHistory.setTotalAllotAmt(0);
      cbbkDepositHistory.setAllotStatus("ready");
      cbbkDepositHistory.setSbKey(vacs.getTrNo());  // 거래고유번호
      cbbkDepositHistory.setRegisteredEmpNumber(99999);

      if (vacs.getInpSt().equals("1")) {
        cbbkService.createCbbkDepositHistory(cbbkDepositHistory);
      } else {
        cbbkService.removeCbbkDepositHistory(cbbkDepositHistory);
      }

    }

    return RepeatStatus.FINISHED;

  }

  private String getBankName(String bankCode) {

    String bankName = "";

    switch (bankCode) {
      case "011":
        bankName = "농협";
        break;
      case "004":
        bankName = "국민은행";
        break;
      case "003":
        bankName = "기업은행";
        break;
      case "020":
        bankName = "우리은행";
        break;
      case "088":
        bankName = "신한은행";
        break;
      default:
        bankName = bankCode;
    }

    return bankName;

  }

}
