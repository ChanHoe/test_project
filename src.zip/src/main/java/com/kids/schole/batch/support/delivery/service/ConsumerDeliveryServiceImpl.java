package com.kids.schole.batch.support.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.delivery.dao.ConsumerDeliveryDao;
import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;

@Service
public class ConsumerDeliveryServiceImpl implements ConsumerDeliveryService {
  
  @Autowired
  private ConsumerDeliveryDao consumerDeliveryDao;
  
  @Override
  public void modifyConsumerDeliveryRequestStatusWait(DeliveryRequest deliveryRequest) {
    consumerDeliveryDao.updateConsumerDeliveryRequestStatusWait(deliveryRequest);
  }

  @Override
  public List<Order> getConsumerDeliveryStatusWaitList() {
    return consumerDeliveryDao.selectConsumerDeliveryStatusWaitList();
  }

  @Override
  public void modifyConsumerDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest) {
    consumerDeliveryDao.updateConsumerDeliveryRequestStatusScmAccept(deliveryRequest);
  }

  @Override
  public List<DeliveryRequest> getConsumerDeliveryStatusScmDeliveryList() {
    return consumerDeliveryDao.selectConsumerDeliveryStatusScmDeliveryList();
  }

  @Override
  public void modifyConsumerDeliveryRequestStatus(DeliveryRequest tempDeliveryRequest) {
    consumerDeliveryDao.updateConsumerDeliveryRequestStatus(tempDeliveryRequest);
  }

  @Override
  public int getConsumerDeliveryStatusNotScmShippedCount(int orderId) {
    return consumerDeliveryDao.selectConsumerDeliveryStatusNotScmShippedCount(orderId);
  }

  @Override
  public void modifySingleCopyDeliveryStatusWait(SingleCopyDelivery singleCopyDelivery) {
    consumerDeliveryDao.updateSingleCopyDeliveryStatusWait(singleCopyDelivery);
  }

  @Override
  public List<SingleCopyOrder> getSingleCopyDeliveryStatusWaitList() {
    return consumerDeliveryDao.selectSingleCopyDeliveryStatusWaitList();
  }

  @Override
  public void modifySingleCopyDeliveryStatusScmAccept(SingleCopyDelivery singleCopyDelivery) {
    consumerDeliveryDao.updateSingleCopyDeliveryStatusScmAccept(singleCopyDelivery);
  }

  @Override
  public List<SingleCopyDelivery> getSingleCopyDeliveryStatusScmDeliveryList() {
    return consumerDeliveryDao.selectSingleCopyDeliveryStatusScmDeliveryList();
  }

  @Override
  public void modifySingleCopyDeliveryStatus(SingleCopyDelivery singleCopyDelivery) {
    consumerDeliveryDao.updateSingleCopyDeliveryStatus(singleCopyDelivery);
  }

  @Override
  public int getSingleCopyDeliveryStatusNotScmShippedCount(int singleCopyOrderId) {
    return consumerDeliveryDao.selectSingleCopyDeliveryStatusNotScmShippedCount(singleCopyOrderId);
  }

}
