package com.kids.schole.batch.support.sales.dao;

import java.util.HashMap;
import java.util.List;

/**
 * SalesInfoDao는 매출 집계 처리를 위한 DAO 인터페이스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
public interface SalesInfoDao {

	// 일별 매출 집계
	int insertDailySaleInfo(HashMap<String, String> param) throws Exception;

	// 월별 매출 집계
	int insertMonthlySaleInfo(HashMap<String, String> param) throws Exception;

	// 현재월별 인원현황
	List<HashMap<String, Object>> selectCurrentMonthlyEMPSaleInfoList(HashMap<String, Object> param) throws Exception;

	// 월별 인원현황
	List<HashMap<String, Object>> selectMonthlyEMPSaleInfoList(HashMap<String, Object> param) throws Exception;
	
	// 현재최근 발령 내역
	HashMap<String, Object> selectCurrentPersonnelChange(HashMap<String, Object> param) throws Exception;
	
	// 최근 발령 내역
	HashMap<String, Object> selectPersonnelChange(HashMap<String, Object> param) throws Exception;

	// 인원별 누적금액
	HashMap<String, Object> selectMonthlySaleInfoSum(HashMap<String, Object> param) throws Exception;

	// 월별 미팅 참여 수
	int selectDailyMeetingCount(HashMap<String, Object> param) throws Exception;
	
	// 월간 인원 현황 삭제
	int deleteMonthlyEmpInfo(HashMap<String, Object> param) throws Exception;
	
	// 월간 인원 현황 입력
	int insertMonthlyEmpInfo(HashMap<String, Object> param) throws Exception;

	// 월별 지점 조직 현황
	List<HashMap<String, Object>> selectMonthlyORGBranchInfoList(HashMap<String, Object> param) throws Exception;

	// 현재월별 지점 조직 현황 인원 집계
	List<HashMap<String, Object>> selectCurrentMonthlyORGEmpCount(HashMap<String, Object> param) throws Exception;

	// 월별 지점 조직 현황 인원 집계
	List<HashMap<String, Object>> selectMonthlyORGEmpCount(HashMap<String, Object> param) throws Exception;

	// 현재월별 지점 조직 등록 인원
	int selectCurrentMonthlyORGRegisterEmpCount(HashMap<String, Object> param) throws Exception;

	// 월별 지점 조직 등록 인원
	int selectMonthlyORGRegisterEmpCount(HashMap<String, Object> param) throws Exception;
	
	// 현재월별 지점 조직 해약 인원
	int selectCurrentMonthlyORGExpireEmpCount(HashMap<String, Object> param) throws Exception;
	
	// 월별 지점 조직 해약 인원
	int selectMonthlyORGExpireEmpCount(HashMap<String, Object> param) throws Exception;

	// 월별 조직 삭제
	int deleteMonthlyORGInfo(HashMap<String, Object> param) throws Exception;
	
	// 월별 조직 입력
	int insertMonthlyORGInfo(HashMap<String, Object> param) throws Exception;

	// 월별 라운지 조직 입력
	int insertMonthlyORGLoungeInfo(HashMap<String, Object> param) throws Exception;
}
