package com.kids.schole.batch.execute.cashreceipt.issue;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.service.PgCashReceiptService;
import com.kids.schole.common.properties.CashReceiptProperties;

/**
 * 현금영주승 요청을 하기 위해 준비(요청건을 조회해서 txt 파일 생성)
 *
 * @author 최인혜
 */
@Component
public class MakeCashReceiptFileForIssueTasklet implements Tasklet {

  @Autowired
  private CashReceiptProperties cashReceiptProperties;

  @Autowired
  private PgCashReceiptService pgCashReceiptService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    // 일반주문의 현금영수증 대상건 조회(처음부터 전문에 맞게 데이터를 가져옴)
    List<String> cashReceiptTargets = pgCashReceiptService.getCashReceiptsForIssue(nowDate);
    // 낱권유상의 현금영수증 대상건 조회(처음부터 전문에 맞게 데이터를 가져옴)
    List<String> singleCopyCashReceiptTargets = pgCashReceiptService.getSingleCopyCashReceiptsForIssue(nowDate);
    if (cashReceiptTargets.isEmpty() && singleCopyCashReceiptTargets.isEmpty()) {
      return RepeatStatus.FINISHED;
    }

    // TODO 같은 날짜로 요청하면 ? 파일명 다르게 생성.ex) 20170907_2.txt
    // TODO 같은걸 보내면 어떻게 되지?

    PgCashReceiptBatchLog cashReceiptBatchLog = PgCashReceiptBatchLog.createIssueCashReceipt(cashReceiptProperties);
    cashReceiptBatchLog.setRegisteredEmpNumber(99999);
    pgCashReceiptService.createPgCashReceiptBatch(cashReceiptBatchLog);

    try {
      FileOutputStream fileOutputStream = new FileOutputStream(cashReceiptBatchLog.getFullFileName());
      OutputStreamWriter OutputStreamWriter = new OutputStreamWriter(fileOutputStream, "euc-kr");
      BufferedWriter out = new BufferedWriter(OutputStreamWriter);

      // 일반주문 파일 write
      for (String cashReceiptTarget : cashReceiptTargets) {
        out.write(cashReceiptTarget);
        out.newLine();
      }
      // 낱권유상 파일 write
      for (String singleCopyCashReceiptTarget : singleCopyCashReceiptTargets) {
        out.write(singleCopyCashReceiptTarget);
        out.newLine();
      }
      out.close();

    } catch (IOException e) {
      System.err.println(e); // 에러가 있다면 메시지 출력
      System.exit(1);
    }

    // 일반주문의 현금영수증 배치ID 적용
    List<Integer> cashReceiptIds = pgCashReceiptService.getCashReceiptIdsForIssue(nowDate);
    if (!cashReceiptIds.isEmpty()) {
      cashReceiptBatchLog.setCashReceiptIds(cashReceiptIds);
      pgCashReceiptService.modifyCashReceiptForBatchLogId(cashReceiptBatchLog);
    }

    // 낱권유상의 현금영수증 상태 변경
    List<Integer> singleCopyCashReceiptIds = pgCashReceiptService.getSingleCopyCashReceiptIdsForIssue(nowDate);
    if (!singleCopyCashReceiptIds.isEmpty()) {
      cashReceiptBatchLog.setSingleCopyCashReceiptIds(singleCopyCashReceiptIds);
      pgCashReceiptService.modifySingleCopyCashReceiptsForBatch(cashReceiptBatchLog);
    }

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
          .put("cashReceiptBatchLog", cashReceiptBatchLog);

    return RepeatStatus.FINISHED;

  }

}
