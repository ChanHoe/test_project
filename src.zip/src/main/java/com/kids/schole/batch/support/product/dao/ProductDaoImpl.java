package com.kids.schole.batch.support.product.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDaoImpl implements ProductDao {

  @Autowired
  private SqlSession sqlSession;
  
  @Override
  public void updateProductStatus() {
    // TODO Auto-generated method stub
    sqlSession.update("product.updateProductStatus");
  }
  
}
