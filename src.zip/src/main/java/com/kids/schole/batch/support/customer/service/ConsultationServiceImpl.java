package com.kids.schole.batch.support.customer.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.kids.schole.batch.support.customer.dao.ConsultationDao;
import com.kids.schole.batch.support.customer.domain.CsAllotMapping;
import com.kids.schole.common.constant.IConst;
import com.kids.schole.common.util.EmailUtil;
import com.kids.schole.common.util.SMSUtil;

/**
 * ConsultationServiceImpl은 온라인상담을 위한 서비스 클래스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
@Service
public class ConsultationServiceImpl implements ConsultationService {

	final String to_mail = "jerry@stunitas.com";
	
	@Autowired
	private ConsultationDao consultationDao;

	@Override
	public int modifyCsConsultationVDAllot() {
		
		Set<String> postcodeSet = new HashSet<String>();
		
		// 1. 라운지 미배분 내역 재배분 진행
		List<CsAllotMapping> list = consultationDao.selectCsConsultationAllotNoneList();
		for(CsAllotMapping csAllotMapping : list){
			
			if( StringUtils.isEmpty(csAllotMapping.getOrganizationName()) ){
				postcodeSet.add(csAllotMapping.getPostCode());
			}else{
				consultationDao.updateCsConsultationVDAllot(csAllotMapping);
			}
		}
		
		return 1;
	}


	@Override
	public int csConsultationVDAllotNoti() {
		
		Set<String> postcodeSet = new HashSet<String>();
		// TODO postcodeSet 배분되지 않은 우편번호 리포팅 추가 필요

		// 1. 지점 배분 1주일 이후 대기 건 추출
		List<CsAllotMapping> waitList = consultationDao.selectCsConsultationAllotWaitList();

		// 2. 미배분 내역 메일 전송
		StringBuffer msg = new StringBuffer();
		msg.append(EmailUtil.makeHtmlHeader());
		
		msg.append(" <BODY>");
		if(postcodeSet.size() > 0){
			msg.append(makeEmailHtmlPOSTCODE(postcodeSet, "배분되지 않는 우편변호") );
		}
		if(waitList.size() > 0){
			msg.append(makeEmailHtmlWAIT(waitList, " 지점 배분 3일이상 대기 건") );
		}
		msg.append("</BODY></HTML>" );

		// 라이브만 발송
		if("RELEASE".equals(IConst.CONF_SYSTEM_TYPE) ){
			// 3. 메일 발송
			if( postcodeSet.size() > 0 || waitList.size() > 0 ){
				try {
					EmailUtil.sendHtmlEmail(to_mail, "[Lounge] 고객 온라인상담 점검 알림", msg.toString());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			// 4. 핸드폰 발송
			for(CsAllotMapping obj : waitList){
				SMSUtil.sendSms(obj.getName()+" 고객님이 상담을 기다리고 계십니다. 지금 e스콜레라운지에서 확인해주세요.", obj.getMobileNumber(), "키즈스콜레 [가망고객]");
			}
		}
		return 1;
	}
	
	public static String makeEmailHtmlPOSTCODE(Set<String> postcodeSet, String subject) {  
		StringBuffer msg = new StringBuffer();
		msg.append("<table border='1' width=1000 cellpadding='2' align='center' borderColor='#ff0000' style='border-collapse:collapse'>");
		msg.append(" <tr height=30 bgcolor='#FFFFFF' align='center'>");
		msg.append("   <td width='100%' class='AL'>"+subject+"</td>");
		msg.append(" </tr>");
		msg.append(" <tr bgcolor='#FFFFFF'>" );
		msg.append("	<td class='AL' >");

		for(String postcode : postcodeSet){
			msg.append(postcode + " , ");	
		}

		msg.append("	</td>");
		msg.append(" </tr>" );
		msg.append("</table> <br><br>" );

		return msg.toString(); 
	}
	
	public String makeEmailHtmlWAIT(List<CsAllotMapping> waitList, String subject) {  
		StringBuffer msg = new StringBuffer();
		String emailForm =	
						"<table width=1000 align=center cellspacing=0 cellpadding=0 >"
						+ "	<tr height=30 bgcolor='#FFFFFF'>"
						+ "   <td width='100%' class='AL'><b> " + subject + "</b></td>"
						+ " </tr>"
						+ "</table>"
						+ "<table border=1 width=1000 cellpadding=2 align=center borderColor='#ff0000' style='border-collapse:collapse'>"
						+ "	<tr height=25 align=center>"
						+ "   <td width=100 class='bT'>상담No</td>"
						+ "   <td width=100 class='bT'>배정라운지</td>"
						+ "   <td width=100 class='bT'>고객명</td>"
						+ "   <td width=100 class='bT'>담당자</td>"
						+ " </tr>";

		msg.append(emailForm);
		
		for(CsAllotMapping csAllotMapping : waitList) {
			msg.append("<tr bgcolor='#FFFFFF'>" );
			msg.append("<td align=center>" +  csAllotMapping.getCsConsultationId());
			msg.append("<td align=center>" +  csAllotMapping.getOrganizationName());
			msg.append("<td align=center>" +  csAllotMapping.getName());
			msg.append("<td align=center>" +  csAllotMapping.getEmpName());
			msg.append("</tr>" );
		}
		msg.append("</tr></table> <br><br>" );

		return msg.toString(); 
	}
}
