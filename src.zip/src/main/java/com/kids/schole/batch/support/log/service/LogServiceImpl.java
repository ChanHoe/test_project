package com.kids.schole.batch.support.log.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.log.dao.LogDao;

/**
 * LogService는 배치로그 삭제를 위한 서비스 클래스입니다.
 * 
 * @version 1.0 2017.01.04
 * @author Jeongwon Son
 */
@Service
public class LogServiceImpl implements LogService{

  @Autowired
  private LogDao logDao;

  @Override
  public void removeBatchLogWithinTwoWeeks() {
    
    // 순서대로 배치로그를 삭제
    logDao.deleteBatchStepExecutionContext();
    logDao.deleteBatchStepExecution();
    logDao.deleteBatchJobExecutionContext();
    logDao.deleteBatchJobExecutionParams();
    logDao.deleteBatchJobExecution();
    logDao.deleteBatchJobInstance();
  }
  
}
