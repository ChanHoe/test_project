package com.kids.schole.batch.support.delivery.domain;

import com.google.gson.annotations.SerializedName;

public class TrackingNumberTraceResponseStatus {

  private String status;

  @SerializedName("resultCode")
  private String resultCode;

  @SerializedName("result")
  private TrackingNumberTraceResult trackingNumberTraceResult;

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getResultCode() {
    return resultCode;
  }

  public void setResultCode(String resultCode) {
    this.resultCode = resultCode;
  }

  public TrackingNumberTraceResult getTrackingNumberTraceResult() {
    return trackingNumberTraceResult;
  }

  public void setTrackingNumberTraceResult(TrackingNumberTraceResult trackingNumberTraceResult) {
    this.trackingNumberTraceResult = trackingNumberTraceResult;
  }

}
