package com.kids.schole.batch.support.order.service;

import java.util.List;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.OrderPayment;

public interface OrderService {

  public List<CardPaymentRequest> getOrderApprovalList();

  public void modifyOrderPaymentPayStatus(OrderPayment orderPayment);

  public void modifyOrderPayDoneAmt(Order order);

  public void modifyOrderStatus(Order order);

  public void modifyOrderStatusDone(Order order);

  public void modifyInstallmentPaymentRequestStatus(
      InstallmentPaymentRequest installmentPaymentRequest);

  public void modifyInstallmentPaymentStatus(InstallmentPayment installmentPayment);
  
  public Order getOrder(int orderId);
  
  // 주문 계약서 첨부파일 CMS 회원 증빙 실패 -> 대기 (기간은 일주일)
  public void modifyOrderAttachedFileProofStatusFailToWait();

}
