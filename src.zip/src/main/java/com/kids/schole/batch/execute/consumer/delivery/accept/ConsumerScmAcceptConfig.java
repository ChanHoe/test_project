package com.kids.schole.batch.execute.consumer.delivery.accept;

/**
 * ConsumerScmAcceptConfig는 소비자 처리 후 배송요청 대기건인 주문을 조회해서 
 * SCM에 배송 요청을 하고 그 이후 작업을 처리하는 클래스입니다.
 * 
 * @version 1.0 2017.03.21
 * @author chheo
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class ConsumerScmAcceptConfig {
  
  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private ConsumerScmAcceptTasklet consumerScmAcceptTasklet;
  
  @Autowired
  private ConsumerDeliveryRequestAcceptTasklet consumerDeliveryRequestAcceptTasklet;
  
  
  //저녁 7시 30분
  @Scheduled(cron = "0 30 19 * * ?")
  public String runConsumerScmAccept() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(consumerScmAcceptJob(), param);

    return execution.getStatus().toString();

  }
  
  @Bean
  public Job consumerScmAcceptJob() {
    return jobBuilderFactory
        .get("consumerScmAcceptJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(consumerScmAcceptStep())
        .next(consumerDeliveryRequestAcceptStep())
        .build();
  }
  
  // 소비자 처리건 배송요청 대기중인 주문을 가져와서 SCM쪽에 배송 요청을 한다.
  @Bean
  public Step consumerScmAcceptStep() {
   return stepBuilderFactory
       .get("consumerScmAcceptStep")
       .tasklet(consumerScmAcceptTasklet)
       .build();
  }
  
  // 소비자 처리건 배송요청 테이블의 배송상태를 업데이트한다.
  @Bean
  public Step consumerDeliveryRequestAcceptStep() {
    return stepBuilderFactory
        .get("consumerDeliveryRequestAcceptStep")
       .tasklet(consumerDeliveryRequestAcceptTasklet)
       .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

  
}
