package com.kids.schole.batch.execute.albam;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.albam.domain.DailyMeetingInfo;
import com.kids.schole.batch.support.albam.domain.RollsReponse;
import com.kids.schole.batch.support.albam.domain.VwSalesEmpInfo;
import com.kids.schole.batch.support.albam.service.AlbamService;
import com.kids.schole.common.constant.AlbamConst;
import com.kids.schole.common.properties.AlbamProperties;
import com.kids.schole.common.util.DateUtil;
import com.kids.schole.common.util.DomainUtil;
import com.kids.schole.common.util.StringUtil;

@Component
public class DailyMeetingInfoTasklet implements Tasklet {

  private Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Autowired
  private AlbamService albamService;
  
  @Autowired
  private AlbamProperties albamProperties;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
    
    Map<String, Object> param = chunkContext.getStepContext().getJobParameters();
    
    String inputYear = (String)param.get("inputYear");
    String inputMonth = (String)param.get("inputMonth");
    String empKey = (String)param.get("empKey");  // 교사 번호
    
    // 해당 연도와 월을 구함
    Date date = DateUtil.getSysDate();
    
    VwSalesEmpInfo vwSalesEmpInfo = new VwSalesEmpInfo();
    vwSalesEmpInfo.setSaleYear(StringUtils.isBlank(inputYear) ? DateUtil.getSysDateFormat(date, "yyyy") : inputYear);
    vwSalesEmpInfo.setSaleMonth(StringUtils.isBlank(inputMonth) ? DateUtil.getSysDateFormat(date, "MM") : inputMonth);
    vwSalesEmpInfo.setEmpKey(StringUtils.isBlank(empKey) ? null : empKey);  // 특정 교사 알밤 기록 가져오고 싶을때 사용
    
    // 재직 중인 CD 목록을 가져온다.
    List<VwSalesEmpInfo> vwSalesEmpInfoList = albamService.getVwSalesEmpInfoList(vwSalesEmpInfo);
    
    // 배치 실행되는 날짜의 하루 전날 : 어제
    Calendar cal = new GregorianCalendar();
    cal.add(Calendar.DATE, -1);
    
    // 웹에서 시작, 종료일을 입력한 경우 날짜 setting
    inputYear = vwSalesEmpInfo.getSaleYear();
    inputMonth = vwSalesEmpInfo.getSaleMonth();
    String startDate = (String)param.get("startDate");  // 시작 날짜
    String endDate = (String)param.get("endDate");  // 종료 날짜
    String beforeDate = new java.text.SimpleDateFormat("yyyyMMdd").format(cal.getTime()); // 어제
    String today = DateUtil.getSysDateFormat("yyyyMMdd"); // 오늘
    
    // 시작일을 입력하지 않은 경우
    if(StringUtils.isEmpty(startDate)){
      // 어제
      startDate = beforeDate + "000000";
    }else{
      startDate = inputYear+ inputMonth + startDate + "000000";
    }
    
    // 종료일을 입력하지 않은 경우
    if(StringUtils.isEmpty(endDate)){
      // 오늘(종료일 날짜가 있으면 종료일에 시간)
      endDate = today + "235959";
    }else{
      endDate = inputYear + inputMonth + endDate + "235959";
    }
    
    logger.debug("날짜(시작,종료일) 값 확인 {} {}" , startDate, endDate);
    
    for (VwSalesEmpInfo empInfo : vwSalesEmpInfoList) {
      
      MultiValueMap<String, String> rollsMap = new LinkedMultiValueMap<String, String>();
      
      rollsMap.add("access_token", albamProperties.getAccessToken());
      rollsMap.add("custom_value", empInfo.getCdEmpKey());
      rollsMap.add("sdate", startDate);
      rollsMap.add("edate", endDate);
      
      String url = albamProperties.getUrl() + AlbamConst.ALBAM_ROLLS_URL;
  
      // Http Header 세팅
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
      
      HttpEntity<MultiValueMap<String, String>> rollsMapEntity =
          new HttpEntity<MultiValueMap<String, String>>(rollsMap, headers);
      
      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<String> responseEntity =
          restTemplate.postForEntity(url, rollsMapEntity, String.class);
      
      Gson gson = new GsonBuilder()
          .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();
      
      RollsReponse rollsResponseStatus =
          gson.fromJson(responseEntity.getBody(), RollsReponse.class);
      
      DailyMeetingInfo dailyMeetingInfo = new DailyMeetingInfo();
      
      if(rollsResponseStatus.getReturnCode().equals(0)){
        
        if(rollsResponseStatus.getRollsResult().getRollsList().size() > 0){
          // rollId null 체크하기
          
          for(int i=0; i< rollsResponseStatus.getRollsResult().getRollsList().size(); i++){
            
            if(rollsResponseStatus.getRollsResult().getRollsList().get(0).getRollsId() != null){
              
//              logger.debug("user 값 확인 {} {} {}", empInfo.getCdEmpKey(),
//                  rollsResponseStatus.getRollsResult().getRollsList().get(i).getRollsId(),
//                  rollsResponseStatus.getRollsResult().getRollsList().get(i).getUserId());
              
              // cdEmpKey, meetingDate 먼저 값을 set함
              dailyMeetingInfo.setCdEmpKey(empInfo.getCdEmpKey());
              dailyMeetingInfo.setMeetingDate(
                  rollsResponseStatus.getRollsResult().getRollsList().get(i).getConvertedStartTimeE().substring(0,10)); // 관리자 보정 날짜로 활동 일자 
              
              dailyMeetingInfo.setRollId(
                  rollsResponseStatus.getRollsResult().getRollsList().get(i).getRollsId());
              dailyMeetingInfo.setUserId(
                  rollsResponseStatus.getRollsResult().getRollsList().get(i).getUserId());
              dailyMeetingInfo.setStaffName(
                  rollsResponseStatus.getRollsResult().getRollsList().get(i).getStaffName());
              
              String startTime = rollsResponseStatus.getRollsResult().getRollsList().get(i).getConvertedStartTimeE();	// 관리자 보정 우선
              if(StringUtil.isNull(startTime)){
            	  startTime = rollsResponseStatus.getRollsResult().getRollsList().get(i).getConvertedStartTime();
              }
              dailyMeetingInfo.setStartTime(startTime);
              
              String endTime = rollsResponseStatus.getRollsResult().getRollsList().get(i).getConvertedEndTimeE();		// 관리자 보정 우선
              if(StringUtil.isNull(endTime)){
            	  endTime = rollsResponseStatus.getRollsResult().getRollsList().get(i).getConvertedEndTime();
              }
              dailyMeetingInfo.setEndTime(endTime);
              
//              DomainUtil.retriveDomain(dailyMeetingInfo);
              
              // 근무 시작일 날짜 비교
              SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
              Date empWorkBeginDate = df.parse(empInfo.getWorkBeginDate());
              Date albamMeetingDate = df.parse(dailyMeetingInfo.getMeetingDate());
              
              // 근무 시작일 부터 확인 ( 근무시작일이 알밤등록일보다 작거나 같을때 insert )
              if(empWorkBeginDate.compareTo(albamMeetingDate) <= 0){
                // 값이 없으면 insert, 있으면 update 됨
                albamService.createDailyMeetingInfo(dailyMeetingInfo);
              }
              
            }
          }
        }

      }
    }
    
    return RepeatStatus.FINISHED;
  }

}
