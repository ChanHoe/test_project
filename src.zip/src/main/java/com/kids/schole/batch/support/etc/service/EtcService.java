package com.kids.schole.batch.support.etc.service;

import java.util.List;

import com.kids.schole.batch.support.etc.domain.SpecialHoliday;

public interface EtcService {
  
  List<SpecialHoliday> getCacheSpecialHolidayList();
  
}
