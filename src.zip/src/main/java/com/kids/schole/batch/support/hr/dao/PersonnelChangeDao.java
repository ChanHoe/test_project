package com.kids.schole.batch.support.hr.dao;

import java.util.List;

import com.kids.schole.batch.support.hr.domain.PersonnelChange;

public interface PersonnelChangeDao {

  public List<PersonnelChange> selectPersonnelChangeOfMonthly();

  public List<PersonnelChange> selectPersonnelChangeByType(PersonnelChange PersonnelChange);
}
