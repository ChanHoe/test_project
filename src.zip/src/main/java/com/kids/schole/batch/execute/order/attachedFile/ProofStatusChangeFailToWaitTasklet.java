package com.kids.schole.batch.execute.order.attachedFile;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.order.service.OrderService;

@Component
public class ProofStatusChangeFailToWaitTasklet implements Tasklet{
  
  @Autowired
  private OrderService orderService;
  
  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 주문 계약서 회원 증빙 상태 실패 -> 대기로 변경
    orderService.modifyOrderAttachedFileProofStatusFailToWait();

    return RepeatStatus.FINISHED;
  }

}
