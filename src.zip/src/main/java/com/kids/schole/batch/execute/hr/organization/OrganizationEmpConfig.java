package com.kids.schole.batch.execute.hr.organization;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * 조직-사원 테이블에 대한 처리를 담당하는 클래스입니다.
 *
 * @version 1.0 2017. 2. 3.
 * @author Eunsung Ju
 */
@Configuration
@EnableBatchProcessing
public class OrganizationEmpConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  private OrganizationEmpTasklet organizationEmpTasklet;


  // 매월 1일 00시 01분 00초 실행
  @Scheduled(cron="0 1 0 1 * ?")
  public String runOrganizationEmp() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(organizationIdModifyJob(), param);

    return execution.getStatus().toString();
  }

  @Bean
  public Job organizationIdModifyJob() {

    return jobBuilderFactory
            .get("organizationIdModifyJob")
            .incrementer(new RunIdIncrementer())
            .listener(listener())
            .start(organizationIdModifyStep())
            .build();
  }

  @Bean
  public Step organizationIdModifyStep() {

    return stepBuilderFactory
            .get("organizationIdModifyStep")
            .tasklet(organizationEmpTasklet)
            .build();
  }

  @Bean
  public JobExecutionListener listener() {

    return new JobCompletionNotificationListener();
  }
}
