package com.kids.schole.batch.execute.cms.member;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cms.member.domain.Member;
import com.kids.schole.batch.support.cms.member.service.MemberService;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;

@Component
public class MemberModifyWaitForChangeAccountTasklet implements Tasklet {

  @Autowired
  private MemberService memberService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    // 회원신청할 데이터가 있을때만 전문을 실행한다.
    String firstDayOfNextMonth = LocalDate.now().plusMonths(1).format(DateTimeFormatter.ofPattern("yyyy-MM"))+"-01";
    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    InstallmentPaymentRequest search = new InstallmentPaymentRequest();
    search.setFirstDayOfNextMonth(firstDayOfNextMonth);
    search.setApplicationDate(nowDate);
    List<Member> modifiedAccountMembers = memberService.getModifyAccountInstallments(search);

    if (modifiedAccountMembers.size() < 1) {
      return RepeatStatus.FINISHED;
    }

    for (Member member : modifiedAccountMembers) {
      memberService.modifyApplicationStatusWaitAndModify(member.getInstallmentPaymentRequestId());
    }

    return RepeatStatus.FINISHED;
  }


}
