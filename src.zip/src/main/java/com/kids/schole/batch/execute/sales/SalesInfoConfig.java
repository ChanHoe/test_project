package com.kids.schole.batch.execute.sales;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

/**
 * SalesInfoConfig는 사업부 매출 집계를 처리하는 클래스입니다.
 * 
 * @version 1.0 2016.12.27
 * @author Gil K.
 */
@Configuration
@EnableBatchProcessing
public class SalesInfoConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private DailySalesInfoTasklet dailySalesInfoTasklet;
  
  @Autowired
  private MonthlySalesInfoTasklet monthlySalesInfoTasklet;
  
  @Scheduled(cron="0 0/5 * * * *")
  public String runSalesInfo() throws Exception {
    
    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
    
    JobExecution execution = jobLauncher.run(dailySalesInfoJob(), param);
    
    return execution.getStatus().toString();
  }
  
  // 웹에서의 파라미터 지정 호출용
  public String runSalesInfo(String firstDate) throws Exception {
    
    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis()))
    	.addString("firstDate", firstDate).toJobParameters();
    
    JobExecution execution = jobLauncher.run(dailySalesInfoJob(), param);
    
    return execution.getStatus().toString();
  }
  
  @Bean
  public Job dailySalesInfoJob() {
    
    return jobBuilderFactory
        .get("dailySalesInfoJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(dailySalesInfoStep())
        .next(monthlySalesInfoStep())
        .build();
  }
  
  // 일일 매출 집계
  @Bean
  public Step dailySalesInfoStep() {
    
    return stepBuilderFactory
        .get("dailySalesInfoStep")
        .tasklet(dailySalesInfoTasklet)
        .build();
  }
  
  // 월별 매출 집계
  @Bean
  public Step monthlySalesInfoStep() {
   
    return stepBuilderFactory
       .get("monthlySalesInfoStep")
       .tasklet(monthlySalesInfoTasklet)
       .build();
  }
 
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }
  
}
