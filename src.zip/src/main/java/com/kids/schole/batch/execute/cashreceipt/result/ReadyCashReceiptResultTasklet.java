package com.kids.schole.batch.execute.cashreceipt.result;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.kids.schole.batch.support.cashreceipt.issue.domain.PgCashReceiptBatchLog;
import com.kids.schole.batch.support.cashreceipt.issue.service.PgCashReceiptService;
import com.kids.schole.common.properties.CashReceiptProperties;

/**
 * 현금영수증 결과조회를 위해 준비
 *
 * @author 최인혜
 */
@Component
public class ReadyCashReceiptResultTasklet implements Tasklet {

  @Autowired
  private CashReceiptProperties cashReceiptProperties;

  @Autowired
  private PgCashReceiptService pgCashReceiptService;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    String nowDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    String preDate = LocalDate.now().minusDays(7).format(DateTimeFormatter.ofPattern("yyyyMMdd")); // 결과조회 기간은 7일전부터로.

    PgCashReceiptBatchLog cashReceiptBatchLog = PgCashReceiptBatchLog.createResultCashReceipt(preDate, nowDate, cashReceiptProperties);
    cashReceiptBatchLog.setRegisteredEmpNumber(99999);
    pgCashReceiptService.createPgCashReceiptBatch(cashReceiptBatchLog);

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
                                 .put("cashReceiptBatchLog", cashReceiptBatchLog);

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
                                 .put("preDate", preDate);
    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
                                 .put("nowDate", nowDate);

    return RepeatStatus.FINISHED;

  }

}
