package com.kids.schole.batch.execute.consumer.delivery.accept;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kids.schole.batch.support.delivery.domain.SingleCopyDelivery;
import com.kids.schole.batch.support.delivery.domain.WarehouseResponseStatus;
import com.kids.schole.batch.support.delivery.service.ConsumerDeliveryService;
import com.kids.schole.batch.support.order.domain.SingleCopyOrder;
import com.kids.schole.common.constant.DeliveryConst;
import com.kids.schole.common.constant.WarehouseConst;
import com.kids.schole.common.properties.WarehouseProperties;
import com.kids.schole.common.util.DomainUtil;
import com.kids.schole.common.util.StringUtil;
import com.kids.schole.common.util.WarehouseUtil;

@Component
public class SingleCopyScmAcceptTasklet implements Tasklet {

  @Autowired
  private ConsumerDeliveryService consumerDeliveryService;

  @Autowired
  private WarehouseProperties warehouseProperties;

  @Override
  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)
      throws Exception {

    List<SingleCopyDelivery> singleCopyDeliveryList = new ArrayList<SingleCopyDelivery>();

    // 현재 배송 대기중인 낱권주문 리스트를 가져온다.
    List<SingleCopyOrder> singleCopyOrderList = consumerDeliveryService.getSingleCopyDeliveryStatusWaitList();

    for (SingleCopyOrder singleCopyOrder : singleCopyOrderList) {

      String[] tempMobileNumber = singleCopyOrder.getReceiverMobileNumber().split("-");

      String prefixPhoneNumber = null;
      String infixPhoneNumber = null;
      String suffixPhoneNumber = null;

      if (StringUtils.isNotBlank(singleCopyOrder.getReceiverPhoneNumber())) {
        String[] tempPhoneNumber = singleCopyOrder.getReceiverPhoneNumber().split("-");
        if (tempPhoneNumber.length == 3) {
          prefixPhoneNumber = tempPhoneNumber[0];
          infixPhoneNumber = tempPhoneNumber[1];
          suffixPhoneNumber = tempPhoneNumber[2];
        }
      }

      // 현재 시간 설정
      LocalDateTime now = LocalDateTime.now();
      DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

      Map<String, String> warehouseMap = new TreeMap<String, String>();
      // 필수 값
      warehouseMap.put("contents_id", singleCopyOrder.getWarehouseContentsKey());
      warehouseMap.put("biz_code", warehouseProperties.getBizCode());
      warehouseMap.put("biz_order_number", "A" + singleCopyOrder.getSingleCopyOrderId());
      warehouseMap.put("biz_delivery_record_id", "A" + singleCopyOrder.getSingleCopyDeliveryId());
      warehouseMap.put("sender_name", warehouseProperties.getSenderName());
      warehouseMap.put("sender_tel", warehouseProperties.getSenderTel());
      warehouseMap.put("sender_addr", warehouseProperties.getSenderAddr());
      warehouseMap.put("customer_user_id", singleCopyOrder.getCustomerId() + "");
      warehouseMap.put("customer_name", singleCopyOrder.getReceiverName());
      if (tempMobileNumber.length == 3) {
        warehouseMap.put("customer_phone1", tempMobileNumber[0]);
        warehouseMap.put("customer_phone2", tempMobileNumber[1]);
        warehouseMap.put("customer_phone3", tempMobileNumber[2]);
      } 
      else if (tempMobileNumber.length < 3) {

        String mobileNumber = StringUtil.replace(singleCopyOrder.getReceiverMobileNumber(), "-", "");
        if (StringUtil.length(mobileNumber) == 11) {
          warehouseMap.put("customer_phone1", mobileNumber.substring(0, 3));
          warehouseMap.put("customer_phone2", mobileNumber.substring(3, 7));
          warehouseMap.put("customer_phone3", mobileNumber.substring(7));
        } else if (StringUtil.length(mobileNumber) == 10) {
          warehouseMap.put("customer_phone1", mobileNumber.substring(0, 3));
          warehouseMap.put("customer_phone2", mobileNumber.substring(3, 6));
          warehouseMap.put("customer_phone3", mobileNumber.substring(6));
        }
      }
      warehouseMap.put("customer_postcode", singleCopyOrder.getDeliveryPostcode());
      warehouseMap.put("customer_addr1", singleCopyOrder.getDeliveryAddress());

      // 선택 값
      warehouseMap.put("customer_tel1", StringUtils.defaultString(prefixPhoneNumber));
      warehouseMap.put("customer_tel2", StringUtils.defaultString(infixPhoneNumber));
      warehouseMap.put("customer_tel3", StringUtils.defaultString(suffixPhoneNumber));
      warehouseMap.put("customer_addr2", singleCopyOrder.getDeliveryAddressDetail());
      warehouseMap.put("biz_contents_id", "");
      warehouseMap.put("customer_memo", "");
      warehouseMap.put("payment_time", now.format(dateTimeFormatter));
      warehouseMap.put("delivery_contents_divide_yn", "N");
      warehouseMap.put("record_sub_type", "");
      warehouseMap.put("cs_reason", "");
      warehouseMap.put("cs_admin_id", "");
      warehouseMap.put("cs_admin_name", "");

      warehouseMap = WarehouseUtil.setTimeStampNFingerPrint(warehouseMap);

      String url = warehouseProperties.getUrl() + WarehouseConst.DELIVERY_INSERT_URL;

      // Http Header 세팅
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

      HttpEntity<Map<String, String>> warehouseMapEntity =
          new HttpEntity<Map<String, String>>(warehouseMap, headers);

      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<String> responseEntity =
          restTemplate.postForEntity(url, warehouseMapEntity, String.class);

      Gson gson = new GsonBuilder()
          .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).create();

      WarehouseResponseStatus warehouseResponseStatus =
          gson.fromJson(responseEntity.getBody(), WarehouseResponseStatus.class);

      DomainUtil.retriveDomain(warehouseResponseStatus);

      SingleCopyDelivery singleCopyDelivery = new SingleCopyDelivery();

      if (warehouseResponseStatus.getResultCode().equals("0000")) {
        singleCopyDelivery.setSingleCopyDeliveryId(singleCopyOrder.getSingleCopyDeliveryId());
        singleCopyDelivery.setSingleCopyOrderId(singleCopyOrder.getSingleCopyOrderId());
        singleCopyDelivery.setSingleCopyDeliveryStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_SCM_ACCEPTED);
        singleCopyDelivery.setWarehouseCompleteKey(
            warehouseResponseStatus.getWarehouseResult().getCustomerRecordId());
      } else {
        singleCopyDelivery.setSingleCopyDeliveryId(singleCopyOrder.getSingleCopyDeliveryId());
        singleCopyDelivery.setSingleCopyOrderId(singleCopyOrder.getSingleCopyOrderId());
        singleCopyDelivery.setSingleCopyDeliveryStatus(DeliveryConst.DELIVERY_REQUEST_STATUS_WAIT);
        singleCopyDelivery.setWarehouseCompleteKey("");
      }

      singleCopyDeliveryList.add(singleCopyDelivery);

    }

    chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext()
        .put("singleCopyDeliveryList", singleCopyDeliveryList);

    return RepeatStatus.FINISHED;

  }

}
