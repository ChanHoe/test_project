package com.kids.schole.batch.support.cbbk.domain;


/**
 * CbbkPaymentRequest는 가상계좌 결제 요청 도메인 클래스입니다.
 * 
 * @version 1.0 2016.12.14
 * @author Jeongwon Son
 */
public class CbbkPaymentRequest {

  private int cbbkPaymentRequestId;
  private int paymentId;
  private int substitutePaymentId;
  private String bankCode;
  private String bankName;
  private String bankAccount;
  private long paymentAmt;
  private long refundAmt;
  private String requestStatus;
  private String failedPaymentReason;
  private String cbbkExpireDate;
  private String allotDatetime;
  private String depositDatetime;
  private String depositName;
  private long depositAmt;
  private String lastSmsSendDatetime;
  private int registeredEmpNumber;
  private String registeredDatetime;

  // 주문관련
  private int orderId;
  private String isCombine;
  private String payAction;
  
  public int getCbbkPaymentRequestId() {
    return cbbkPaymentRequestId;
  }

  public void setCbbkPaymentRequestId(int cbbkPaymentRequestId) {
    this.cbbkPaymentRequestId = cbbkPaymentRequestId;
  }

  public int getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(int paymentId) {
    this.paymentId = paymentId;
  }

  public int getSubstitutePaymentId() {
    return substitutePaymentId;
  }

  public void setSubstitutePaymentId(int substitutePaymentId) {
    this.substitutePaymentId = substitutePaymentId;
  }

  public String getBankCode() {
    return bankCode;
  }

  public void setBankCode(String bankCode) {
    this.bankCode = bankCode;
  }

  public String getBankName() {
    return bankName;
  }

  public void setBankName(String bankName) {
    this.bankName = bankName;
  }

  public String getBankAccount() {
    return bankAccount;
  }

  public void setBankAccount(String bankAccount) {
    this.bankAccount = bankAccount;
  }

  public long getPaymentAmt() {
    return paymentAmt;
  }

  public void setPaymentAmt(long paymentAmt) {
    this.paymentAmt = paymentAmt;
  }

  public long getRefundAmt() {
    return refundAmt;
  }

  public void setRefundAmt(long refundAmt) {
    this.refundAmt = refundAmt;
  }

  public String getRequestStatus() {
    return requestStatus;
  }

  public void setRequestStatus(String requestStatus) {
    this.requestStatus = requestStatus;
  }

  public String getFailedPaymentReason() {
    return failedPaymentReason;
  }

  public void setFailedPaymentReason(String failedPaymentReason) {
    this.failedPaymentReason = failedPaymentReason;
  }

  public String getCbbkExpireDate() {
    return cbbkExpireDate;
  }

  public void setCbbkExpireDate(String cbbkExpireDate) {
    this.cbbkExpireDate = cbbkExpireDate;
  }

  public String getAllotDatetime() {
    return allotDatetime;
  }

  public void setAllotDatetime(String allotDatetime) {
    this.allotDatetime = allotDatetime;
  }

  public String getDepositDatetime() {
    return depositDatetime;
  }

  public void setDepositDatetime(String depositDatetime) {
    this.depositDatetime = depositDatetime;
  }

  public String getDepositName() {
    return depositName;
  }

  public void setDepositName(String depositName) {
    this.depositName = depositName;
  }

  public long getDepositAmt() {
    return depositAmt;
  }

  public void setDepositAmt(long depositAmt) {
    this.depositAmt = depositAmt;
  }

  public String getLastSmsSendDatetime() {
    return lastSmsSendDatetime;
  }

  public void setLastSmsSendDatetime(String lastSmsSendDatetime) {
    this.lastSmsSendDatetime = lastSmsSendDatetime;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getOrderId() {
    return orderId;
  }

  public void setOrderId(int orderId) {
    this.orderId = orderId;
  }

  public String getIsCombine() {
    return isCombine;
  }

  public void setIsCombine(String isCombine) {
    this.isCombine = isCombine;
  }

  public String getPayAction() {
    return payAction;
  }

  public void setPayAction(String payAction) {
    this.payAction = payAction;
  }

}