package com.kids.schole.batch.execute.cbbk.autoAllotCombine;

/**
 * AutoAllotConfig는 주문금액과 가상계좌 입금금액이 일치하면 자동배분을 해주는 클래스입니다. 
 * 
 * @version 1.0 2016.12.17
 * @author Jeongho Baek
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;
import com.kids.schole.batch.execute.cbbk.autoAllot.CbbkDeliveryWaitTasklet;
import com.kids.schole.batch.execute.cbbk.autoAllot.OrderStatusCbbkAcceptTasklet;

@Configuration
@EnableBatchProcessing
public class AutoAllotCombineConfig {

  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;

  @Autowired
  public OrderStatusCbbkReadyCombineTasklet orderStatusCbbkReadyCombineTasklet;
  
  @Autowired
  public CbbkPaymentRequestDoneCombineTasklet cbbkPaymentRequestDoneCombineTasklet;
  
  @Autowired
  public OrderStatusCbbkAcceptTasklet orderStatusCbbkAcceptTasklet;
  
  @Autowired
  public CbbkDeliveryWaitTasklet cbbkDeliveryWaitTasklet;
  
  @Autowired
  private CbbkCombineInstallmentPaymentTasklet cbbkCombineInstallmentPaymentTasklet;
  
  // 5분마다
//  @Scheduled(fixedRate = 300000)
  @Scheduled(cron="0 */5 * * * *")
  public String runAutoAllotCombine() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(AutoAllotCombineJob(), param);
    
    return execution.getStatus().toString();

  }

  @Bean
  public Job AutoAllotCombineJob() {

    return jobBuilderFactory
        .get("autoAllotCombineJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(orderStatusCbbkReadyCombineStep())
        .next(cbbkPaymentRequestDoneCombineStep())
        .next(orderStatusCbbkAcceptStep())
        .next(cbbkDeliveryWaitStep())
        .next(cbbkCombineInstallmentPaymentTaskletStep())
        .build();
  }
  
  // 주문상태가 가상계좌 입금대기 조회
  @Bean
  public Step orderStatusCbbkReadyCombineStep() {

    return stepBuilderFactory
        .get("orderStatusCbbkReadyCombineStep")
        .tasklet(orderStatusCbbkReadyCombineTasklet)
        .build();
  }
  
  // 자동분배
  @Bean
  public Step cbbkPaymentRequestDoneCombineStep() {
    
    return stepBuilderFactory
        .get("cbbkPaymentRequestDoneCombineStep")
        .tasklet(cbbkPaymentRequestDoneCombineTasklet)
        .build();
  }
  
  // 주문 및 결제작업정보 수정
  @Bean
  public Step orderStatusCbbkAcceptStep() {
    
    return stepBuilderFactory
        .get("orderStatusCbbkAcceptStep")
        .tasklet(orderStatusCbbkAcceptTasklet)
        .build();
  }
  
  // 배송 요청 상태를 대기로 변경
  @Bean
  public Step cbbkDeliveryWaitStep() {
    return stepBuilderFactory
        .get("cbbkDeliveryWaitStep")
        .tasklet(cbbkDeliveryWaitTasklet)
        .build();
  }
  
  //할부 일 경우 완료 시킴
  @Bean
  public Step cbbkCombineInstallmentPaymentTaskletStep() {
    return stepBuilderFactory
        .get("cbbkCombineInstallmentPaymentTaskletStep")
        .tasklet(cbbkCombineInstallmentPaymentTasklet)
        .build();
  }
  
  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

}