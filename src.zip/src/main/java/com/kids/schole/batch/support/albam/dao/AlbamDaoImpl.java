package com.kids.schole.batch.support.albam.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.albam.domain.DailyMeetingInfo;
import com.kids.schole.batch.support.albam.domain.VwSalesEmpInfo;

@Repository
public class AlbamDaoImpl implements AlbamDao {
  
  @Autowired
  private SqlSession sqlSession;

  @Override
  public List<VwSalesEmpInfo> selectVwSalesEmpInfoList(VwSalesEmpInfo vwSalesEmpInfo) {
    return sqlSession.selectList("albam.selectVwSalesEmpInfoList", vwSalesEmpInfo);
  }
  
  @Override
  public int selectDuplicateDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo) {
    return sqlSession.selectOne("albam.selectDuplicateDailyMeetingInfo", dailyMeetingInfo);
  }

  @Override
  public void insertDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo) {
    sqlSession.insert("albam.insertDailyMeetingInfo",dailyMeetingInfo);
  }

  @Override
  public void updateDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo) {
    sqlSession.update("albam.updateDailyMeetingInfo", dailyMeetingInfo);
  }

}
