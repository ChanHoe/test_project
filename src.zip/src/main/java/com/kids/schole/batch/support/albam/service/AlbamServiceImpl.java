package com.kids.schole.batch.support.albam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.albam.dao.AlbamDao;
import com.kids.schole.batch.support.albam.domain.DailyMeetingInfo;
import com.kids.schole.batch.support.albam.domain.VwSalesEmpInfo;

@Service
public class AlbamServiceImpl implements AlbamService{

  @Autowired
  private AlbamDao albamDao;

  @Override
  public List<VwSalesEmpInfo> getVwSalesEmpInfoList(VwSalesEmpInfo vwSalesEmpInfo) {
    return albamDao.selectVwSalesEmpInfoList(vwSalesEmpInfo);
  }

  @Override
  public int getDuplicateDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo) {
    return albamDao.selectDuplicateDailyMeetingInfo(dailyMeetingInfo);
  }
  
  @Override
  public void createDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo) {
    albamDao.insertDailyMeetingInfo(dailyMeetingInfo);
  }

  @Override
  public void modifyDailyMeetingInfo(DailyMeetingInfo dailyMeetingInfo) {
    albamDao.updateDailyMeetingInfo(dailyMeetingInfo);
  }
}
