package com.kids.schole.batch.support.delivery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kids.schole.batch.support.delivery.dao.DeliveryDao;
import com.kids.schole.batch.support.delivery.domain.DeliveryRequest;
import com.kids.schole.batch.support.order.domain.Order;

@Service
public class DeliveryServiceImpl implements DeliveryService {

  @Autowired
  private DeliveryDao deliveryDao;

  @Override
  public void modifyDeliveryRequestStatusWait(DeliveryRequest deliveryRequest) {
    deliveryDao.updateDeliveryRequestStatusWait(deliveryRequest);
  }

  @Override
  public List<Order> getDeliveryStatusWaitList(String businessDay) {
    return deliveryDao.selectDeliveryStatusWaitList(businessDay);
  }

  @Override
  public void modifyDeliveryRequestStatusScmAccept(DeliveryRequest deliveryRequest) {
    deliveryDao.updateDeliveryRequestStatusScmAccept(deliveryRequest);
  }

  @Override
  public List<DeliveryRequest> getDeliveryStatusScmDeliveryList() {
    return deliveryDao.selectDeliveryStatusScmDeliveryList();
  }

  @Override
  public void modifyDeliveryRequestStatus(DeliveryRequest deliveryRequest) {
    deliveryDao.updateDeliveryRequestStatus(deliveryRequest);
  }

  @Override
  public int getDeliveryStatusNotScmShippedCount(int orderId) {
    return deliveryDao.selectDeliveryStatusNotScmShippedCount(orderId);
  }
  
  @Override
  public List<Order> getDeliveryStatusWaitListForCard(String businessDay) {
    return deliveryDao.selectDeliveryStatusWaitListForCard(businessDay);
  }
  
}
