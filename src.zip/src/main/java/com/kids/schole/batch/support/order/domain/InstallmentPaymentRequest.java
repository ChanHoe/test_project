package com.kids.schole.batch.support.order.domain;

/**
 * InstallmentPaymentRequest는 할부요청 도메인 클래스입니다.
 *
 * @version 1.0 2016.11.14
 * @author Jeongwon Son
 */
public class InstallmentPaymentRequest {

  private int installmentPaymentRequestId;
  private int paymentId;
  private String installmentPaymentRequestStatus;
  private int installmentPaymentCount;
  private long totalInstallmentPaymentAmt;
  private long taxableAmt;
  private long vatAmt;
  private long nonTaxableAmt;
  private long sundryLossesAmt;
  private int customerId;
  private int payDay;
  private String applicationDate;
  private String applicationType;
  private String applicationStatus;
  private String applicationResponseMessage;
  private int registeredEmpNumber;
  private String registeredDatetime;
  private int lastUpdatedEmpNumber;
  private String lastUpdatedDatetime;

  // 다음달 첫날.
  private String firstDayOfNextMonth;

  public int getInstallmentPaymentRequestId() {
    return installmentPaymentRequestId;
  }

  public void setInstallmentPaymentRequestId(int installmentPaymentRequestId) {
    this.installmentPaymentRequestId = installmentPaymentRequestId;
  }

  public int getPaymentId() {
    return paymentId;
  }

  public void setPaymentId(int paymentId) {
    this.paymentId = paymentId;
  }

  public String getInstallmentPaymentRequestStatus() {
    return installmentPaymentRequestStatus;
  }

  public void setInstallmentPaymentRequestStatus(String installmentPaymentRequestStatus) {
    this.installmentPaymentRequestStatus = installmentPaymentRequestStatus;
  }

  public int getInstallmentPaymentCount() {
    return installmentPaymentCount;
  }

  public void setInstallmentPaymentCount(int installmentPaymentCount) {
    this.installmentPaymentCount = installmentPaymentCount;
  }

  public long getTotalInstallmentPaymentAmt() {
    return totalInstallmentPaymentAmt;
  }

  public void setTotalInstallmentPaymentAmt(long totalInstallmentPaymentAmt) {
    this.totalInstallmentPaymentAmt = totalInstallmentPaymentAmt;
  }

  public long getTaxableAmt() {
    return taxableAmt;
  }

  public void setTaxableAmt(long taxableAmt) {
    this.taxableAmt = taxableAmt;
  }

  public long getVatAmt() {
    return vatAmt;
  }

  public void setVatAmt(long vatAmt) {
    this.vatAmt = vatAmt;
  }

  public long getNonTaxableAmt() {
    return nonTaxableAmt;
  }

  public void setNonTaxableAmt(long nonTaxableAmt) {
    this.nonTaxableAmt = nonTaxableAmt;
  }

  public long getSundryLossesAmt() {
    return sundryLossesAmt;
  }

  public void setSundryLossesAmt(long sundryLossesAmt) {
    this.sundryLossesAmt = sundryLossesAmt;
  }

  public int getCustomerId() {
    return customerId;
  }

  public void setCustomerId(int customerId) {
    this.customerId = customerId;
  }

  public int getPayDay() {
    return payDay;
  }

  public void setPayDay(int payDay) {
    this.payDay = payDay;
  }

  public String getApplicationDate() {
    return applicationDate;
  }

  public void setApplicationDate(String applicationDate) {
    this.applicationDate = applicationDate;
  }

  public String getApplicationType() {
    return applicationType;
  }

  public void setApplicationType(String applicationType) {
    this.applicationType = applicationType;
  }

  public String getApplicationStatus() {
    return applicationStatus;
  }

  public void setApplicationStatus(String applicationStatus) {
    this.applicationStatus = applicationStatus;
  }

  public String getApplicationResponseMessage() {
    return applicationResponseMessage;
  }

  public void setApplicationResponseMessage(String applicationResponseMessage) {
    this.applicationResponseMessage = applicationResponseMessage;
  }

  public int getRegisteredEmpNumber() {
    return registeredEmpNumber;
  }

  public void setRegisteredEmpNumber(int registeredEmpNumber) {
    this.registeredEmpNumber = registeredEmpNumber;
  }

  public String getRegisteredDatetime() {
    return registeredDatetime;
  }

  public void setRegisteredDatetime(String registeredDatetime) {
    this.registeredDatetime = registeredDatetime;
  }

  public int getLastUpdatedEmpNumber() {
    return lastUpdatedEmpNumber;
  }

  public void setLastUpdatedEmpNumber(int lastUpdatedEmpNumber) {
    this.lastUpdatedEmpNumber = lastUpdatedEmpNumber;
  }

  public String getLastUpdatedDatetime() {
    return lastUpdatedDatetime;
  }

  public void setLastUpdatedDatetime(String lastUpdatedDatetime) {
    this.lastUpdatedDatetime = lastUpdatedDatetime;
  }

  public String getFirstDayOfNextMonth() {
    return firstDayOfNextMonth;
  }

  public void setFirstDayOfNextMonth(String firstDayOfNextMonth) {
    this.firstDayOfNextMonth = firstDayOfNextMonth;
  }

}
