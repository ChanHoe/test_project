package com.kids.schole.batch.support.order.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kids.schole.batch.support.card.domain.CardPaymentRequest;
import com.kids.schole.batch.support.order.domain.InstallmentPayment;
import com.kids.schole.batch.support.order.domain.InstallmentPaymentRequest;
import com.kids.schole.batch.support.order.domain.Order;
import com.kids.schole.batch.support.order.domain.OrderPayment;

@Repository
public class OrderDaoImpl implements OrderDao {

  @Autowired
  private SqlSession sqlSession;

  @Override
  public List<CardPaymentRequest> selectOrderApprovalList() {
    return sqlSession.selectList("order.selectOrderApprovalList");
  }

  @Override
  public void updateOrderPaymentPayStatus(OrderPayment orderPayment) {
    sqlSession.update("order.updateOrderPaymentPayStatus", orderPayment);
  }

  @Override
  public void updateOrderPayDoneAmt(Order order) {
    sqlSession.update("order.updateOrderPayDoneAmt", order);
  }

  @Override
  public void updateOrderStatus(Order order) {
    sqlSession.update("order.updateOrderStatus", order);
  }

  @Override
  public void updateOrderStatusDone(Order order) {
    sqlSession.update("order.updateOrderStatusDone", order);
  }

  @Override
  public void updateInstallmentPaymentRequestStatus(
      InstallmentPaymentRequest installmentPaymentRequest) {
    sqlSession.update("order.updateInstallmentPaymentRequestStatus", installmentPaymentRequest);
  }

  @Override
  public void updateInstallmentPaymentStatus(InstallmentPayment installmentPayment) {
    sqlSession.update("order.updateInstallmentPaymentStatus", installmentPayment);
  }

  @Override
  public Order selectOrder(int orderId) {
    return sqlSession.selectOne("order.selectOrder", orderId);
  }

  @Override
  public void updateOrderAttachedFileProofStatusFailToWait() {
    sqlSession.update("order.updateOrderAttachedFileProofStatusFailToWait");
  }

}
