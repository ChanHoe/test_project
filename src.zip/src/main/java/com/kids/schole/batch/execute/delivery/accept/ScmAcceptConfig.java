package com.kids.schole.batch.execute.delivery.accept;

/**
 * ScmAcceptConfig는 배송요청 대기건이 주문을 조회해서 
 * SCM에 배송 요청을 하고 그 이후 작업을 처리하는 클래스입니다.
 * 
 * @version 1.0 2016.12.17
 * @author Jeongho Baek
 */
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import com.kids.schole.batch.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class ScmAcceptConfig {
  
  @Autowired
  public JobLauncher jobLauncher;

  @Autowired
  public JobBuilderFactory jobBuilderFactory;

  @Autowired
  public StepBuilderFactory stepBuilderFactory;
  
  @Autowired
  private ScmAcceptTasklet scmAcceptTasklet;
  
  @Autowired
  private OrderAcceptTasklet orderAcceptTasklet;
  
  @Autowired
  private DeliveryRequestAcceptTasklet deliveryRequestAcceptTasklet;
  
  @Autowired
  private ScmAcceptForCardTasklet scmAcceptForCardTasklet;
  
  //저녁 7시 30분
  @Scheduled(cron = "0 30 19 * * ?")
  public String runScmAccept() throws Exception {

    JobParameters param = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

    JobExecution execution = jobLauncher.run(scmAcceptJob(), param);

    return execution.getStatus().toString();

  }
  
 //오후 2시 ( 매입이 완료된 건에 한해서 Card로 결제한 것만 배송 요청 )
 @Scheduled(cron = "0 0 14 * * ?")
 public String runScmAcceptForCard() throws Exception {

   JobParameters param = new JobParametersBuilder()
       .addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

   JobExecution execution = jobLauncher.run(scmAcceptForCardJob(), param);

   return execution.getStatus().toString();

 }
  
  @Bean
  public Job scmAcceptJob() {

    return jobBuilderFactory
        .get("scmAcceptJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(scmAcceptStep())
        .next(orderAcceptStep())
        .next(deliveryRequestAcceptStep())
        .build();
  }
  
  @Bean
  public Job scmAcceptForCardJob() {

    return jobBuilderFactory
        .get("scmAcceptForCardJob")
        .incrementer(new RunIdIncrementer())
        .listener(listener())
        .start(scmAcceptForCardStep())
        .next(orderAcceptStep())
        .next(deliveryRequestAcceptStep())
        .build();
  }
  
  // 배송요청 대기중인 주문을 가져와서 SCM쪽에 배송 요청을 한다.
  @Bean
  public Step scmAcceptStep() {

   return stepBuilderFactory
       .get("scmAcceptStep")
       .tasklet(scmAcceptTasklet)
       .build();
  }
  
  // 주문 테이블의 주문상태를 업데이트한다.
  @Bean
  public Step orderAcceptStep() {
    return stepBuilderFactory
        .get("orderAcceptStep")
        .tasklet(orderAcceptTasklet)
        .build();
  }
  
  // 배송요청 테이블의 배송상태를 업데이트한다.
  @Bean
  public Step deliveryRequestAcceptStep() {
    return stepBuilderFactory
        .get("deliveryRequestAcceptStep")
        .tasklet(deliveryRequestAcceptTasklet)
        .build();
  }
  
   // 카드로 결제한 배송요청 대기중인 주문을 가져와서 SCM쪽에 배송 요청을 한다.
   @Bean
   public Step scmAcceptForCardStep() {
  
    return stepBuilderFactory
        .get("scmAcceptForCardStep")
        .tasklet(scmAcceptForCardTasklet)
        .build();
   }

  @Bean
  public JobExecutionListener listener() {
    return new JobCompletionNotificationListener();
  }

  
}
